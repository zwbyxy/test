#!/bin/bash

for fn in  `find ./ |grep Inc_Delivery|grep txt |grep -v bak|grep 202008`
        do
        echo "文件${fn}处理开始" >> zwb.log
	name=''
	
	ct=`echo ${fn}|xargs wc -l`
	cat 
	echo "文件${fn}处理结束" >> zwb.log
        done
