#不全父企业code，父企业名称
#1、根据营帐话单获取父企业id
find ./ |grep Inc_member |xargs cat |awk -F "|" '{print $5}' |sort -r |uniq -c 
#2、根据父企业id获取父企业code，父企业名称,放入info.txt中
20000028|CSR0104613|中国移动通信集团河南有限公司
20000040|CSR0104616|中国移动通信集团河北有限公司
20000053|CSR0104623|中国移动通信集团山西有限公司
#3、执行脚本zwb_add_feild2.sh



#产品id "null" 处理。
find ./ |grep Inc_membe |xargs cat  |grep null |awk -F '|' '{print $1"|"$8"|"$9"|"$10"|"$NF}'> get_old_info2.txt


#数据库处理：
#单独查询察看
SELECT DISTINCT ts.`enterpriseID`,ts.`servType`,tb.`msisdn`,r.`orgID`,ts.`pkgID` FROM ecpm_t_content ts , ecpm_t_content_org t ,ecpm_t_org_rel r , ecpm_t_member tb
WHERE ts.`ID`=t.`cyContID` AND t.`ownerID`=r.`orgID` AND r.`ID`=tb.`ID`
#AND ts.`approveStatus`=3  ##审核通过
#and ts.`ID`='572971'
AND ts.`chargeType`=2
AND ts.`enterpriseType` NOT IN ('6')
AND tb.`msisdn`  IN  ('13616060289')
AND ts.`enterpriseID`='30000582'
AND ts.`servType`=1
AND r.`orgID`='11742';


#ecpm入库临时表
CREATE TABLE t_zwb_temptest (a0 VARCHAR(1000) , a1 VARCHAR(1000) , a2 VARCHAR(1000) , a3 VARCHAR(1000) , a4 VARCHAR(1000) , a5 VARCHAR(1000) )


#挂机短信数据提取 
SELECT * FROM t_zwb_temp_test_gjdx
CREATE TABLE t_zwb_temp_test_gjdx
SELECT DISTINCT tb.`msisdn`,r.`orgID`,ts.`pkgID` FROM ecpm_t_content ts , ecpm_t_content_org t ,ecpm_t_org_rel r , ecpm_t_member tb,t_zwb_temptest aa
WHERE ts.`ID`=t.`cyContID` AND t.`ownerID`=r.`orgID` AND r.`ID`=tb.`ID`
#AND ts.`approveStatus`=3  ##审核通过
#and ts.`ID`='572971'
AND ts.`chargeType`=2
AND ts.`enterpriseType` NOT IN ('6')
AND tb.`msisdn` =aa.a3
AND ts.`enterpriseID`=aa.a0
AND ts.`servType`=aa.a1
AND r.`orgID`=aa.a4
AND ts.subservtype=aa.a2
AND ts.subservtype=4


#挂机彩信 数据提取
CREATE TABLE t_zwb_temp_test_gjcx
SELECT DISTINCT tb.`msisdn`,r.`orgID`,ts.`pkgID` FROM ecpm_t_content ts , ecpm_t_content_org t ,ecpm_t_org_rel r , ecpm_t_member tb,t_zwb_temptest aa
WHERE ts.`ID`=t.`cyContID` AND t.`ownerID`=r.`orgID` AND r.`ID`=tb.`ID`
#AND ts.`approveStatus`=3  ##审核通过
#and ts.`ID`='572971'
AND ts.`chargeType`=2
AND ts.`enterpriseType` NOT IN ('6')
AND tb.`msisdn` =aa.a3
AND ts.`enterpriseID`=aa.a0
AND ts.`servType`=aa.a1
AND r.`orgID`=aa.a4
AND ts.subservtype=aa.a2
AND ts.subservtype=8


#屏显 数据提取
CREATE TABLE t_zwb_temp_test_px
SELECT DISTINCT tb.`msisdn`,r.`orgID`,ts.`pkgID` FROM ecpm_t_content ts , ecpm_t_content_org t ,ecpm_t_org_rel r , ecpm_t_member tb,t_zwb_temptest aa
WHERE ts.`ID`=t.`cyContID` AND t.`ownerID`=r.`orgID` AND r.`ID`=tb.`ID`
#AND ts.`approveStatus`=3  ##审核通过
#and ts.`ID`='572971'
AND ts.`chargeType`=2
AND ts.`enterpriseType` NOT IN ('6')
AND tb.`msisdn` =aa.a3
AND ts.`enterpriseID`=aa.a0
AND ts.`servType`=aa.a1
AND r.`orgID`=aa.a4
AND ts.subservtype IN (1,2,3)
AND aa.a2='3'
;







#26310
SELECT t.a3,COUNT(1) FROM t_zwb_temptest t GROUP BY t.a3;
#26758
SELECT COUNT(1) FROM t_zwb_temptest t 

SELECT DISTINCT t.a3,t.a4 FROM t_zwb_temptest t WHERE t.a3='13007563557'
SELECT  t.* FROM t_zwb_temptest t WHERE t.a3='13007563557';

#历史割接问题(一样父id ，其中主、被叫存在不同包月pkgid)，需要删除被叫1013数据
CREATE TABLE  t_zwb_temp_test_px_duo AS 
SELECT px.`msisdn` FROM t_zwb_temp_test_px px GROUP BY px.`msisdn` HAVING COUNT(1) >1  #1678
SELECT px.* FROM t_zwb_temp_test_px px  JOIN t_zwb_temp_test_px_duo d ON (px.msisdn=d.msisdn) WHERE px.pkgid='1013'
#delete px FROM t_zwb_temp_test_px px  JOIN t_zwb_temp_test_px_duo d ON (px.msisdn=d.msisdn) WHERE px.pkgid='1013'

#drop table t_zwb_temp_test_all
CREATE TABLE t_zwb_temp_test_all AS 
SELECT '1' a1 ,'4' a2, msisdn,orgid,pkgid FROM t_zwb_temp_test_gjdx
UNION ALL
SELECT '1' a1 ,'8' a2, msisdn,orgid,pkgid FROM t_zwb_temp_test_gjcx
UNION ALL
SELECT '1' a1 ,'3' a2, msisdn,orgid,pkgid FROM t_zwb_temp_test_px
;
SELECT * FROM t_zwb_temptest; #26758
SELECT COUNT(*) FROM t_zwb_temp_test_all; #26498
SELECT * FROM t_zwb_temp_test_zc #26498
#提取正常数据
CREATE TABLE t_zwb_temp_test_zc
SELECT t1.*,t2.`pkgid` FROM t_zwb_temptest t1 JOIN t_zwb_temp_test_all t2 ON (t1.`a1`=t2.`a1` AND t1.`a2`=t2.`a2` AND t1.a3=t2.`msisdn` AND t1.`a4`=t2.`orgid`)

#为关联到分组的数据处理
SELECT * FROM t_zwb_temp_test_yc #260
#drop table t_zwb_temp_test_yc
CREATE TABLE t_zwb_temp_test_yc
SELECT t1.*,t2.pkgid FROM t_zwb_temptest t1 LEFT JOIN t_zwb_temp_test_all t2 ON (t1.`a1`=t2.`a1` AND t1.`a2`=t2.`a2` AND t1.a3=t2.`msisdn` AND t1.`a4`=t2.`orgid`) WHERE t2.pkgid IS NULL;

#查找企业关联内容的pkgid进行参考修复pkgid字段
SELECT * FROM `ecpm_t_content` ts  WHERE ts.`chargeType`=2  AND ts.`enterpriseID` IN ('30000660') AND ts.`subServType`=8;# 1062
SELECT * FROM t_zwb_temp_test_yc yc WHERE yc.`pkgid` IS NULL ORDER BY yc.`a4`

#update t_zwb_temp_test_yc set pkgid='1049' where  a0='30000660' and  a2='8'




#提取最终数据
SELECT * FROM t_zwb_temp_test_zc
UNION ALL
SELECT * FROM t_zwb_temp_test_yc





##最后将数据放入info2.txt

#由于是月初定时任务倒入的话单又问题，因此找下月初话单进行修复（find ./  |grep Inc_member |grep 20200801）
#修改脚本zwb_add_feild3.sh中月初日期20200801 执行脚步

#生成新数据结尾使用$(unix格式)，规范使用的是^M$(windows格式) ,需要下载月初文件修改文件格式


