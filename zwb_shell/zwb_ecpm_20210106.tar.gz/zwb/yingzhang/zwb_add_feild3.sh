#!/bin/bash

for fn in  `find ./ |grep Inc_member|grep -v bak|grep 20200801`
        do
        echo "文件${fn}处理开始" >> zwb.log
        for info in `cat ./info2.txt`
                do
				eid=`echo ${info}|awk -F "|" '{print $1}'`
				stype=`echo ${info}|awk -F "|" '{print $2}'`
				subtype=`echo ${info}|awk -F "|" '{print $3}'`
				phone=`echo ${info}|awk -F "|" '{print $4}'`
				groupid=`echo ${info}|awk -F "|" '{print $5}'`
				pcode=`echo ${info}|awk -F "|" '{print $7}'`
                echo "${subtype}|${phone}|${groupid}|${pcode}针对${fn}已处理">>zwb.log
                awk   -v subtype="$subtype" -v phone="$phone" -v groupid="$groupid" -v pcode="$pcode" 'BEGIN{FS=OFS="|"}{if ( $9==subtype && $10==phone && $12==groupid ) $NF=pcode }1' "${fn}" > ${fn}_bak
				mv ${fn}_bak ${fn}
                done
	echo "文件${fn}处理结束" >> zwb.log
        done
