#!/bin/bash

for fn in  `find ./ |grep Inc_member|grep -v bak`
        do

        for info in `cat ./info.txt`
                do
				fid=`echo ${info}|awk -F "|" '{print $1}'`
				fcode=`echo ${info}|awk -F "|" '{print $2}'`
				fname=`echo ${info}|awk -F "|" '{print $3}'`
                echo $fid
                echo $fcode
                echo $fname
                echo $fn
                awk -v fid="$fid" -v  fcode="$fcode"  -v fname="$fname" 'BEGIN{FS=OFS="|"}{if ($5==fid) $6=fcode ; if ($5==fid) $7=fname }1' "${fn}" > ${fn}_bak
				mv ${fn}_bak ${fn}
                done
        done
