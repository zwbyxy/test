#date 20190301
###dsum interface bak###
#DATE=$(date -d "1 day ago" +%Y%m%d)
DATE=$(date +%Y%m%d)
#DATE2=$(date -d "1 day ago" +%Y-%m-%d)
DATE2=$(date +%Y-%m-%d)
mkdir -p /data/qglogs/dsum_logbak/interface_bak/temp
mkdir -p /data/qglogs/dsum_logbak/debug_bak/temp
rm -rf /data/qglogs/dsum_logbak/debug_bak/temp/*
rm -rf /data/qglogs/dsum_logbak/interface_bak/temp/*

wenjian=`find /data/qglogs/dsum/debug/interface.log.* -mmin +80 -type f | xargs ls -al --time-style="+%Y-%m-%d %H:%M:%S" |grep '.log' | awk '{print $6"_"$7"|"$8}'`
for i in $wenjian
do
#echo $i
logfilepwd=`echo $i | awk -F '|' '{print $2}'`
logname=`echo $i | awk -F '|' '{print $1}'`
echo $logfilepwd
echo $logname
cp -rp $logfilepwd  /data/qglogs/dsum_logbak/interface_bak/temp/interface_$logname.log
done

mkdir -p /data/qglogs/dsum_logbak/interface_bak/${DATE}
cd /data/qglogs/dsum_logbak/interface_bak/temp/
bzip2  *${DATE2}*.log
mv  /data/qglogs/dsum_logbak/interface_bak/temp/interface_${DATE2}*.log.bz2 /data/qglogs/dsum_logbak/interface_bak/${DATE}/
cd  /data/qglogs/dsum_logbak/interface_bak/${DATE}/
#gzip *.log


wenjian2=`find /data/qglogs/dsum/debug/debug.log.* -mmin +80 -type f | xargs ls -al --time-style="+%Y-%m-%d %H:%M:%S" |grep  ".log"   | awk '{print $6"_"$7"|"$8}'`
for o in $wenjian2
do
#echo $i
logfilepwd=`echo $o | awk -F '|' '{print $2}'`
logname=`echo $o | awk -F '|' '{print $1}'`
echo $logfilepwd
echo $logname
cp -rp $logfilepwd  /data/qglogs/dsum_logbak/debug_bak/temp/debug_$logname.log
done

mkdir -p /data/qglogs/dsum_logbak/debug_bak/${DATE}
cd /data/qglogs/dsum_logbak/debug_bak/temp/
bzip2  *${DATE2}*.log
mv  /data/qglogs/dsum_logbak/debug_bak/temp/debug_${DATE2}*.log.bz2  /data/qglogs/dsum_logbak/debug_bak/${DATE}/
cd  /data/qglogs/dsum_logbak/debug_bak/${DATE}/
