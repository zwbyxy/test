#!/bin/bash
##微服务补丁升级脚本，适用jar包补丁##
##使用说明：将补丁放到补丁指定目录~/zwb/zwb_jarbuding/，执行脚本update.sh##
now_time=`date +%Y%m%d%H%M%S`
#date +%s%N >  ~/zwb/zwb_jarbuding_bak/version_flag.txt
version_flag=`cat ~/zwb/zwb_jarbuding_bak/version_flag.txt`
echo "" > ~/zwb/temp/flag.txt

##判断回滚文件是否存在,没有退出##
[ `ls ~/zwb/zwb_jarbuding_bak/* |grep ${version_flag}|wc -l |wc -l` -eq 0 ] && {
echo "没有回滚文件，退出。"
exit 1
}

chown 6001:6001  ~/zwb/zwb_jarbuding_bak/*${version_flag}*
##获取回滚文件名称##
ls -l ~/zwb/zwb_jarbuding_bak/  |grep ${version_flag} |awk  '{print $NF}'  > ~/zwb/temp/jar_rollbakfilename.txt

##获取容器id，如果不存在退出##
id=`docker ps -a |grep "/huawei/dsum" | awk  '{print $1}'`

[  -z "`echo ${id}`"  ] && {
echo "容器id未找到，退出！！"
exit 1
}


##回滚数据##
for i in `cat ~/zwb/temp/jar_rollbakfilename.txt`
do
##备份##
#docker cp  ${id}:/home/dsum/dsum_container/modules/dsum/lib/${i}  ~/zwb/zwb_jarbuding_bak/${i}_bak${now_time}_${version_flag}
#sleep 1
##回滚##
jarfilename=`echo ${i} | awk -F "_" '{print $1}'`
docker cp ~/zwb/zwb_jarbuding_bak/${i} ${id}:/home/dsum/dsum_container/modules/dsum/lib/${jarfilename}
sleep 1
##获取回滚文件比较##
docker cp  ${id}:/home/dsum/dsum_container/modules/dsum/lib/${jarfilename}  ~/zwb/zwb_jarbuding_checkfile/${jarfilename}
sleep 1
if [ `ls -la ~/zwb/zwb_jarbuding_bak/${i}  |awk '{print $5}'` -eq `ls -la ~/zwb/zwb_jarbuding_checkfile/${jarfilename}  |awk '{print $5}'` ]
then
 echo "${i}已经替换成功!"
 echo "${i}已经替换成功!" >> ~/zwb/temp/flag.txt
 else 
 echo "${i}已经替换失败，请检查!!" >> ~/zwb/temp/flag.txt
fi

done

##判断没有替换失败重启应用##
if [ `grep "失败"  ~/zwb/temp/flag.txt |wc -l` -eq 0 ] 
then

docker exec -it ${id} /bin/bash -c 'cd /home/dsum/dsum_container/modules/dsum/bin/ && ./1.sh;./2.sh'
#docker exec -it ${id} /bin/bash -c 'cd /home/dsum/dsum_container/modules/dsum/bin/ && ./stop_app.sh;./start_app.sh'

else
echo "有替换失败数据退出"
exit 1
fi
#mv ~/zwb/zwb_jarbuding/*.jar ~/zwb/temp/
rm -rf ~/zwb/zwb_jarbuding_checkfile/*.jar*

