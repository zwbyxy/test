#date 20190301
###ecpm interface bak###
DATE=$(date -d "1 day ago" +%Y%m%d)
#DATE=$(date +%Y%m%d)
DATE2=$(date -d "1 day ago" +%Y-%m-%d)
#DATE2=$(date +%Y-%m-%d)
mkdir -p /data/qglogs/ecpm_logbak/interface_bak/temp
mkdir -p /data/qglogs/ecpm_logbak/debug_bak/temp
mkdir -p /data/qglogs/ecpm_logbak/task_bak/temp
rm -rf /data/qglogs/ecpm_logbak/task_bak/temp/*
rm -rf /data/qglogs/ecpm_logbak/debug_bak/temp/*
rm -rf /data/qglogs/ecpm_logbak/interface_bak/temp/*

wenjian=`find /data/qglogs/ecpm/debug/interface.log.* -mmin +80 -type f | xargs ls -al --time-style="+%Y-%m-%d %H:%M:%S" |grep '.log' | awk '{print $6"_"$7"|"$8}'`
for i in $wenjian
do
#echo $i
logfilepwd=`echo $i | awk -F '|' '{print $2}'`
logname=`echo $i | awk -F '|' '{print $1}'`
echo $logfilepwd
echo $logname
cp -rp $logfilepwd  /data/qglogs/ecpm_logbak/interface_bak/temp/interface_$logname.log
done

mkdir -p /data/qglogs/ecpm_logbak/interface_bak/${DATE}
cd /data/qglogs/ecpm_logbak/interface_bak/temp/
bzip2  *${DATE2}*.log
mv  /data/qglogs/ecpm_logbak/interface_bak/temp/interface_${DATE2}*.log.bz2 /data/qglogs/ecpm_logbak/interface_bak/${DATE}/
cd  /data/qglogs/ecpm_logbak/interface_bak/${DATE}/
#gzip *.log


wenjian2=`find /data/qglogs/ecpm/debug/debug.log.* -mmin +80 -type f | xargs ls -al --time-style="+%Y-%m-%d %H:%M:%S" |grep '.log' | awk '{print $6"_"$7"|"$8}'`
for o in $wenjian2
do
#echo $o
logfilepwd=`echo $o | awk -F '|' '{print $2}'`
logname=`echo $o | awk -F '|' '{print $1}'`
echo $logfilepwd
echo $logname
cp -rp $logfilepwd  /data/qglogs/ecpm_logbak/debug_bak/temp/debug_$logname.log
done

mkdir -p /data/qglogs/ecpm_logbak/debug_bak/${DATE}
cd /data/qglogs/ecpm_logbak/debug_bak/temp/
bzip2  *${DATE2}*.log
mv  /data/qglogs/ecpm_logbak/debug_bak/temp/debug_${DATE2}*.log.bz2  /data/qglogs/ecpm_logbak/debug_bak/${DATE}/
cd  /data/qglogs/ecpm_logbak/debug_bak/${DATE}/

wenjian3=`find /data/qglogs/ecpm/debug/task.log.* -mmin +80 -type f | xargs ls -al --time-style="+%Y-%m-%d %H:%M:%S" |grep '.log' | awk '{print $6"_"$7"|"$8}'`
for w in $wenjian3
do
#echo $i
logfilepwd=`echo $w | awk -F '|' '{print $2}'`
logname=`echo $w | awk -F '|' '{print $1}'`
echo $logfilepwd
echo $logname
cp -rp $logfilepwd  /data/qglogs/ecpm_logbak/task_bak/temp/task_$logname.log
done

mkdir -p /data/qglogs/ecpm_logbak/task_bak/${DATE}
cd /data/qglogs/ecpm_logbak/task_bak/temp/
bzip2  *${DATE2}*.log
mv  /data/qglogs/ecpm_logbak/task_bak/temp/task_${DATE2}*.log.bz2  /data/qglogs/ecpm_logbak/task_bak/${DATE}/
cd  /data/qglogs/ecpm_logbak/task_bak/${DATE}/


wenjian4=`find /data/qglogs/ecpm/debug/feign.log.* -mmin +5 -type f | xargs ls -al --time-style="+%Y-%m-%d %H:%M:%S" |grep '.log' | awk '{print $6"_"$7"|"$8}'`
for w in $wenjian4
do
#echo $i
logfilepwd=`echo $w | awk -F '|' '{print $2}'`
logname=`echo $w | awk -F '|' '{print $1}'`
echo $logfilepwd
echo $logname
cp -rp $logfilepwd  /data/qglogs/ecpm_logbak/feign_bak/temp/feign_$logname.log
done

mkdir -p /data/qglogs/ecpm_logbak/feign_bak/${DATE}
cd /data/qglogs/ecpm_logbak/feign_bak/temp/
bzip2  *${DATE2}*.log
mv  /data/qglogs/ecpm_logbak/feign_bak/temp/feign_${DATE2}*.log.bz2  /data/qglogs/ecpm_logbak/feign_bak/${DATE}/
cd  /data/qglogs/ecpm_logbak/feign_bak/${DATE}/
