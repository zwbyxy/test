#!/bin/bash
cat /etc/hostname |\
while read line
do
Host_IP="$(echo $line| awk '{print $1}')"
Host_name="$(echo $line| awk '{print $2}')"
echo "$Host_IP"
#echo "$Host_name"
done
