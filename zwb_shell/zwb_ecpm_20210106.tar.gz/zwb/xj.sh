#!/bin/bash
echo "1、ecpm 调用外部失败接口统计:"
Date=$(date +%Y-%m-%d)
grep "€€€RSP€€€"  /data/qglogs/ecpm/debug/feign.log* |grep "${Date}" |grep -v "RC00000000" |awk -F "€€€" '{print $9}'|sort -r |uniq -c

interface_name=`grep "€€€RSP€€€"  /data/qglogs/ecpm/debug/feign.log* |grep "${Date}" |grep -v "RC00000000" |awk -F "€€€" '{print $9}'|sort -r |uniq -c | awk '{print $2}'`
for i in $interface_name
do

grep "€€€RSP€€€"  /data/qglogs/ecpm/debug/feign.log* |grep "${Date}" |grep -v "RC00000000" |grep "${i}" |tail -n 5
echo "############"
done


echo "2、外部调用ecpm失败接口统计:"
Date=$(date +%Y-%m-%d)
grep "€€€RSP€€€"  /data/qglogs/ecpm/debug/interface.log* |grep "${Date}" |grep -v "RC00000000" |awk -F "€€€" '{print $9}'|sort -r |uniq -c
interface_name=`grep "€€€RSP€€€"  /data/qglogs/ecpm/debug/interface.log* |grep "${Date}" |grep -v "RC00000000" |awk -F "€€€" '{print $9}'|sort -r |uniq -c | awk '{print $2}'`
for i in $interface_name
do

grep "€€€RSP€€€"  /data/qglogs/ecpm/debug/interface.log* |grep "${Date}" |grep -v "RC00000000" |grep "${i}" |tail -n 5
echo "############"
done


echo "1、dsum 调用外部失败接口统计:"
Date=$(date +%Y-%m-%d)
grep "€€€RSP€€€"  /data/qglogs/dsum/debug/feign.log* |grep "${Date}" |grep -v "RC00000000" |awk -F "€€€" '{print $9}'|sort -r |uniq -c

interface_name=`grep "€€€RSP€€€"  /data/qglogs/dsum/debug/feign.log* |grep "${Date}" |grep -v "RC00000000" |awk -F "€€€" '{print $9}'|sort -r |uniq -c | awk '{print $2}'`
for i in $interface_name
do

grep "€€€RSP€€€"  /data/qglogs/dsum/debug/feign.log* |grep "${Date}" |grep -v "RC00000000" |grep "${i}" |tail -n 5
echo "############"
done


echo "2、外部调用dsum失败接口统计:"
Date=$(date +%Y-%m-%d)
grep "€€€RSP€€€"  /data/qglogs/dsum/debug/interface.log* |grep "${Date}" |grep -v "RC00000000" |awk -F "€€€" '{print $9}'|sort -r |uniq -c
interface_name=`grep "€€€RSP€€€"  /data/qglogs/dsum/debug/interface.log* |grep "${Date}" |grep -v "RC00000000" |awk -F "€€€" '{print $9}'|sort -r |uniq -c | awk '{print $2}'`
for i in $interface_name
do

grep "€€€RSP€€€"  /data/qglogs/dsum/debug/interface.log* |grep "${Date}" |grep -v "RC00000000" |grep "${i}" |tail -n 5
echo "############"
done


