#!/bin/bash
 grep -B1 "start successful"  /data/qglogs/ecpm/server/server.out  |grep -A1 "`date +"%Y-%m-%d %H"`" > ~/zwb/temp/server_tmp.txt

[ `cat ~/zwb/temp/server_tmp.txt |wc -l` -gt 0 ] && {
echo "ecpm start successfully"
cat ~/temp/server_tmp.txt
exit 0
}

echo "ecpm maybe start faild!! pls  check server.out logs."

