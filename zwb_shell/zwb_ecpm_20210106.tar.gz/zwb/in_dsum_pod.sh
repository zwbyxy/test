#!/bin/bash

##获取容器id，如果不存在退出##
id=`docker ps -a |grep "/huawei/dsum" | awk  '{print $1}'`

[  -z "`echo ${id}`"  ] && {
echo "容器id未找到，退出！！"
exit 1
}

docker exec -it ${id} /bin/bash
