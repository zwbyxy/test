#!/bin/bash
[ -f ~/zwb/logs.conf ] || {
echo "配置文件 ~/zwb/logs.conf不存在，退出"
exit 1
}

##初始化回话标志位,只有当end时才可以再次执行logbak.sh
[ -s ~/zwb/flag_session.txt ] || {
echo "end" > ~/zwb/flag_session.txt
}

[ "`cat  ~/zwb/flag_session.txt`" = "end" ] || {
echo "上一次进程还未执行完成，退出。"
exit 1
}

echo "start" > ~/zwb/flag_session.txt
for i in `grep -v "^#" ~/zwb/logs.conf`
do
filepwd=`echo $i | awk -F "|" '{print $1}'`
logbakpwd=`echo $i | awk -F "|" '{print $2}'`
bakfname=`echo $i | awk -F "|" '{print $3}'`
cat ~/zwb/logbak_tamplate_v2.sh > ~/zwb/logbak_ec.sh         
sed -i "s#€a#${filepwd}#g" ~/zwb/logbak_ec.sh
sed -i "s#€b#${logbakpwd}#g" ~/zwb/logbak_ec.sh
sed -i "s#€c#${bakfname}#g" ~/zwb/logbak_ec.sh
chmod 755 ~/zwb/logbak_ec.sh
sh  ~/zwb/logbak_ec.sh

##规避前天部分数据没有备份到，只执行一次
cat ~/zwb/logbak_tamplate_one_v2.sh > ~/zwb/logbak_ec_one.sh
sed -i "s#€a#${filepwd}#g" ~/zwb/logbak_ec_one.sh
sed -i "s#€b#${logbakpwd}#g" ~/zwb/logbak_ec_one.sh
sed -i "s#€c#${bakfname}#g" ~/zwb/logbak_ec_one.sh
chmod 755 ~/zwb/logbak_ec_one.sh
[ -s ~/zwb/flag_${bakfname}_date.txt ] || {
date +%Y%m%d > ~/zwb/flag_${bakfname}_date.txt
}

if [ -f ~/zwb/flag_${bakfname}_date.txt -a "`cat ~/zwb/flag_${bakfname}_date.txt`" -eq "`date -d "1 day ago" +%Y%m%d`" ]
then
  if [ `date +%H` -ge 0 -a `date +%H` -le 24  ]
  then
  date +%Y%m%d > ~/zwb/flag_${bakfname}_date.txt
  sh ~/zwb/logbak_ec_one.sh
  fi
fi


done
echo "end" > ~/zwb/flag_session.txt
