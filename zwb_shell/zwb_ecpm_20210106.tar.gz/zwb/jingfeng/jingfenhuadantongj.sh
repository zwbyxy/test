#!/bin/bash
datelist=(
20200701
20200702
20200703
20200704
20200705
20200706
20200707
20200708
20200709
20200710
20200711
20200712
20200713
20200714
20200715
20200716
20200717
20200718
20200719
20200720
20200721
20200722
20200723
20200724
20200725
20200726
20200727
20200728
20200729
20200730
20200731
)

pidlist=(
        50000102
)

tongji_exec(){
        cd $1/$2
        datecount=`find ./ | grep ".txt" |xargs grep "|$3|" | awk -F "|" '{ if ( $52==0 ) print $39 }' |awk '{sum+=$1} END {print sum}'`
        echo -n "$3" >> $1/jingfeng_bydate_count.txt
        echo -n "|"  >> $1/jingfeng_bydate_count.txt
        echo -n "$2" >> $1/jingfeng_bydate_count.txt
        echo -n "|" >> $1/jingfeng_bydate_count.txt
        echo -n "$datecount" >> $1/jingfeng_bydate_count.txt
        echo  "" >>  $1/jingfeng_bydate_count.txt
}

main(){
        shpwd=`pwd`
        for array in ${pidlist[*]}
        do
                pid=$array
                for iarray in ${datelist[*]}
                do
                        tongji_exec $shpwd $iarray $pid
                        cd $shpwd
                done
        done
        cd $shpwd
}
main $
