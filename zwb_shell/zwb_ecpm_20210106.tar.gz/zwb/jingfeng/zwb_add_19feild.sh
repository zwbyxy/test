#!/bin/bash

for fn in  `find ./ |grep delivery_ |grep -v bak`
        do
        echo "文件${fn}处理开始" >> zwb.log
        for info in `cat ./info2.txt`
                do
                                eid=`echo ${info}|awk -F "|" '{print $1}'`
                                stype=`echo ${info}|awk -F "|" '{print $2}'`
                                subtype=`echo ${info}|awk -F "|" '{print $3}'`
                                phone=`echo ${info}|awk -F "|" '{print $4}'`
                echo "${subtype}|${phone}|${stype}|${eid}针对${fn}已处理">>zwb.log
                awk -v eid="$eid"   -v stype="$stype" -v subtype="$subtype" -v phone="$phone"  'BEGIN{FS=OFS="|"}{if ( $20==eid && $24==stype && $25==subtype ) $19=phone }1' "${fn}" > ${fn}_bak
                                mv ${fn}_bak ${fn}
                done
        echo "文件${fn}处理结束" >> zwb.log
        done
