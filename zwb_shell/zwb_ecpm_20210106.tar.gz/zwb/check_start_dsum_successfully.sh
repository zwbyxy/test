#!/bin/bash
 grep -B1 "dsum start successfully"  /data/qglogs/dsum/server/server.out  |grep -A1 "`date +"%Y-%m-%d %H"`" > ~/zwb/temp/server_dsum_tmp.txt

[ `cat ~/zwb/temp/server_dsum_tmp.txt |wc -l` -gt 0 ] && {
echo "dsum start successfully"
cat ~/temp/server_tmp.txt
exit 0
}

echo "dsum maybe start faild!! pls  check server.out logs."

