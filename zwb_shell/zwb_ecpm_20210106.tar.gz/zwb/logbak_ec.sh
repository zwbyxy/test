#!/bin/bash
#date 20190301
###ecpe interface bak###
#DATE=$(date -d "1 day ago" +%Y%m%d)
DATE=$(date +%Y%m%d)
#DATE2=$(date -d "1 day ago" +%Y-%m-%d)
DATE2=$(date +%Y-%m-%d)
#mkdir -p /data/qglogs/dsum_logbak/task_bak/temp
#rm -rf /data/qglogs/dsum_logbak/task_bak/temp/*
[ `find /data/qglogs/dsum/debug/task.log.* -mmin +5 -type f |grep '.log' |wc -l` -ne 0 ] || {
echo "日志不存在，退出。"
exit 1
}

mkdir -p /data/qglogs/dsum_logbak/task_bak/temp
cd /data/qglogs/dsum_logbak/task_bak/temp
if [ $? -eq 0 ] 
then
rm -rf /data/qglogs/dsum_logbak/task_bak/temp/*
fi

rm -rf ~/zwb/temp/logsnewnote_temp_temp.txt 
mkdir -p ~/zwb/temp/
[ -e ~/zwb/temp/logsnoteall.txt ] || {
cd  ~/zwb/temp/
#touch logsnoteall.txt
find /data/qglogs/dsum/debug/task.log.* -mmin +5 -type f | xargs ls -al --time-style="+%Y-%m-%d %H:%M:%S" |grep '.log' | awk '{print $6"_"$7"|"$8}'>~/zwb/temp/logsnoteall.txt
}


find /data/qglogs/dsum/debug/task.log.* -mmin +5 -type f | xargs ls -al --time-style="+%Y-%m-%d %H:%M:%S" |grep '.log' | awk '{print $6"_"$7"|"$8}'> ~/zwb/temp/logsnewnote.txt
##根据时间获取未备份的日志名称,并将所有数据备份记录到~/zwb/temp/logsnoteall.txt
#grep -v -f ~/zwb/temp/logsnoteall.txt ~/zwb/temp/logsnewnote.txt > ~/zwb/temp/logsdiffnote.txt
cat  ~/zwb/temp/logsnewnote.txt >  ~/zwb/temp/logsnewnote_temp.txt
for rule in  `cat ~/zwb/temp/logsnewnote.txt`
do
filedate=`echo ${rule}|awk -F "|" '{print $1}'`
filename=`echo ${rule}|awk -F "|" '{print $2}'`

sametime=`awk -v filedate="$filedate" -v  filename="$filename"  'BEGIN{FS=OFS="|"}{if ($1==filedate) print $1}' ~/zwb/temp/logsnoteall.txt` 
if [ -z ${sametime}  ]
then
echo "${sametime} is null."
else
grep -v "${sametime}"  ~/zwb/temp/logsnewnote_temp.txt > ~/zwb/temp/logsnewnote_temp_temp.txt
fi

if [ -e ~/zwb/temp/logsnewnote_temp_temp.txt ]
then
cat ~/zwb/temp/logsnewnote_temp_temp.txt > ~/zwb/temp/logsnewnote_temp.txt
echo "after1:"
#cat ~/zwb/temp/logsnewnote_temp.txt 
else
echo "after2:"
#cat ~/zwb/temp/logsnewnote_temp.txt 
fi

done
cat  ~/zwb/temp/logsnewnote_temp.txt >> ~/zwb/temp/logsnoteall.txt






#wenjian=`find /data/qglogs/dsum/debug/task.log.* -mmin +5 -type f | xargs ls -al --time-style="+%Y-%m-%d %H:%M:%S" |grep '.log' | awk '{print $6"_"$7"|"$8}'`
for i in `cat ~/zwb/temp/logsnewnote_temp.txt`
do
#echo $i
logfilepwd=`echo $i | awk -F '|' '{print $2}'`
logname=`echo $i | awk -F '|' '{print $1}'`
echo $logfilepwd
echo $logname
cp -rp $logfilepwd  /data/qglogs/dsum_logbak/task_bak/temp/10.124.72.144_dsum_task.log_$logname.log
done

mkdir -p /data/qglogs/dsum_logbak/task_bak/${DATE}
mkdir -p /data/qglogs/dsum_logbak/task_bak/logtemp
mv /data/qglogs/dsum_logbak/task_bak/temp/10.124.72.144_dsum_task.log_${DATE2}*.log /data/qglogs/dsum_logbak/task_bak/logtemp/
cd /data/qglogs/dsum_logbak/task_bak/logtemp/
bzip2  *${DATE2}*.log
mv /data/qglogs/dsum_logbak/task_bak/logtemp/10.124.72.144_dsum_task.log_${DATE2}*.log.bz2 /data/qglogs/dsum_logbak/task_bak/${DATE}/
#gzip *.log
