#!/bin/bash
##微服务补丁升级脚本，适用jar包补丁##
##使用说明：将补丁放到补丁指定目录~/zwb/zwb_jarbuding/，执行脚本update.sh##
now_time=`date +%Y%m%d%H%M%S`
date +%s%N >  ~/zwb/zwb_jarbuding_bak/version_flag.txt
version_flag=`cat ~/zwb/zwb_jarbuding_bak/version_flag.txt`
echo "" > ~/zwb/temp/flag.txt

##判断~/zwb/zwb_jarbuding/是否有补丁文件,没有退出##
[ `ls ~/zwb/zwb_jarbuding/ |wc -l` -eq 0 ] && {
echo "没有上传补丁文件，请上传。"
exit 1
}

chown 6001:6001  ~/zwb/zwb_jarbuding/*
##获取补丁文件名称##
ls -l ~/zwb/zwb_jarbuding/  |grep -v total |awk  '{print $NF}' > ~/zwb/temp/jarfilename.txt

##获取容器id，如果不存在退出##
id=`docker ps -a |grep "/huawei/dsum" | awk  '{print $1}'`

[  -z "`echo ${id}`"  ] && {
echo "容器id未找到，退出！！"
exit 1
}


##备份jar到~/zwb/zwb_jarbuding_bak,并将补丁包括制定目录##
for i in `cat ~/zwb/temp/jarfilename.txt`
do
##备份##
docker cp  ${id}:/home/dsum/dsum_container/modules/dsum/lib/${i}  ~/zwb/zwb_jarbuding_bak/${i}_bak${now_time}_${version_flag}
sleep 1
##升级##
docker cp ~/zwb/zwb_jarbuding/${i} ${id}:/home/dsum/dsum_container/modules/dsum/lib/${i}
sleep 1
##获取升级文件比较##
docker cp  ${id}:/home/dsum/dsum_container/modules/dsum/lib/${i}  ~/zwb/zwb_jarbuding_checkfile/${i}
sleep 1
if [ `ls -la ~/zwb/zwb_jarbuding/${i}  |awk '{print $5}'` -eq `ls -la ~/zwb/zwb_jarbuding_checkfile/${i}  |awk '{print $5}'` ]
then
 echo "${i}已经替换成功!"
 echo "${i}已经替换成功!" >> ~/zwb/temp/flag.txt
 else 
 echo "${i}已经替换失败，请检查!!" >> ~/zwb/temp/flag.txt
fi

done

##判断没有替换失败重启应用##
if [ `grep "失败"  ~/zwb/temp/flag.txt |wc -l` -eq 0 ] 
then

docker exec -it ${id} /bin/bash -c 'cd /home/dsum/dsum_container/modules/dsum/bin/ && ./1.sh;./2.sh'
#docker exec -it ${id} /bin/bash -c 'cd /home/dsum/dsum_container/modules/dsum/bin/ && ./stop_app.sh;./start_app.sh'

else
echo "有替换失败数据退出"
exit 1
fi
mv ~/zwb/zwb_jarbuding/*.jar ~/zwb/temp/
rm -rf ~/zwb/zwb_jarbuding_checkfile/*.jar

