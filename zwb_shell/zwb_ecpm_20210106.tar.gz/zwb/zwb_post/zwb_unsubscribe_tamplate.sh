curl -X  POST \
  http://10.254.1.2:19057/cy/internal/user/unsubscribe \
  -H 'Content-Type: application/json;charset=utf-8' \
  -H 'Connection: Keep-Alive' \
  -d '{
"valdateType": "1",
"productCode": "MDSP2000489466",
"userAccount": "€aaa",
"channelId": "20"
}'
