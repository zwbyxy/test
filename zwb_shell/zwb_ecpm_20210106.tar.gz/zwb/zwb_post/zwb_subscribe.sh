#!/bin/bash
gj_list=(
15280017653€30000683
14759209929€30000683
)
main(){
for array in ${gj_list[*]}
do
	phone=`echo ${array} |awk -F "€" '{print $1}'`
#	enterpriseID=`echo ${array} |awk -F "€" '{print $2}'`
	#echo ${phone}
	#echo ${enterpriseID}
	cat   /root/zwb/zwb_post/zwb_subscribe_tamplate.sh > /root/zwb/zwb_post/zwb_subscribe_temp.sh
	sed -i "s#€aaa#${phone}#g" /root/zwb/zwb_post/zwb_subscribe_temp.sh
#	sed -i "s#€bbb#${enterpriseID}#g" /root/zwb/zwb_post/zwb_subscribe_temp.sh
	chmod 755 /root/zwb/zwb_post/zwb_subscribe_temp.sh
	echo "${phone}执行结果:" >> /root/zwb/zwb_post/zwb_subscribe_temp.log
#	sh /root/zwb/zwb_post/zwb_subscribe_temp.sh >> /root/zwb/zwb_post/zwb_subscribe_temp.log
	echo "">> /root/zwb/zwb_post/zwb_subscribe_temp.log
	echo "">> /root/zwb/zwb_post/zwb_subscribe_temp.log
	echo "=======================" >> /root/zwb/zwb_post/zwb_subscribe_temp.log
done
}
main $*

