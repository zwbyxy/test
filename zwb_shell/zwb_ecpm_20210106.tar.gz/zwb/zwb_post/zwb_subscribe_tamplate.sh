curl -X  POST \
  http://10.254.1.2:19057/cy/internal/user/subscribe \
  -H 'Content-Type: application/json;charset=utf-8' \
  -H 'Connection: Keep-Alive' \
  -d '{
"productCode": "MDSP2000489466",
"userAccount": "€aaa",
"userAccountType": "0",
"channelId": "20"
}'
