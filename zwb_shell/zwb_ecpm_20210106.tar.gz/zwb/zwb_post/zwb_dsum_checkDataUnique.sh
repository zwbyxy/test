curl -X  POST \
  http://10.254.7.11:21000/dsum/commonServices/checkDataUnique \
  -H 'Content-Type: application/json;charset=utf-8' \
  -H 'Connection: Keep-Alive' \
  -d '{
"serviceType": 1,
"content": "国网河南省电力公司正阳县供电公司396"
}'
