curl -i -X POST    -H "Content-Type:application/json;charset=UTF-8"   -d '校验码'  'http://10.254.23.8:19031/sensitive/check'

