curl -X  POST \
  http://10.254.27.7:19025/rule/sync/setGroupMember \
  -H 'Content-Type: application/json;charset=utf-8' \
  -H 'Connection: Keep-Alive' \
  -d '{
"groupId": "01139_20200913221327aYur5W",
"msisdnList": ["18883197375"],
"actionType": 1
}'
