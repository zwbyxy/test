curl -H "Content-Type:application/json" -XPOST -d'{
	"groupId": "01134_20201130171639NEQjsp",
	"serviceId": "01134",
	"groupName": "",
	"groupType": "0",
	"userId": "",
	"parentGroup": "",
	"actionType": "2"
}' 'http://10.254.23.9:19025/rule/setGroup'

