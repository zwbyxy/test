#ecoding=utf-8
#print("测试")
class age():
	def __init__(self):
		self.__age=10
	def setAge(self,age_num):
		self.__age=age_num
	def getAge(self):
		return self.__age
	agex = proprety(getAge,setAge)
t=age()
print(t.getAge())
t.setAge(50)
print(t.getAge())

t.agex = 60
print(t.agex)
