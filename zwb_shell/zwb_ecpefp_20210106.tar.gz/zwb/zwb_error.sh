Date0=$(date +%Y-%m-%d)
cat $HOME/ecpfep_container/modules/ecpfep/logs/debug/interface.* |grep -E "$Date0"| grep DeliveryReq | grep end | awk -F"|"  '{print $2 "|" $8 "|" $9 "|" $12 "|" $13 "|" $14}' > Delivery.tmp

grep 'event=' Delivery.tmp |grep -v "status=4"|grep -v "status=3" |grep -E "$Date0" > error1.txt
grep -v 'status=119, msg' error1.txt |grep -v 'status=601, msg=template and hotline not match' >error1_other.txt
