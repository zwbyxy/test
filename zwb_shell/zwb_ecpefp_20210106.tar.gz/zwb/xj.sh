#!/bin/bash
echo "1、ecpfep 调用外部失败接口统计:"
Date=$(date +%Y-%m-%d)
grep "€€€RSP€€€"  /home/ecpfep/ecpfep_container/modules/ecpfep/logs/debug/feign.log* |grep "${Date}" |grep -v "RC00000000" |awk -F "€€€" '{print $10}'|sort -r |uniq -c

interface_name=`grep "€€€RSP€€€"  /home/ecpfep/ecpfep_container/modules/ecpfep/logs/debug/feign.log* |grep "${Date}" |grep -v "RC00000000" |awk -F "€€€" '{print $10}'|sort -r |uniq -c | awk '{print $2}'`
for i in $interface_name
do

grep "€€€RSP€€€"  /home/ecpfep/ecpfep_container/modules/ecpfep/logs/debug/feign.log* |grep "${Date}" |grep -v "RC00000000" |grep "${i}" |tail -n 5
echo "############"
done


echo "2、外部调用ecpfep失败接口统计:"
Date=$(date +%Y-%m-%d)
grep "€€€RSP€€€"  /home/ecpfep/ecpfep_container/modules/ecpfep/logs/debug/interface.log* |grep "${Date}" |grep -v "RC00000000" |awk -F "€€€" '{print $10}'|sort -r |uniq -c
interface_name=`grep "€€€RSP€€€"  /home/ecpfep/ecpfep_container/modules/ecpfep/logs/debug/interface.log* |grep "${Date}" |grep -v "RC00000000" |awk -F "€€€" '{print $10}'|sort -r |uniq -c | awk '{print $2}'`
for i in $interface_name
do

grep "€€€RSP€€€"  /home/ecpfep/ecpfep_container/modules/ecpfep/logs/debug/interface.log* |grep "${Date}" |grep -v "RC00000000" |grep "${i}" |tail -n 5
echo "############"
done
