curl -X POST \ 
  -H 'Content-Type: application/json;charset=utf-8' \
  -H 'Connection: Keep-Alive' \
-d '"header": {"platformid": "cmccbj", "timeStamp": 1593941711,   "sign": "d12becb9a5a9562e"  }, 
  "body": {   "msgtype": "4",   "src": "10658086",   "biztype": "1",  
   "notifyUrl": "http://211.136.64.6:19985/message/v1/MgjdNotifyMessage", 
     "content": [{     "target": "13897960714",   
       "template": "",  
        "argv": [""],     
        "callEvent": {     
         "callIdentifier": "FLASH20200705173438393111",   
           "scalling": "8613661123815",     
            "called": "8613897960714",     
             "direction": "MO",      "event": "Ringing",    
              "timeStamp": "2020-07-05T09:34:38.665Z"    
               } }]}' http://10.124.72.45:28080/ecpfep/deliveryServices/delivery
