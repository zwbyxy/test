#!/bin/bash
sum_count=`netstat -an | grep "^tcp" | grep ":28080" | wc -l`
if
[ ${sum_count} -gt 50 ];
then
echo "-------结束------" >> tcp_count.txt
datet=`date  "+%Y-%m-%d %H:%M:%S"`
echo "时间: ${datet}" >> tcp_count.txt
echo "前5连接数信息：">>tcp_count.txt
netstat -an |grep "^tcp" |grep ":28080" |awk -F "      " '{print $4}' |awk -F ":" '{print $1}' |sort -r |uniq -c |sort -rn -k1 |head -5 >> tcp_count.txt

echo "总连接数:${sum_count}">> tcp_count.txt
echo "-------结束------" >>tcp_count.txt
fi


#echo ${sum_count}
