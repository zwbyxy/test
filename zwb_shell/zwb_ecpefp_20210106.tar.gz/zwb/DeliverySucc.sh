#!/bin/bash
echo "#统计接口日志中消息投递成功率:"
#ecpfep用户下执行
User_start=`whoami`
Date0=$(date +%Y-%m-%d)
#Date1=$(date -d "-1 days" +"%Y-%m-%d")
#Date2=$(date -d "-2 days" +"%Y-%m-%d")
#Date3=$(date -d "-3 days" +"%Y-%m-%d")
#Date4=$(date -d "-4 days" +"%Y-%m-%d")
#Date5=$(date -d "-5 days" +"%Y-%m-%d")
#Date6=$(date -d "-6 days" +"%Y-%m-%d")
if [ $User_start = ecpfep ]
then
{

#创建存Delivery Req  Res 临时文件
if [ ! -f "Delivery.tmp" ]
then
        touch Delivery.tmp
else 
        rm -f Delivery.tmp
        touch Delivery.tmp
fi

#提取Delivery接口响应记录
#cat $HOME/ecpfep_container/modules/ecpfep/logs/debug/interface.* |grep -E "$Date0"| grep DeliveryReq |grep -v 54c6c8b5db9f45f987e367d14ef0ffee | grep "|end|" | awk -F"|"  '{print $2 "|" $8 "|" $9 "|" $12 "|" $13 "|" $14}' > Delivery.tmp
cat $HOME/ecpfep_container/modules/ecpfep/logs/debug/interface.* |grep "$Date0"| grep "€€€delivery€€€" |grep "€€€RSP€€€"  > Delivery.tmp


grep -v "status=4" Delivery.tmp |grep -v "status=3"|grep -v "status=6" | > error2.txt


echo "1、#统计Delivery.tmp中event=数,即总投递数:"
echo "Ecpfep Delivery  Total Number"
TotalNum=$(cat Delivery.tmp | wc -l)
echo $TotalNum
echo "2、#统计Delivery.tmp中status=4,|status=3数,即总成功投递数:"
echo "Ecpfep Delivery Success Number"
SucNum=$(grep -o -E "status=4,|status=3,|status=6," Delivery.tmp | wc -l)
echo $SucNum
echo -e "投递成功率: 0\c"
echo "scale = 2; $SucNum / $TotalNum" | bc

echo "请求投递失败返回码分布：数量	返回码	描述"

grep -v "status=4" Delivery.tmp |grep -v "status=3"|grep -v "status=6" | awk -F "status=" '{print $2}' |awk -F ", chargeNum=" '{print $1}' |sort  |uniq -c |sort -r


}
else
        echo "Unknown use" $User_start
fi
