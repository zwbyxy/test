#!/bin/bash
ip=`ifconfig  |grep "inet 10.124" |awk  '{print $2}'`
for i in `df -h |awk '{print $5"|"$6}' |grep -v Use`
do
diskspace=`echo $i|awk -F "%" '{print $1}'`
diskname=`echo $i| awk -F "|" '{print $2}' `
if [ ${diskspace} -gt 70  ]
then
echo "IP地址:${ip}的${diskname}硬盘空间为:${diskspace}%"
fi
done
