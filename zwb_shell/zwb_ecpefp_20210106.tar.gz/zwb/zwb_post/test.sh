#!/bin/bash
gj_list=(
50008225€57758121158€169122
50008225€57758121159€169135
50008225€57758121159€169135
50008225€57758121168€169121
50008225€57758121169€169125
50008225€57758121170€169139
50008225€57758121173€169117
50008225€57758121176€169134
50008225€57758121177€169124
50008225€57758121178€169113
50008225€57758121179€169142
50008225€57758121185€169120
50008225€57758121186€169110
50008225€57758121187€169114
50008225€57758121189€169127
50008225€57758121190€169133
50008225€57758121191€169116
50008225€57758121196€169109
50008225€57758189638€169115
50008227€57158619892€169144
50008229€57989907214€176832
50008229€57989987997€176831
)

main(){
for array in ${gj_list[*]}
do
	a=`echo ${array} |awk -F "€" '{print $1}'`
	b=`echo ${array} |awk -F "€" '{print $2}'`
	c=`echo ${array} |awk -F "€" '{print $3}'`
	#echo ${phone}
	#echo ${enterpriseID}
	cat  /home/ecpfep/zwb/zwb_post/2.txt > /home/ecpfep/zwb/zwb_post/2.sh
	sed -i "s#€a#${a}#g" /home/ecpfep/zwb/zwb_post/2.sh
	sed -i "s#€b#${b}#g" /home/ecpfep/zwb/zwb_post/2.sh
	sed -i "s#€c#${c}#g" /home/ecpfep/zwb/zwb_post/2.sh
	chmod 755 /home/ecpfep/zwb/zwb_post/2.sh
	echo "${a}|${b}|${c}执行结果:" >>  /home/ecpfep/zwb/zwb_post/2.log
	#sh /home/ecpfep/zwb/zwb_post/2.sh >> /home/ecpfep/zwb/zwb_post/2.log
	echo "=======================" >>/home/ecpfep/zwb/zwb_post/2.log
	echo "">> /home/ecpfep/zwb/zwb_post/2.log
	echo "">> /home/ecpfep/zwb/zwb_post/2.log
	
done
}
main $*
