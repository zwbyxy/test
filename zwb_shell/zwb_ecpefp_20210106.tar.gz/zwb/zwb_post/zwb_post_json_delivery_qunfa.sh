#!/bin/bash

for p in `cat ~/zwb/zwb_post/phone_list.txt`
do
cat ~/zwb/zwb_post/zwb_post_json_delivery_qunfa_temp.sh >  ~/zwb/zwb_post/zwb_post_json_delivery_qunfa_exec.sh 
sed -i "s/€a/${p}/g" ~/zwb/zwb_post/zwb_post_json_delivery_qunfa_exec.sh
chmod 755 ~/zwb/zwb_post/zwb_post_json_delivery_qunfa_exec.sh
sh ~/zwb/zwb_post/zwb_post_json_delivery_qunfa_exec.sh
sleep 0.05
done
