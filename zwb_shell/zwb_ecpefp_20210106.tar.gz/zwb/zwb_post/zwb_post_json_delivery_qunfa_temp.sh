#!/bin/bash

curl -X POST \
  http://10.124.72.45:28080/ecpfep/deliveryServices/delivery \
  -H 'Content-Type: application/json;charset=utf-8' \
  -H 'Connection: Keep-Alive' \
  -d '{	"header": {
         "platformid":"0066f1a81f504bb480c2e4a5f6d33f05",
        "timestamp":"1608535247",
        "sign":"ab66f7fc09a95ebc"
	},
	"body": {
		"biztype": "1",
		"src": "106580862711",
		"notifyurl": "http://10.124.52.40:22/cy/v2/deliveryresultnotification",
		"msgtype": "6",
		"content": [{
			"template": "575390",
			"callEvent": {
				"timeStamp": "2020-12-22T06:50:00.000+0800",
				"called": "€a",
				"callIdentifier": "15481€a",
				"scalling": "10086",
				"event": "IDP",
				"direction": "MO"
			},
			"argv": [],
			"target": "€a"
		}]
	}
}' >> ~/zwb/zwb_post/phone_result.log
