#!/bin/bash

function my_cmd(){
    tt=$1
    t=$RANDOM
    t=$[t%15]
    sleep $t
    echo "sleep $t s $tt"
}

gj_list=(
500096
500097
500098
500099
500100
500101
500102
500103
500104
500105
500106
500107
500108
500109
500110
500111
500112
500113
500114
500115
500116
500117
500118
500119
500120
500121
500122
500123
500124
500125
500126
500127
500128
500129
500130
500131
500132
500133
500134
500135
500136
500137
500138
500139
500140
500141
500142
500143
500144
500145
500146
500147
500148
500149
500150
500151
500152
500153
500154
500155
500156
500157
500158
500159
500160
500161
500162
500163
500164
500165
500166
500167
500168
500169
500170
500171
500172
500173
500174
500175
500176
500177
500178
500179
500180
500181
500182
500183
500184
500185
500186
500187
500188
500189
500190
500191
500192
500193
500194
500195
)

tmp_fifofile="/tmp/$$.fifo"
mkfifo $tmp_fifofile      # 新建一个fifo类型的文件
exec 6<>$tmp_fifofile     # 将fd6指向fifo类型
rm $tmp_fifofile    #删也可以

thread_num=3  # 最大可同时执行线程数量
job_num=30   # 任务总数(具体的循环参数,可以根据应用获取需要的参数)

#根据线程总数量设置令牌个数
for ((i=0;i<${thread_num};i++));do
    echo
done >&6

#for ((i=0;i<${job_num};i++));do # 任务数量
for  array in ${gj_list[*]}
do 
    # 一个read -u6命令执行一次，就从fd6中减去一个回车符，然后向下执行，
    # fd6中没有回车符的时候，就停在这了，从而实现了线程数量控制
    read -u6

        phone=`echo ${array} |awk -F "€" '{print $1}'`
    #可以把具体的需要执行的命令封装成一个函数
        {
#                my_cmd ${job_num}
#	./zwb_post_json_querytemplate.sh
#        my_cmd ${phone}
	cp -rp zwb_post_json_querytemplate_temp.sh ./temp/zwb_post_json_querytemplate_${phone}.sh
	sed -i "s#€a#${phone}#g" ./temp/zwb_post_json_querytemplate_${phone}.sh
	sh ./temp/zwb_post_json_querytemplate_${phone}.sh
	rm  ./temp/zwb_post_json_querytemplate_${phone}.sh
        } &
    echo >&6 # 当进程结束以后，再向fd6中加上一个回车符，即补上了read -u6减去的那个
#done
done
wait
exec 6>&- # 关闭fd6
echo "over"
