curl -X POST \
  http://10.124.72.45:28080/ecpfep/provincialEnterprises/syncMember \
  -H 'Content-Type: application/xml' \
  -H 'SessionId: 44C05255C0924AE157EB64685A289A' \
  -H 'TimeStamp: 20160317135652053' \
  -H 'Connection: Keep-Alive' \
  -H 'x-Source: 4' \
  -H 'Version: 1' \
  -H 'AccessCode: utf-8' \
  -H 'Signature: 083ce3e0cd4fcbfa' \
  -d '
<Request>
  <transactionID>53920201215144400</transactionID>
  <memberList>
    <MemberInfo>
      <msisdn>13869770841</msisdn>
      <status>1</status>
      <msisdnType>1</msisdnType>
    </MemberInfo>
  </memberList>
  <corpID>5308038620336</corpID>
  <operationType>2</operationType>
</Request>
' 
