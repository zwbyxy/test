curl -X POST \
  http://61.152.146.66:8089/wwdxpt/servlet/SxServlet?action=callBack_dx \
  -H 'Content-Type: application/json;charset=utf-8' \
  -H 'Connection: Keep-Alive' \
  -d '{"body":{"deliveryresult":[{"chargeNum":1,"msg":"The flashSM_delivery succeed","status":"1","target":"8619821034063"}],"taskid":"20200000901481794"},"header":{"platformid":"84abf02817484701be133b2b04cf99ef","sign":"86c5f983cf6846cb","timestamp":1601019887063}}'
