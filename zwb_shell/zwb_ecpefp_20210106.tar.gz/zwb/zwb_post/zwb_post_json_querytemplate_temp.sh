curl -X POST \
  http://10.124.72.45:28080/ecpfep/templateServices/querytemplate \
  -H 'Content-Type: application/json;charset=utf-8' \
  -H 'Connection: Keep-Alive' \
  -d '{
        "header":{
        "platformid":"d3a8e5ddb4a6440b898243dc5dd77a45",
        "timestamp":"1548338667",
        "sign":"5c25542e1d8fe30e"
        },
        "body":{
                "templateid":"€a"
        }
}'
