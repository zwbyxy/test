curl -X POST \
  http://10.124.72.45:28080/ecpfep/enterpriseServices/businessOrderAccept \
  -H 'Content-Type: application/json;charset=utf-8' \
  -H 'Connection: Keep-Alive' \
  -d '{
	"header": {
		"platformid":"879d5d4f332a433cbc580fc32b9f7f72",
		"timestamp":"1548338667",
		"sign":"34e6d5df8168fdb9"
		},
	"body": {
			"custID": "CSR103798",
			"servType": "2",
			"resType": "11"
			}
}'
