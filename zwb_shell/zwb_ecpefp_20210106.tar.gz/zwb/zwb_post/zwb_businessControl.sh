#!/bin/bash
gj_list=(
111111
CSR104138
CSR101584
CSR104082
CSR104338
CSR101957
CSR104218
CSR104265
CSR104305
CSR104316
CSR104107
CSR104428
CSR104358
CSR0104615
CSR0104616
CSR104665
34234
CSR0104618
CSR0104541
CSR0104620
CSR100901
CSR0104623
CSR0104624
CSR0104563
CSR102326
CSR0104629
CSR0104630
CSR0104583
CSR104452
CSR0104605
CSR0104632
)
main(){
for array in ${gj_list[*]}
do
        phone=`echo ${array} |awk -F "€" '{print $1}'`
#       enterpriseID=`echo ${array} |awk -F "€" '{print $2}'`
        #echo ${phone}
        #echo ${enterpriseID}
        cat   /home/ecpfep/zwb/zwb_post/zwb_businessControl_tamplate.sh > /home/ecpfep/zwb/zwb_post/zwb_businessControl_temp.sh
        sed -i "s#€aaa#${phone}#g" /home/ecpfep/zwb/zwb_post/zwb_businessControl_temp.sh
#       sed -i "s#€bbb#${enterpriseID}#g" /home/ecpfep/zwb/zwb_post/zwb_businessControl_temp.sh
        chmod 755 /home/ecpfep/zwb/zwb_post/zwb_businessControl_temp.sh
        echo "${phone}执行结果:" >> /home/ecpfep/zwb/zwb_post/zwb_businessControl_temp.log
       sh /home/ecpfep/zwb/zwb_post/zwb_businessControl_temp.sh >> /home/ecpfep/zwb/zwb_post/zwb_businessControl_temp.log
        echo "">> /home/ecpfep/zwb/zwb_post/zwb_businessControl_temp.log
        echo "">> /home/ecpfep/zwb/zwb_post/zwb_businessControl_temp.log
        echo "=======================" >> /home/ecpfep/zwb/zwb_post/zwb_businessControl_temp.log
        sleep 120
done
}
main $*
