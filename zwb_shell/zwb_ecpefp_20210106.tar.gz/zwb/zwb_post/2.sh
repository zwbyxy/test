curl -X POST \
  http://10.124.73.12:18903/ecpm/organizationServices/createMember \
  -H 'Content-Type: application/json;charset=utf-8' \
  -H 'token: 29862a4f-9255-42e3-8cce-0cae9fbb3517' \
  -H 'x-Source: 1' \
  -H 'Connection: Keep-Alive' \
  -d '{
        "enterpriseID": 50008229,
        "extension": {
                "platformid": "1"
        },
        "memberList": [{
                "ecpmReserveds": {
                        "reserved2": "3"
                },
                "memberName": "57989987997",
                "msisdn": "57989987997",
                "operatorID": 1000
        }],
        "orgID": 176831,
        "servType": 5
}'
