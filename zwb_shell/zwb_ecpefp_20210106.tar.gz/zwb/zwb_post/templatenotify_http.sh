curl -X  POST \
  http://47.95.43.236/mgtemplatenotice/receive.do \
  -H 'Content-Type: application/json;charset=utf-8' \
  -H 'Connection: Keep-Alive' \
  -d '{"body":{"templateid":"572412","auditresult":"1","audittime":"20200813112013","auditdesc":"涉及敏感行业需要协议及内容涉及营销"},"header":{"platformid":"9394ce1043f042649eea073172ea9c12","sign":"345728b8b659b8c6","timestamp":1597289840140}}'
