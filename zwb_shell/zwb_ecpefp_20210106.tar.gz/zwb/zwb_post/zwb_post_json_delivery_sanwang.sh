curl -X POST \
  http://10.124.72.45:28080/ecpfep/deliveryServices/delivery \
  -H 'Content-Type: application/json;charset=utf-8' \
  -H 'Connection: Keep-Alive' \
  -d '{ "header": {
         "platformid":"48c5f66850fe499db59c79f2b01ce859",
        "timestamp":"1548338667",
        "sign":"b0283f0af97bc142"
        },
        "body": {
                "biztype": "1",
                "src": "10658086",
                "notifyurl": "http://10.124.129.175:28080/cy/v2/deliveryresultnotification",
                "msgtype": "5",
                "content": [{
                        "template": "536926",
                        "callEvent": {
                                "timeStamp": "2019-01-24T10:08:26.323+0800",
                                "called": "15280017653",
                                "callIdentifier": "1548122906",
                                "scalling": "15280017653",
                                "event": "IDP",
                                "direction": "MO"
                        },
                        "argv": [],
                        "target": "15280017653"
                }]
        }
}'
