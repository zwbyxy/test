curl -X POST \
  http://10.124.72.45:28080/ecpfep/deliveryServices/delivery \
  -H 'Content-Type: application/json;charset=utf-8' \
  -H 'Connection: Keep-Alive' \
  -d '{	"header": {
         "platformid":"879d5d4f332a433cbc580fc32b9f7f72",
        "timestamp":"1548338667",
        "sign":"34e6d5df8168fdb9"
	},
	"body": {
		"biztype": "1",
		"src": "10658086",
		"notifyurl": "http://10.124.129.175:28080/cy/v2/deliveryresultnotification",
		"msgtype": "6",
		"content": [{
			"template": "502495",
			"callEvent": {
				"timeStamp": "2019-01-24T10:08:26.323+0800",
				"called": "15280017653",
				"callIdentifier": "1548122906",
				"scalling": "123123",
				"event": "IDP",
				"direction": "MO"
			},
			"argv": [],
			"target": "15280017653"
		}]
	}
}'
