curl -X POST \
  http://10.124.72.45:28080/ecpfep/provincialEnterprises/serviceSubscribe \
  -H 'Content-Type: application/xml' \
  -H 'SessionId: 44C05255C0924AE157EB64685A289A' \
  -H 'TimeStamp: 20160317135652053' \
  -H 'Connection: Keep-Alive' \
  -H 'x-Source: 4' \
  -H 'Version: 1' \
  -H 'AccessCode: utf-8' \
  -H 'Signature: 083ce3e0cd4fcbfa' \
  -d '
<Request>
	<transactionID>2020121550081976</transactionID>
                <corpID>6358035569763</corpID>
                <oprDate>20201215170000</oprDate>
		<servType>1</servType>
		<subServType>2</subServType>
                <oprType>2</oprType>
                <chargeMsisdn>13806316372</chargeMsisdn>
	<operatorType>100</operatorType>
</Request>
' 
