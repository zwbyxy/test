curl -X POST \
  http://10.124.72.45:28080/ecpfep/provincialEnterprises/serviceSubscribe \
  -H 'Content-Type: application/xml' \
  -H 'SessionId: 44C05255C0924AE157EB64685A289A' \
  -H 'TimeStamp: 20160317135652053' \
  -H 'Connection: Keep-Alive' \
  -H 'x-Source: 4' \
  -H 'Version: 1' \
  -H 'AccessCode: utf-8' \
  -H 'Signature: 083ce3e0cd4fcbfa' \
  -d '<?xml version="1.0" encoding="UTF-8"?>
<Request>
		<transactionID>67102007301725smfyoq</transactionID>
		<corpID>5712007201644eopiwn</corpID>
		<oprDate>20200730172507</oprDate>
		<servType>1</servType>
		<subServType>2</subServType>		
		<oprType>1</oprType>
		<effectiveTime>20200730172114</effectiveTime>
		<expireTime>20991231235959</expireTime>
		<chargeMsisdn>334602</chargeMsisdn>
  		<operatorType>100</operatorType>
</Request>'

