curl -k POST \
  https://o2i.vibeac.com/ussdService/ussd/templatenotify \
  -H 'Content-Type: application/json;charset=utf-8' \
  -H 'Connection: Keep-Alive' \
  -d '{"body":{"templateid":"538278","auditresult":"0","contentType":1,"audittime":"20200408143158"},"header":{"platformid":"8f4dc5d113384b93a828c329057f19b8","sign":"3e9167f149a3d67e","timestamp":1586338532294}}'
