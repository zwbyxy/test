curl -X POST \
  http://121.201.18.83:18081/mgdm2/back/nfjd/mgdmrp \
  -H 'Content-Type: application/json;charset=utf-8' \
  -H 'Connection: Keep-Alive' \
  -d '{"body":{"deliveryresult":[{"chargeNum":1,"msg":"The flashSM_delivery succeed","status":"1","target":"15889651923"}],"taskid":"20200000918562175"},"header":{"platformid":"923e5cf64182406db963afc45d331a59","sign":"89bdca2e49056d53","timestamp":1589875229681}}'
