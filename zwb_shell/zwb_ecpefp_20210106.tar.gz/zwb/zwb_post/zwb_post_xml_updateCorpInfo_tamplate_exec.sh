curl -X POST \
  http://10.124.72.45:28080/ecpfep/provincialEnterprises/updateCorpInfo \
  -H 'Content-Type: application/xml' \
  -H 'SessionId: 44C05255C0924AE157EB64685A289A' \
  -H 'TimeStamp: 20160317135652053' \
  -H 'Connection: Keep-Alive' \
  -H 'x-Source: 4' \
  -H 'Version: 1' \
  -H 'AccessCode: utf-8' \
  -H 'Signature: 083ce3e0cd4fcbfa' \
  -d '
<Request>
  <transactionID>20201215181050048717</transactionID>
  <corpID>5318064191478</corpID>
  <updateType>2</updateType>
  <corpName>商业楼宇-中泰大厦-好孩子中国商贸有限公司济南分公司</corpName>
  <corpPhone>11111111111</corpPhone>
  <createDate>20200728</createDate>
  <locationid>531</locationid>
  <loginName>5318064191478</loginName>
  <extensionInfo>
    <NamedParameter>
      <key>Source</key>
      <value>01</value>
    </NamedParameter>
    <NamedParameter>
      <key>channelSrc</key>
      <value>15</value>
    </NamedParameter>
  </extensionInfo>
</Request>
'
