curl -X POST \
  http://10.124.72.45:28080/ecpfep/hotlineServices/synctemphotline \
  -H 'Content-Type: application/json;charset=utf-8' \
  -H 'Connection: Keep-Alive' \
  -d '{ "header": {
         "platformid":"84c19237b85248f8a2f9dd04585827a4",
        "timestamp":"1548338667",
        "sign":"2657a49cb92d3c63"
        },
        "body": {
                "actiontype": "0",
                "hotlines": ["02029197387"],
                "templateid": "573946"
        }
      }'
