curl -X  POST \
  http://10.124.72.45:28080/ecpfep/enterpriseServices/businessControl \
  -H 'Content-Type: application/json;charset=utf-8' \
  -H 'Connection: Keep-Alive' \
  -d '{
"header": {
        "platformid":"3c4485e1347349be92d489e975805650",
        "timestamp":"1601364526567",
        "sign":"02763417ccc2efad"          
        },
"body": {
               "custID": "CSR103632",
               "businessStatus": "0",
               "controlReason": "启用"
}
}'
