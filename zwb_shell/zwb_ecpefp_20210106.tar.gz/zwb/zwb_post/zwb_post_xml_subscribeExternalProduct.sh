curl -X POST \
  http://10.124.72.45:28080/ecpfep/provincialEnterprises/subscribeExternalProduct \
  -H 'Content-Type: application/xml' \
  -H 'SessionId: 44C05255C0924AE157EB64685A289A' \
  -H 'TimeStamp: 20160317135652053' \
  -H 'Connection: Keep-Alive' \
  -H 'x-Source: 4' \
  -H 'Version: 1' \
  -H 'AccessCode: utf-8' \
  -H 'Signature: 083ce3e0cd4fcbfa' \
  -d '
<subscribeExternalProductReq>
		<transactionID>202008241820</transactionID>
		<orgExtCode>MobileMP18040001263607</orgExtCode>
		<msisdn>13033921122</msisdn>
		<externalProID>29602617</externalProID>
		<externalProPortal>1</externalProPortal>
		<effectiveTime>20201214</effectiveTime>
		<expiryTime>20201231</expiryTime>
		<extensionInfo></extensionInfo>
</subscribeExternalProductReq>
' 
