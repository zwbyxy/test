#!/bin/bash
gj_list=(
50013683€5318063904986€临街商铺-十亩园街-静逸轩茗茶€531€5318063904986
50013814€5318063905064€临街商铺-十亩园街-社区卫生服务€531€5318063905064
50013822€5318063905126€临街商铺-十亩园街-康雅齿科€531€5318063905126
50013830€5318063905182€临街商铺-十亩园街-伊勒鞋屋€531€5318063905182
50012567€5318063905333€临街商铺-十亩园街-孟鑫超市€531€5318063905333
50063483€5318063987656€行业聚类-时代总部基地-济南今日摄影器材有限公司一部€531€5318063987656
50020998€5318064062971€行业聚类-水屯装饰材料市场-济南桑拿板木方防腐木€531€5318064062971
50021012€5318064063195€行业聚类-水屯装饰材料市场-济南桑拿板木方防腐木€531€5318064063195
50021014€5318064063229€行业聚类-水屯装饰材料市场-济南桑拿板木方防腐木€531€5318064063229
50020847€5318064223635€临街商铺-按察司街-目拖誓贪€531€5318064223635
50016259€5318064287710€行业聚类-新坊巷-MAKAYLAboutique€531€5318064287710
50028345€5318064764320€行业聚类-秀水街-BlingBling€531€5318064764320
50048717€5318064191478€商业楼宇-中泰大厦-好孩子中国商贸有限公司济南分公司€531€5318064191478
)

main(){
for array in ${gj_list[*]}
do
        a=`echo ${array} |awk -F "€" '{print $1}'`
        b=`echo ${array} |awk -F "€" '{print $2}'`
        c=`echo ${array} |awk -F "€" '{print $3}'`
        d=`echo ${array} |awk -F "€" '{print $4}'`
        e=`echo ${array} |awk -F "€" '{print $5}'`
        cat  /home/ecpfep/zwb/zwb_post/zwb_post_xml_updateCorpInfo_tamplate.sh > /home/ecpfep/zwb/zwb_post/zwb_post_xml_updateCorpInfo_tamplate_exec.sh
        sed -i "s#€aaa#${a}#g" /home/ecpfep/zwb/zwb_post/zwb_post_xml_updateCorpInfo_tamplate_exec.sh
        sed -i "s#€bbb#${b}#g" /home/ecpfep/zwb/zwb_post/zwb_post_xml_updateCorpInfo_tamplate_exec.sh
        sed -i "s#€ccc#${c}#g" /home/ecpfep/zwb/zwb_post/zwb_post_xml_updateCorpInfo_tamplate_exec.sh
        sed -i "s#€ddd#${d}#g" /home/ecpfep/zwb/zwb_post/zwb_post_xml_updateCorpInfo_tamplate_exec.sh
        sed -i "s#€eee#${e}#g" /home/ecpfep/zwb/zwb_post/zwb_post_xml_updateCorpInfo_tamplate_exec.sh
        chmod 755 /home/ecpfep/zwb/zwb_post/zwb_post_xml_updateCorpInfo_tamplate_exec.sh
        echo "${a}|${b}|${c}执行结果:" >>  /home/ecpfep/zwb/zwb_post/zwb_post_xml_updateCorpInfo_tamplate_exec.log
        sh /home/ecpfep/zwb/zwb_post/zwb_post_xml_updateCorpInfo_tamplate_exec.sh >> /home/ecpfep/zwb/zwb_post/zwb_post_xml_updateCorpInfo_tamplate_exec.log
        echo "=======================" >>/home/ecpfep/zwb/zwb_post/zwb_post_xml_updateCorpInfo_tamplate_exec.log
        echo "">> /home/ecpfep/zwb/zwb_post/zwb_post_xml_updateCorpInfo_tamplate_exec.log
        echo "">> /home/ecpfep/zwb/zwb_post/zwb_post_xml_updateCorpInfo_tamplate_exec.log
sleep 1
done
}
main $*
