
echo ''> zwb_ecpfep_xunjian_result.txt
echo "ECPFEP 巡检01：" >>zwb_ecpfep_xunjian_result.txt
echo "1、空闲内存检查:(标准：如果free内存、buffers内存与cached内存的总和不足1GB，则系统已经处于较为危险的情况了)" >> zwb_ecpfep_xunjian_result.txt
free -m >>zwb_ecpfep_xunjian_result.txt

echo "2.系统IO占用:(标准：%util如果持续超过70%，则表明当前节点的IO使用过高)" >> zwb_ecpfep_xunjian_result.txt
iostat -d -x -k 1 5 >>zwb_ecpfep_xunjian_result.txt

echo "3.系统CPU占用:(标准：CPU Idle值>50%)" >> zwb_ecpfep_xunjian_result.txt
vmstat 2 10 >>zwb_ecpfep_xunjian_result.txt


echo "4.磁盘空间占用率:(标准：各文件系统的使用率不应超过85％)" >> zwb_ecpfep_xunjian_result.txt
df -h >> zwb_ecpfep_xunjian_result.txt

echo "5.应用进程检查:(标准：有一个ecpfep java进程)" >> zwb_ecpfep_xunjian_result.txt
ps -ef | grep java | grep ecpfep/lib | grep -v grep  >> zwb_ecpfep_xunjian_result.txt

echo "6.检查启动日志:(标准：无异常报错)" >> zwb_ecpfep_xunjian_result.txt
cat $HOME/ecpfep_container/modules/ecpfep/logs/server/server.out | grep `date "+%Y-%m-%d"` |grep "ERROR" >> zwb_ecpfep_xunjian_result.txt


echo "7.检查业务日志:(标准：无异常报错)" >> zwb_ecpfep_xunjian_result.txt
cat $HOME/ecpfep_container/modules/ecpfep/logs/debug/debug.log |grep `date "+%Y-%m-%d"` | grep "ERROR"  >> zwb_ecpfep_xunjian_result.txt

echo "8.检查gc日志:(标准：10分钟内的full gc次数小于1)" >> zwb_ecpfep_xunjian_result.txt
tail -n 10 $HOME/ecpfep_container/modules/ecpfep/logs/gc.log.0.current   >> zwb_ecpfep_xunjian_result.txt

./DeliverySucc.sh >>zwb_ecpfep_xunjian_result.txt
