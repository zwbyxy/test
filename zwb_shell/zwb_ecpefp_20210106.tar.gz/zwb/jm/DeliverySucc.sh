#!/bin/sh
echo "#统计接口日志中消息投递成功率:"
#ecpfep用户下执行
User_start=`whoami`
Date0=$(date +%Y-%m-%d)
#Date1=$(date -d "-1 days" +"%Y-%m-%d")
#Date2=$(date -d "-2 days" +"%Y-%m-%d")
#Date3=$(date -d "-3 days" +"%Y-%m-%d")
#Date4=$(date -d "-4 days" +"%Y-%m-%d")
#Date5=$(date -d "-5 days" +"%Y-%m-%d")
#Date6=$(date -d "-6 days" +"%Y-%m-%d")
if [ $User_start = ecpfep ]
then
{

#创建存Delivery Req  Res 临时文件
if [ ! -f "Delivery.tmp" ]
then
        touch Delivery.tmp
else 
        rm -f Delivery.tmp
        touch Delivery.tmp
fi

#提取Delivery接口响应记录
cat $HOME/ecpfep_container/modules/ecpfep/logs/debug/interface.* |grep -E "$Date0"| grep DeliveryReq | grep end | awk -F"|"  '{print $2 "|" $8 "|" $9 "|" $12 "|" $13 "|" $14}' > Delivery.tmp

grep 'event=' Delivery.tmp |grep -v "status=4"|grep -v "status=3" |grep -E "$Date0" > error2.txt
grep -v 'status=119, msg' error2.txt |grep -v 'status=601, msg=template and hotline not match' >error2_other.txt


echo "1、#统计Delivery.tmp中event=数,即总投递数:"
echo "Ecpfep Delivery  Total Number"
TotalNum=$(grep -o 'event=' Delivery.tmp | wc -l)
echo $TotalNum
echo "2、#统计Delivery.tmp中status=4,|status=3数,即总成功投递数:"
echo "Ecpfep Delivery Success Number"
SucNum=$(grep -o -E "status=4,|status=3," Delivery.tmp | wc -l)
echo $SucNum
echo -e "Success rate 0\c"
echo "scale = 2; $SucNum / $TotalNum" | bc
#rm -f Delivery.tmp
cat Delivery.tmp  |awk -F "msgtype=" '{print $2}' |awk -F "," '{print $1}' |sort |uniq -c >msgtype_all_count.txt
grep  "status=4,\|status=3,"  Delivery.tmp |awk -F "msgtype=" '{print $2}' |awk -F "," '{print $1}' |sort |uniq -c   >msgtype_succ_count.txt
grep -v "status=4," Delivery.tmp |grep -v "status=3,"  |awk -F "msgtype=" '{print $2}' |awk -F "," '{print $1}' |sort |uniq -c   >msgtype_error_count.txt
echo "3、总投递数分类统计："
cat msgtype_all_count.txt |awk -F " " '{if ($2 == 1) print "msgtype=1：使用通知式USSD发送，总量："  $1 ; if ($2 == 2) print "msgtype=2：使用闪信发送，总量："  $1 ; if ($2 == 3) print "msgtype=3：通知式USSD投递失败时改由闪信投递，总量："  $1 ; if ($2 == 4) print "msgtype=4：使用闪信发送，需要回执结果，总量："  $1 ; if ($2 == 5) print "msgtype=5：通知式USSD投递失败时改由闪信投递，需要回执结果，总量："  $1 ; if ($2 == 8) print "msgtype=8：使用通知式USSD发送(无域查询)，总量："  $1  }'


echo "4、成功投递数分类统计："
cat msgtype_succ_count.txt |awk -F " " '{if ($2 == 1) print "msgtype=1：使用通知式USSD发送，成功量："  $1 ; if ($2 == 2) print "msgtype=2：使用闪信发送，成功量："  $1 ; if ($2 == 3) print "msgtype=3：通知式USSD投递失败时改由闪信投递，成功量："  $1 ; if ($2 == 4) print "msgtype=4：使用闪信发送，需要回执结果，成功量："  $1 ; if ($2 == 5) print "msgtype=5：通知式USSD投递失败时改由闪信投递，需要回执结果，成功量："  $1 ; if ($2 == 8) print "msgtype=8：使用通知式USSD发送(无域查询)，成功量："  $1  }'

echo "5、失败投递数分类统计："
cat msgtype_error_count.txt |awk -F " " '{if ($2 == 1) print "msgtype=1：使用通知式USSD发送，失败量："  $1 ; if ($2 == 2) print "msgtype=2：使用闪信发送，失败量："  $1 ; if ($2 == 3) print "msgtype=3：通知式USSD投递失败时改由闪信投递，失败量："  $1 ; if ($2 == 4) print "msgtype=4：使用闪信发送，需要回执结果，失败量："  $1 ; if ($2 == 5) print "msgtype=5：通知式USSD投递失败时改由闪信投递，需要回执结果，失败量："  $1 ; if ($2 == 8) print "msgtype=8：使用通知式USSD发送(无域查询)，失败量："  $1  }'



}
else
        echo "Unknown use" $User_start
fi
