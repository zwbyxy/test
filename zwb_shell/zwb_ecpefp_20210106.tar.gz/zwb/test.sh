#!/bin/bash
#物理cpu个数
wlcpu=`grep "physical id" /proc/cpuinfo|sort -u|wc -l`
#cpu核数
cpucount=`grep "cpu cores" /proc/cpuinfo|uniq |awk -F ":" '{print $2}'|awk '{print $1}'`
#5分钟负载
min_5=`uptime | awk -F "average:" '{print $2}' |awk -F "," '{print $1}' |awk '{print $1}'`
echo "wlcpu:${wlcpu}"
echo "cpucount:${cpucount}"
echo "min_5:${min_5}"
b=`echo "sacle=3;${wlcpu}*${cpucount}*0.7" |bc`
echo $b

if [ `expr ${min_5}  \> $b` -eq 0  ]
 then
echo "zwbfzzc负载正常，5分钟平均负载:${min_5},小于最大负载:${b}"
else 
echo "zwbfzyc超出最大负载，5分钟平均负载:${min_5},小于最大负载:${b}"
fi
