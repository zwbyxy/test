
#echo "1、------------------------当天接口统计：---------------------"
#cat /home/ecpfep/ecpfep_container/modules/ecpfep/logs/debug/interface.log* |grep `date +%Y-%m-%d` |grep "|end|" | awk -F "|" '{print $6}' |sort -r |uniq -c
#echo ""
#echo ""
#echo ""
#echo "2、----------------------最新日志接口统计------------------"
#cat /home/ecpfep/ecpfep_container/modules/ecpfep/logs/debug/interface.log |grep `date +%Y-%m-%d` |grep "|end|" | awk -F "|" '{print $6}' |sort -r |uniq -c

#echo ""
#echo ""
#echo ""


echo "3、------------------当天接口平均耗时---------------"
##接口名称##cat interface.log* |grep `date +%Y-%m-%d` |grep "|end|" | awk -F "|" '{print $6}' |sort -r |uniq -c |awk -F " " '{print $2}' > interface.tmp

date=`date +%Y-%m-%d`
 interface_name=`cat /home/ecpfep/ecpfep_container/modules/ecpfep/logs/debug/interface.log* |grep $date |grep "€€€RSP€€€" | awk -F "€€€" '{print $10}' |sort -r |uniq -c |awk -F " " '{print $2}'`
for i in $interface_name
do

##平均耗时统计

all_costime=`grep $i /home/ecpfep/ecpfep_container/modules/ecpfep/logs/debug/interface.log* |grep $date |grep "€€€RSP€€€" |awk -F '€€€' '{print $15}'`

all_costs=`grep $i /home/ecpfep/ecpfep_container/modules/ecpfep/logs/debug/interface.log* |grep $date | grep "€€€RSP€€€" |awk -F '€€€' '{print $15}' |wc -l`
sum=0
for s in $all_costime
do
sum=$(($sum+$s))

done
#echo $sum
##
ss=$(($sum / $all_costs))
echo "$i当天接口平均耗时： $ss ms"
##echo  " scale = 2;$sum / $all_costs" |bc  

done


echo ""
echo ""
echo ""

echo "4、------------------最新日志接口平均耗时---------------"
##接口名称##cat interface.log* |grep `date +%Y-%m-%d` |grep "|end|" | awk -F "|" '{print $6}' |sort -r |uniq -c |awk -F " " '{print $2}' > interface.tmp

date=`date +%Y-%m-%d`
 interface_name=`cat /home/ecpfep/ecpfep_container/modules/ecpfep/logs/debug/interface.log |grep $date |grep "€€€RSP€€€" | awk -F "€€€" '{print $10}' |sort -r |uniq -c |awk -F " " '{print $2}'`
for i in $interface_name
do

##平均耗时统计

all_costime=`grep $i /home/ecpfep/ecpfep_container/modules/ecpfep/logs/debug/interface.log |grep $date |grep "€€€RSP€€€" |awk -F '€€€' '{print $15}'`

all_costs=`grep $i /home/ecpfep/ecpfep_container/modules/ecpfep/logs/debug/interface.log |grep $date |grep "€€€RSP€€€" |awk -F '€€€' '{print $15}'|wc -l`
sum=0
for s in $all_costime
do
sum=$(($sum+$s))

done
#echo $sum
##
ss=$(($sum / $all_costs))
echo "$i当天接口平均耗时： $ss ms"
##echo  " scale = 2;$sum / $all_costs" |bc  

done

echo ""
echo ""
echo ""

echo "4、------------------当天耗时大于3000ms日志信息---------------"
cat /home/ecpfep/ecpfep_container/modules/ecpfep/logs/debug/interface.log* |grep `date +%Y-%m-%d` |grep "€€€RSP€€€" |grep -v grep -v "http://10.124.129.175:28080/cy/v2/deliveryresultnotification" |awk -F "€€€" '{if ($15>3000) print $10 }' |sort |uniq -c 
cat /home/ecpfep/ecpfep_container/modules/ecpfep/logs/debug/interface.log* |grep `date +%Y-%m-%d` |grep "|end|" |grep -v "http://10.124.129.175:28080/cy/v2/deliveryresultnotification" |awk -F "|" '{if ($15>3000) print $0 }' |tail -n 50 

echo ""
echo ""
echo ""

echo "5、------------------当天错误日志信息---------------"
cat /home/ecpfep/ecpfep_container/modules/ecpfep/logs/debug/interface.log* |grep `date +%Y-%m-%d` |grep "|end|"  |grep -v " resultDesc=Successfully" |grep -v "resultCode=1020100000" |grep -v "Delivery request successfully received"  |grep -v "The flashSM has been submitted to the gateway" |grep -v "http://10.124.129.175:28080/cy/v2/deliveryresultnotification" |grep -v "transactionID not exist" |grep -v "resultCode=1010100000," |tail -n 90
echo ""
echo ""
echo ""

echo "6、------------------最新错误日志信息---------------"

cat /home/ecpfep/ecpfep_container/modules/ecpfep/logs/debug/interface.log |grep `date +%Y-%m-%d` |grep "|end|"  |grep -v " resultDesc=Successfully" |grep -v "resultCode=1020100000" |grep -v "Delivery request successfully received"  |grep -v "The flashSM has been submitted to the gateway" |grep -v "http://10.124.129.175:28080/cy/v2/deliveryresultnotification" |grep -v "transactionID not exist"  |grep -v "resultCode=1010100000," |tail -n 60

