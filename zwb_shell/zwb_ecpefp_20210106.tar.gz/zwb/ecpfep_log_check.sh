#!/bin/bash
 now_date=`date  +"%Y-%m-%d %H:%M"`
 now_date_1minbefor=`date -d "1 minute ago" +"%Y-%m-%d %H:%M"`
 now_date_2minbefor=`date -d "2 minute ago" +"%Y-%m-%d %H:%M"`
 now_date_3minbefor=`date -d "3 minute ago" +"%Y-%m-%d %H:%M"`
 now_date_4minbefor=`date -d "4 minute ago" +"%Y-%m-%d %H:%M"`
grep "${now_date}\|${now_date_1minbefor}\|${now_date_2minbefor}\|${now_date_3minbefor}\|${now_date_4minbefor}" /home/ecpfep/ecpfep_container/modules/ecpfep/logs/debug/interface.log > /home/ecpfep/zwb/temp/interface_all_temp.txt

grep "deliveryResultNotify|end|" /home/ecpfep/zwb/temp/interface_all_temp.txt |grep -v "resultCode=0" | awk -F "taskID=" '{print $2}' |awk -F "notifyURL=" '{print $1","$2}' |awk -F "resultCode=" '{print $1","$2}' |awk -F "resultDesc=" '{print $1","$2}' |awk -F "," '{print $1"|"$3"|"$8"|"$9"|"$13"|"$15}' |awk -F "))" '{print $1}' > /home/ecpfep/zwb/temp/interface_error_deliveryResultNotify_temp.txt
cat  /home/ecpfep/zwb/temp/interface_error_deliveryResultNotify_temp.txt |awk -F "|" '{print $3}' |sort -r |uniq -c > /home/ecpfep/zwb/temp/interface_error_deliveryResultNotify.txt
for i in `cat /home/ecpfep/zwb/temp/interface_error_deliveryResultNotify.txt |awk  '{print $1"|"$2}'`
do
count=`echo $i|awk -F "|" '{print $1}'`
#echo $i|awk -F "|" '{print $2}'
if [ ${count} -gt 4 ]
then

echo "deliveryResultNotify失败统计|${now_date}|${i}"
fi
done
