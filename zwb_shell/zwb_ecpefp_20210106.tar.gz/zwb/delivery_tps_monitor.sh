#!/bin/bash
 now_date=`date  +"%Y-%m-%d %H:%M"`
 now_date_1minbefor=`date -d "1 minute ago" +"%Y-%m-%d %H:%M"`
 now_date_2minbefor=`date -d "2 minute ago" +"%Y-%m-%d %H:%M"`
 now_date_3minbefor=`date -d "3 minute ago" +"%Y-%m-%d %H:%M"`
 now_date_4minbefor=`date -d "4 minute ago" +"%Y-%m-%d %H:%M"`

grep "ECPFEP|delivery|start" /home/ecpfep/ecpfep_container/modules/ecpfep/logs/debug/interface.log |grep "${now_date}\|${now_date_1minbefor}\|${now_date_2minbefor}\|${now_date_3minbefor}\|${now_date_4minbefor}"  > /home/ecpfep/zwb/temp/interface_delivery_temp.txt
awk -F "|" '{print $2}' /home/ecpfep/zwb/temp/interface_delivery_temp.txt |awk -F "." '{print $1}' |sort -r |uniq -c |awk '{print $1"|"$2"_"$3}' > /home/ecpfep/zwb/temp/interface_delivery_tps_temp.txt

for i in `cat /home/ecpfep/zwb/temp/interface_delivery_tps_temp.txt`
do
tps=`echo $i |awk -F "|" '{print $1}'`
#echo ${tps}
#如果tps大于指标输出msg信息
if [ ${tps} -gt 100  ] 
then
time=`echo $i |awk -F "|" '{print $2}'`
echo "时间点${time}每秒速率:${tps}"
fi
done

