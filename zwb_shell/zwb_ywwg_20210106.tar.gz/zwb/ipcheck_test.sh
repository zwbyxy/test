#!/bin/bash

iplist=(
10.46.228.116:22
10.46.228.117:22
10.46.228.118:22
10.46.228.119:22
10.46.228.120:22
10.46.228.121:22
10.46.228.230:22
10.46.228.231:22

)


CheckUrl(){
wget -T 1 --spider -t 1 $1 &>/dev/null
RETVAL=$?
if [ $RETVAL -eq 0 ];then
  echo "$1 is ok!!"
  echo "$1 is successful!!" >>./successful.log
  else
  echo "$1 is failed!!"
  echo "$1 is failed!!" >> ./failed.log
fi
return $RETVAL

}

main(){

for array in ${iplist[*]}
 do
  CheckUrl ${array}
 done
}

main $*
