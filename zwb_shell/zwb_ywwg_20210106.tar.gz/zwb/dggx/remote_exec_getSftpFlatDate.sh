#!/usr/bin/expect
spawn sftp -oPort=22 yellowstone@10.181.0.215
expect {
    "refused"
    {
        exit
    }
    "Permission"
    {
        send_user "[exec echo \"Error:Password is wrong\"]"
        exit
    }
    "(yes/no)?"
    {
        send "yes\r"
        expect "*?assword:" { send "yellowstone@321\r"}
    }
    "*?assword:"
    {
       send "yellowstone@321\r"
    }
}
set timeout 3

expect "]*"
send "cd /data/transport/yellowstone/cdr/consis/9206/20201212  \n"
set timeout 3

expect "]*"
send "get *9206*  \n"
#设置get 9206两分钟超时
set timeout 120 

expect "]*"
send "exit\n"
set timeout 3
expect eof
exit
