#!/bin/bash
datetime=`date +%Y%m`12
datetime2=`date +%Y%m%d`
mkdir -p /home/ccbm/zwb/dggx/flat/${datetime2}
cd /home/ccbm/zwb/dggx/flat/${datetime2}
cp -rp /home/ccbm/zwb/dggx/remote_exec_getSftpFlatDate_tamplate.sh /home/ccbm/zwb/dggx/remote_exec_getSftpFlatDate.sh
sed -i "s#€a#${datetime}#g" /home/ccbm/zwb/dggx/remote_exec_getSftpFlatDate.sh
/home/ccbm/zwb/dggx/remote_exec_getSftpFlatDate.sh
downCount=`ls /home/ccbm/zwb/dggx/flat/${datetime2}/* |wc -l`
if [ ${downCount} -eq 31 ]
then
	echo "${downCount}省已经全部下载完成"
else
	echo "只下载${downCount}省，部分省份下载失败，请调整下载超时时间后重新下载。"
fi
