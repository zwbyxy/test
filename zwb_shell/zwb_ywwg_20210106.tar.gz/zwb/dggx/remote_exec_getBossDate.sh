#!/usr/bin/expect
spawn ssh hwzwbusr@10.124.52.50
expect {
    "refused"
    {
        exit
    }
    "Permission"
    {
        send_user "[exec echo \"Error:Password is wrong\"]"
        exit
    }
    "(yes/no)?"
    {
        send "yes\r"
        expect "*?assword:" { send "DCra1kt7XX\r"}
    }
    "*?assword:"
    {
       send "DCra1kt7XX\r"
    }
}
set timeout 3

expect "]*"
send "find /sftpser/dmdsyzxbd/dmdsadm/ -mtime -10 -type f | grep BOSSupload  \r"
set timeout 35

#expect "]*"
#send "echo 1212 \r"
expect "]*"
send "exit\r"
set timeout 2
expect eof
exit
