#!/bin/bash
datetime=$(date +%Y%m%d)
mkdir -p /home/ccbm/zwb/dggx/boss/${datetime}/rename
zwbscp(){
mkdir -p /home/ccbm/zwb/dggx/boss/${3} 
[ -d ~/zwb/dggx ] && {
/usr/bin/expect <<EOF
spawn scp -rp  hwzwbusr@10.124.52.50:${1} /home/ccbm/zwb/dggx/boss/${3}
set timeout 60000
expect {
    "refused"
    {
        exit
    }
    "Permission"
    {
        send_user "[exec echo \"Error:Password is wrong\"]"
        exit
    }
    "(yes/no)?"
    {
        send "yes\r"
        expect "*?assword:" { send "${2}\r"}
    }
    "*?assword:"
    {
       send "${2}\r"
    }
}
expect eof


EOF
}
}



##获取远程boss最近10天上传数据,10天可以根据情况进行修改
./remote_exec_getBossDate.sh > ./filepwd.txt 
dos2unix filepwd.txt
##下载boss数据
for fpwd in `cat filepwd.txt | grep BOSSupload |grep -v find`
do
	zwbscp ${fpwd} DCra1kt7XX ${datetime}
	for pro in `cat province_info.txt`
	do
	prov=`echo ${fpwd} |awk -F "/" '{print $5}'`
	fname=`echo ${fpwd} |awk -F "/" '{print $8}'`
	provi=`echo ${pro} |awk -F "|" '{print $1}'`
	provbm=`echo ${pro} |awk -F "|" '{print $2}'`
	proviname=`echo ${pro} |awk -F "|" '{print $3}'`
	ftype=`echo ${fpwd} |awk -F "/" '{print $8}'|awk -F "." '{print $NF}'`
	rfname=`echo ${fpwd} |awk -F "/" '{print $8}'`_${provbm}_${prov}.${ftype}
	if [ "${prov}" = "${provi}" ]
	then
	echo "${proviname},编码9206${provbm}数据已提供，文件${fname}下载完成。"
	#重命名boss文件
	cp -rp /home/ccbm/zwb/dggx/boss/${datetime}/${fname} /home/ccbm/zwb/dggx/boss/${datetime}/rename/${rfname}
	fi
	done
done


