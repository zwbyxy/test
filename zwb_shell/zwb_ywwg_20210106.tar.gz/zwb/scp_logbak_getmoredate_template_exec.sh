#!/usr/bin/expect
spawn scp -rp ecpfep@10.124.72.47:/home/ecpfep/zwb/remotetemp/checklog_temp.txt /home/ccbm/zwb/temp/checklog_temp.txt
set timeout 60000
expect {
    "refused"
    {
        exit
    }
    "Permission"
    {
        send_user "[exec echo \"Error:Password is wrong\"]"
        exit
    }
    "(yes/no)?"
    {
        send "yes\r"
        expect "*?assword:" { send "Ch7\$A1%!Re\r"}
    }
    "*?assword:"
    {
       send "Ch7\$A1%!Re\r"
    }
}
expect eof


