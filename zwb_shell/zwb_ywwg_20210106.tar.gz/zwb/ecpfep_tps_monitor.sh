#!/bin/bash
hostlist=(
10.124.72.45€Ch7\$A1%!Re€ecpfep
10.124.72.46€Ch7\$A1%!Re€ecpfep
10.124.72.47€Ch7\$A1%!Re€ecpfep
)

main(){
for array in ${hostlist[*]}
do
  ip=`echo ${array} |awk -F "€" '{print $1}'`
  passwd=`echo ${array} |awk -F "€" '{print $2}'`
  loginname=`echo ${array} |awk -F "€" '{print $3}'`
  cp -rp /home/ccbm/zwb/remote_exec_ecpfep_tps_template.sh /home/ccbm/zwb/remote_exec_ecpfep_tps.sh
  sed -i "s#€a#${ip}#g"  /home/ccbm/zwb/remote_exec_ecpfep_tps.sh
  sed -i "s#€b#${passwd}#g"  /home/ccbm/zwb/remote_exec_ecpfep_tps.sh
  sed -i "s#€c#${loginname}#g"  /home/ccbm/zwb/remote_exec_ecpfep_tps.sh
  ##将特殊字符$转义\$ 注意sed需要使用单引号（’）
  sed -i 's#\$#\\$#g' /home/ccbm/zwb/remote_exec_ecpfep_tps.sh 
  /home/ccbm/zwb/remote_exec_ecpfep_tps.sh > /home/ccbm/zwb/temp/text_ecpfep_tps.txt
  counts=`grep "^时间点" /home/ccbm/zwb/temp/text_ecpfep_tps.txt|wc -l` 
  ##由于sed只能单行处理，因此需要将换行替换@  ，处理完后 再将@替换为换行,处理数据中可能带有windows格式^M，需要转换为unix
  ##grep "时间" temp/text_ecpfep_tps.txt | tr '\n' '#' | sed 's/#\[/\[/g' | tr '#' '\n'
  echo "=============$ip============">> /home/ccbm/zwb/temp/text_ecpfep_tps_save.txt
  cat /home/ccbm/zwb/temp/text_ecpfep_tps.txt|grep "^时间点" >>  /home/ccbm/zwb/temp/text_ecpfep_tps_save.txt
  echo "========================="  >>  /home/ccbm/zwb/temp/text_ecpfep_tps_save.txt
  echo ""  >>  /home/ccbm/zwb/temp/text_ecpfep_tps_save.txt
  echo ""  >>  /home/ccbm/zwb/temp/text_ecpfep_tps_save.txt
  cat /home/ccbm/zwb/temp/text_ecpfep_tps.txt|grep "^时间点"|tr '\n' '@' > /home/ccbm/zwb/temp/text_ecpfep_tps_dos2unix.txt
 dos2unix /home/ccbm/zwb/temp/text_ecpfep_tps_dos2unix.txt
   msg="$ip tps信息: `cat /home/ccbm/zwb/temp/text_ecpfep_tps_dos2unix.txt`"
  #for i in `cat /home/ccbm/zwb/temp/text_ecpfep_tps.txt|grep "^时间点"`
  # do
  # msg=${i}${msg}
  #done
  
  if [ ${counts} -gt 0 ]
   then
  echo "$msg"
 echo "===="

  ##sag短信投递部分##
#sag参数时间搓、手机号码、内容，组装到sms.txt 
#time=$(date "+%Y%m%d%H%M%S")
#phone=`cat /home/ccbm/zwb/phone.txt`
#sed -i "s#€1#${time}#g" /home/ccbm/zwb/sms.txt
#sed -i "s#€2#${phone}#g" /home/ccbm/zwb/sms.txt
#sed -i "s#€3#${msg}#g" /home/ccbm/zwb/sms.txt

#投递请求
#sh /home/ccbm/zwb/sendsms.sh

##nae短信投递部分##
time=$(date "+%Y%m%d%H%M%S")
phone=`cat /home/ccbm/zwb/phone_nae.txt|grep -v "^#"`
cp -rp /home/ccbm/zwb/sendsms_nae_tamplate.sh /home/ccbm/zwb/sendsms_nae_exec.sh
sed -i "s#€a#${time}#g"  /home/ccbm/zwb/sendsms_nae_exec.sh
sed -i "s#€b#${phone}#g"  /home/ccbm/zwb/sendsms_nae_exec.sh
sed -i "s#€c#${msg}#g"  /home/ccbm/zwb/sendsms_nae_exec.sh
cat /home/ccbm/zwb/sendsms_nae_exec.sh |tr '@' '\n' > /home/ccbm/zwb/sendsms_nae_exec_temp.sh
chmod 755 /home/ccbm/zwb/sendsms_nae_exec_temp.sh
sh /home/ccbm/zwb/sendsms_nae_exec_temp.sh

  fi 
 
done
}

main $*
