curl -u huawei-log-user:EYzRgqXo1p -XGET '10.114.102.34:9200/jimei-hw-qgcy-ecpfeplog-*/_search?pretty'  -H 'Content-Type: application/json' -d'
{
"from" : 0,
"size":  0,
  "query": {
    "bool": {
      "must": [
                {
          "bool": {
            "should": [
              {
                "term": {
                  "messageType.keyword": {
                    "value": "RSP",
                    "boost": 1
                  }
                }
              }
            ]


          }
        },
        {
          "range": {
            "@timestamp": {
              "from": "2020-12-11T08:15:24.000Z",
              "to": "2020-12-11T08:20:24.999Z",
              "include_lower": true,
              "include_upper": true,
              "boost": 1
            }
          }
        }
      ]
    }
  },
  
    "aggs" : {
        "pre" : {
            "terms" : {
                                "script": "doc[\u0027interfaceName.keyword\u0027].value+\u0027|\u0027+doc[\u0027rspCode.keyword\u0027].value",
                                "size": 1000
            }
        }
    }
}
'
