import json
f=open('json_result.txt','r')
#print(json.load(f))


s_temp=str(json.load(f))
ss_temp=s_temp.replace('false','456')

dict_value=eval(ss_temp)
dict_len=len(dict_value['aggregations']['group_by_grabTime']['buckets'])
dict_count=0
while dict_count<dict_len:
    dict_time=dict_value['aggregations']['group_by_grabTime']['buckets'][dict_count]['key_as_string']
    for i in dict_value['aggregations']['group_by_grabTime']['buckets'][dict_count]['group_by_status']['buckets']:
        print('%s|%s|%s'%(dict_time,i['key'],i['doc_count']))
    dict_count+=1

f.close()
