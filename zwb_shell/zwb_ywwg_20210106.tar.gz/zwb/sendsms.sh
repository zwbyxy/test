##直接调用sag
#cat /home/ccbm/zwb/sms.txt | curl -X POST -H 'Content-type:text/xml; charset=UTF-8' -d @- http://10.46.229.232:8310/SendSmsService/services/SendSms
##调用nae

#cat /home/ccbm/zwb/smsbase.txt > /home/ccbm/zwb/sms.txt
