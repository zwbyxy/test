#!/bin/bash
export LANG=en_US.UTF8
export PATH=/opt/oracle/product/11gR2/db/bin:$PATH
export ORACLE_HOME=/opt/oracle/product/11gR2/db
export NLS_LANG=AMERICAN_AMERICA.AL32UTF8






/usr/bin/mysql -ucarddb -pEf5W#d3VmxR -P3306 -h 10.124.52.163 -D card -N -e "SELECT t1.a,'€',t1.b,'€',t1.c,'€',t1.d,'€',t1.f,'€',t1.e,'€',t1.g,'€',t2.externalid,'€',t2.cardno,'€',t2.turnovertype,'€',t2.fee,'€',t2.createTime,'€',t3.cardBalance,'€',t3.cardAmount FROM t_zwb_temp1126 t1, cardman_t_payment_turnover t2, cardman_t_cardinfo t3 WHERE t1.a = t2.externalid AND t2.cardno = t3.cardNum ORDER BY t1.a,t2.createTime;"  >carddb_data.txt

sed -ie 's/[[:space:]]*//g' carddb_data.txt
