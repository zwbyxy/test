#!/bin/bash
export LANG=en_US.UTF8
export PATH=/opt/oracle/product/11gR2/db/bin:$PATH
export ORACLE_HOME=/opt/oracle/product/11gR2/db
export NLS_LANG=AMERICAN_AMERICA.AL32UTF8






/usr/bin/mysql -ucarddb -pEf5W#d3VmxR -P3306 -h 10.124.52.163 -D card -N -e "SELECT CONCAT(t.userID,',',SUM(t.cardAmount) ,',',SUM(t.cardAmount)-SUM(t.cardBalance) ) FROM cardman_t_cardinfo t WHERE t.activityId='20201110205846' GROUP BY t.userID"  >carddb_data.txt

