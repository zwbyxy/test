#!/bin/bash
export LANG=en_US.UTF8
export PATH=/opt/oracle/product/11gR2/db/bin:$PATH
export ORACLE_HOME=/opt/oracle/product/11gR2/db
export NLS_LANG=AMERICAN_AMERICA.AL32UTF8






/usr/bin/mysql -ucarddb -pEf5W#d3VmxR -P3306 -h 10.124.52.163 -D card -N -e "SELECT CONCAT(t.activityName,',',t.cardNum,',',t.cardAmount,',',DATEDIFF(t.cardExpiryDate,
t.cardEffectiveDate),',',t.createTime,',',t.cardEffectiveDate,',',t.cardExpiryDate,',',IF(t.reserve5 IS NULL ,'null',t.reserve5)) FROM cardman_t_cardinfo t WHERE (t.activityName IS NOT NULL OR t.batchID IS NOT NULL) AND t.createTime > STR_TO_DATE('2019-01-01 00:00:00','%Y-%m-%d %T');
"  >carddb_data.txt

