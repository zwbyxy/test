#!/bin/bash
hostlist=(
10.124.72.140€migucdn@1234€root
)

main(){
for array in ${hostlist[*]}
do
  ip=`echo ${array} |awk -F "€" '{print $1}'`
  passwd=`echo ${array} |awk -F "€" '{print $2}'`
  loginname=`echo ${array} |awk -F "€" '{print $3}'`
  cp -rp /home/ccbm/zwb/remote_exec_ecpelogs_es_template.sh /home/ccbm/zwb/remote_exec_ecpelogs_es.sh
  sed -i "s#€a#${ip}#g"  /home/ccbm/zwb/remote_exec_ecpelogs_es.sh
  sed -i "s#€b#${passwd}#g"  /home/ccbm/zwb/remote_exec_ecpelogs_es.sh
  sed -i "s#€c#${loginname}#g"  /home/ccbm/zwb/remote_exec_ecpelogs_es.sh
  ##将特殊字符$转义\$ 注意sed需要使用单引号（’）
  sed -i 's#\$#\\$#g' /home/ccbm/zwb/remote_exec_ecpelogs_es.sh 
  /home/ccbm/zwb/remote_exec_ecpelogs_es.sh > /home/ccbm/zwb/temp/text_temp.txt
 
done
}

main $*
