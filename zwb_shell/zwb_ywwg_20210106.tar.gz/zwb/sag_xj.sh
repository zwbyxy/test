#!/bin/bash


responselist=(
response\|CMPP30\|cmpp_submit
response\|ParlayX2.1\|sendSms
response\|CMPP30\|cmpp_deliver_status
response\|ParlayX2.1\|notifyMessageDeliveryReceipt
response\|ParlayX2.1\|notifySmsDeliveryReceipt
response\|CMPP30\|cmpp_deliver_status
response\|ParlayX2.1\|sendMessage
response\|MM7\|DeliveryReport
)

exec_grep_interface_list(){
cd /hwlog/sys_logs/SAG/$1

grep "|response|" * > ~/zwb/temp/response_all_temp.txt
for iarray in ${responselist[*]}
do
reqname=`echo ${iarray} |grep -v "^#"`
reqinterfacename=`echo ${iarray} |grep -v "^#"|awk -F "|" '{print $3}'`
interfacename=`grep "${reqinterfacename}" ~/zwb/interfacename.conf |awk -F "|" '{print $2}'`
echo "${interfacename}统计:"
allcount=`grep "$reqname" ~/zwb/temp/response_all_temp.txt|wc -l`
echo "${interfacename} 总量：${allcount}"
succcount=`grep "$reqname" ~/zwb/temp/response_all_temp.txt  | grep  "|INFO|\||Success||" |wc -l`
echo "${interfacename} 成功量：${succcount}"
errorcount=`grep "$reqname" ~/zwb/temp/response_all_temp.txt  | grep "|ERROR|" | grep -v "|Success|" | wc -l`
echo "${interfacename} 失败量：${errorcount}"
succrate=`echo "scale=2;${succcount}/${allcount}" |bc`
echo "${interfacename} 成功率:0${succrate}"
echo ""
done
}


main(){
read -p "enter the  date (eg:20200225):" datetime
mkdir -p ~/zwb/temp/
exec_grep_interface_list ${datetime}

}

main $*
