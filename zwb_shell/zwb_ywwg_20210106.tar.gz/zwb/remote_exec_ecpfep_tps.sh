#!/usr/bin/expect

spawn ssh ecpfep@10.124.72.47
expect {
    "refused"
    {
        exit
    }
    "Permission"
    {
        send_user "[exec echo \"Error:Password is wrong\"]"
        exit
    }
    "(yes/no)?"
    {
        send "yes\r"
        expect "*?assword:" { send "Ch7\$A1%!Re\r"}
    }
    "*?assword:"
    {
       send "Ch7\$A1%!Re\r"
    }
}
expect "]*"
send "sh /home/ecpfep/zwb/delivery_tps_monitor.sh  \r"
#expect "]*"
#send "echo 1212 \r"
expect "]*"
send "exit\r"
expect eof
exit
