#!/bin/bash
##pgw迁移脚本
rm -r ~/zwb/duansou/upMessageLog
rm -r ~/zwb/duansou/downMessageLog
mkdir -p ~/zwb/duansou/upMessageLog
mkdir -p ~/zwb/duansou/downMessageLog
##业务ip€节点号€root密码€管理ip€主机名
iplist=(
10.124.52.36€4€Im##8899€10.46.230.112€FJXM-DM2-HW-DUANSOU-01
10.124.52.37€5€Im##8899€10.46.230.113€FJXM-DM2-HW-DUANSOU-02
10.124.52.38€6€Im##8899€10.46.230.114€FJXM-DM2-HW-DUANSOU-03
10.124.52.39€7€Im##8899€10.46.230.115€FJXM-DM2-HW-DUANSOU-04
)




zwbscp(){
mkdir -p /home/ccbm/zwb/duansou/upMessageLog/$3/upMessageLog
mkdir -p /home/ccbm/zwb/duansou/downMessageLog/$3/downMessageLog
[ -d ~/zwb/duansou ] && {
/usr/bin/expect <<EOF
spawn scp -rp  imuse@${1}:/home/imuse/log/upMessageLog /home/ccbm/zwb/duansou/upMessageLog/$3/upMessageLog
set timeout 60000
expect {
    "refused"
    {
        exit
    }
    "Permission"
    {
        send_user "[exec echo \"Error:Password is wrong\"]"
        exit
    }
    "(yes/no)?"
    {
        send "yes\r"
        expect "*?assword:" { send "${2}\r"}
    }
    "*?assword:"
    {
       send "${2}\r"
    }
}
expect eof


spawn scp -rp  imuse@${1}:/home/imuse/log/downMessageLog /home/ccbm/zwb/duansou/downMessageLog/$3/downMessageLog
set timeout 60000
expect {
    "refused"
    {
        exit
    }
    "Permission"
    {
        send_user "[exec echo \"Error:Password is wrong\"]"
        exit
    }
    "(yes/no)?"
    {
        send "yes\r"
        expect "*?assword:" { send "${2}\r"}
    }
    "*?assword:"
    {
       send "${2}\r"
    }
}
expect eof


EOF
}

}




main(){
for array in ${iplist[*]}
do
  ip=`echo ${array} |awk -F "€" '{print $1}'`
  passwd=`echo ${array} |awk -F "€" '{print $3}'`
  glip=`echo ${array} |awk -F "€" '{print $4}'`
  hostname=`echo ${array} |awk -F "€" '{print $5}'`
  nid=`echo ${array} |awk -F "€" '{print $2}'`
        cd ~/zwb/temp/
        zwbscp ${ip} ${passwd} ${hostname} #&>/dev/null
done
}



main $*
