#!/bin/bash
hostlist=(
10.124.72.45€Ch7\$A1%!Re€ecpfep
10.124.72.46€Ch7\$A1%!Re€ecpfep
10.124.72.47€Ch7\$A1%!Re€ecpfep
)

main(){
for array in ${hostlist[*]}
do
  ip=`echo ${array} |awk -F "€" '{print $1}'`
  passwd=`echo ${array} |awk -F "€" '{print $2}'`
  loginname=`echo ${array} |awk -F "€" '{print $3}'`
  cp -rp /home/ccbm/zwb/remote_exec_template.sh /home/ccbm/zwb/remote_exec.sh
  sed -i "s#€a#${ip}#g"  /home/ccbm/zwb/remote_exec.sh
  sed -i "s#€b#${passwd}#g"  /home/ccbm/zwb/remote_exec.sh
  sed -i "s#€c#${loginname}#g"  /home/ccbm/zwb/remote_exec.sh
  ##将特殊字符$转义\$ 注意sed需要使用单引号（’）
  sed -i 's#\$#\\$#g' /home/ccbm/zwb/remote_exec.sh 
  /home/ccbm/zwb/remote_exec.sh > /home/ccbm/zwb/temp/text.txt
  used=`grep IP /home/ccbm/zwb/temp/text.txt | awk -F ":" '{print $3}' | awk -F "%" '{print $1}'` 
  msg=`grep IP /home/ccbm/zwb/temp/text.txt |awk -F "%" '{print $1"%"}'`
  if [ ${used} -gt 80 ]
   then
  echo "$msg"


  ##sag短信投递部分##
#sag参数时间搓、手机号码、内容，组装到sms.txt 
#time=$(date "+%Y%m%d%H%M%S")
#phone=`cat /home/ccbm/zwb/phone.txt`
#sed -i "s#€1#${time}#g" /home/ccbm/zwb/sms.txt
#sed -i "s#€2#${phone}#g" /home/ccbm/zwb/sms.txt
#sed -i "s#€3#${msg}#g" /home/ccbm/zwb/sms.txt

#投递请求
#sh /home/ccbm/zwb/sendsms.sh

##nae短信投递部分##
time=$(date "+%Y%m%d%H%M%S")
phone=`cat /home/ccbm/zwb/phone_nae.txt|grep -v "^#"`
cp -rp /home/ccbm/zwb/sendsms_nae_tamplate.sh /home/ccbm/zwb/sendsms_nae_exec.sh
sed -i "s#€a#${time}#g"  /home/ccbm/zwb/sendsms_nae_exec.sh
sed -i "s#€b#${phone}#g"  /home/ccbm/zwb/sendsms_nae_exec.sh
sed -i "s#€c#${msg}#g"  /home/ccbm/zwb/sendsms_nae_exec.sh
chmod 755 /home/ccbm/zwb/sendsms_nae_exec.sh
sh /home/ccbm/zwb/sendsms_nae_exec.sh
  fi 
 
done
}

main $*
