#!/bin/bash
##pgw迁移脚本
mkdir -p ~/zwb/backfile
mkdir -p ~/zwb/basefile
mkdir -p ~/zwb/temp
##业务ip€节点号€root密码€管理ip€主机名
iplist=(
10.46.228.112€4€C#so%Y9eR4€10.46.230.112€FJXM-DM2-HW-COSSOSER-04
10.46.228.113€5€C#so%Y9eR4€10.46.230.113€FJXM-DM2-HW-COSSOSER-03
10.46.228.114€6€C#so%Y9eR4€10.46.230.114€FJXM-DM2-HW-COSSOSER-02
10.46.228.115€7€C#so%Y9eR4€10.46.230.115€FJXM-DM2-HW-COSSOSER-01
10.46.228.116€8€DcQ3*FJ#8t€10.46.230.116€FJXM-DM2-HW-DCMPortal-01
10.46.228.117€9€DcQ3*FJ#8t€10.46.230.117€FJXM-DM2-HW-DCMPortal-02
10.46.228.118€10€DcQ3*FJ#8t€10.46.230.118€FJXM-DM2-HW-PRMPortal-01
10.46.228.119€11€DcQ3*FJ#8t€10.46.230.119€FJXM-DM2-HW-PRMPortal-02
10.46.228.120€12€DcQ3*FJ#8t€10.46.230.120€FJXM-DM2-HW-SMPortal-01
10.46.228.121€13€DcQ3*FJ#8t€10.46.230.121€FJXM-DM2-HW-SMPortal-02
10.46.228.230€14€DcQ3*FJ#8t€10.46.230.230€FJXM-DM2-HW-DCMPortal-03
10.46.228.231€15€DcQ3*FJ#8t€10.46.230.231€FJXM-DM2-HW-DCMPortal-04
10.46.228.4€16€dm@2019€10.46.230.4€FJXM-DM2-HW-PGW-10
10.46.228.5€17€dm@2019€10.46.230.5€FJXM-DM2-HW-PGW-11
10.46.228.6€18€dm@2019€10.46.230.6€FJXM-DM2-HW-PGW-12
10.46.228.7€19€dm@2019€10.46.230.7€FJXM-DM2-HW-PGW-13
10.46.228.8€20€dm@2019€10.46.230.8€FJXM-DM2-HW-PGW-14
10.46.228.9€21€dm@2019€10.46.230.9€FJXM-DM2-HW-PGW-15
)




zwbscp(){
rm -rf ~/.ssh/known_hosts
if [ $# -ne 2 ]
then
echo "传参不是2个，退出"
exit 1
fi
[ -d ~/zwb/temp/home ] && {
/usr/bin/expect <<EOF
spawn scp -rp /home/ccbm/zwb/temp/home root@${1}:/
set timeout 60000
expect {
    "refused"
    {
        exit
    }
    "Permission"
    {
        send_user "[exec echo \"Error:Password is wrong\"]"
        exit
    }
    "(yes/no)?"
    {
        send "yes\r"
        expect "*?assword:" { send "${2}\r"}
    }
    "*?assword:"
    {
       send "${2}\r"
    }
}
expect eof


spawn scp -rp /home/ccbm/zwb/temp/etc/hosts root@${1}:/etc/hosts
set timeout 60000
expect {
    "refused"
    {
        exit
    }
    "Permission"
    {
        send_user "[exec echo \"Error:Password is wrong\"]"
        exit
    }
    "(yes/no)?"
    {
        send "yes\r"
        expect "*?assword:" { send "${2}\r"}
    }
    "*?assword:"
    {
       send "${2}\r"
    }
}
expect eof


EOF
rm -rf ~/.ssh/known_hosts
}

}




main(){
for array in ${iplist[*]}
do
  ip=`echo ${array} |awk -F "€" '{print $1}'`
  passwd=`echo ${array} |awk -F "€" '{print $3}'`
  glip=`echo ${array} |awk -F "€" '{print $4}'`
  hostname=`echo ${array} |awk -F "€" '{print $5}'`
  nid=`echo ${array} |awk -F "€" '{print $2}'`
  if [ $? -eq 0 ] 
    then
        ## echo "{array} 备份成功。"
        cd ~/zwb/temp/
        if [ $? -eq 0 ]
           then
               rm -rf ~/zwb/temp/home
               rm -rf ~/zwb/temp/etc
               tar zxvf ~/zwb/basefile/etc.tar.gz &>/dev/null 
               tar zxvf ~/zwb/basefile/home.tar.gz &>/dev/null
              sleep 50
               ##修改配置文件
               sed -i "s#10.46.228.172#${ip}#g" ~/zwb/temp/etc/hosts
               sed -i "s#10.46.230.219#${glip}#g" ~/zwb/temp/etc/hosts
               sed -i "s#FJXM-DM2-HW-PGW-05#${hostname}#g" ~/zwb/temp/etc/hosts
               
               sed -i "s#base_local_ip=10.46.228.172#base_local_ip=${ip}#g" ~/zwb/temp/home/pgw3/cgw/bin/config.properties
               sed -i "s#SA_NODEID=3#SA_NODEID=${nid}#g" ~/zwb/temp/home/pgw3/cgw/bin/config.properties
               sed -i "s#SO_NODEID=3#SO_NODEID=${nid}#g" ~/zwb/temp/home/pgw3/cgw/bin/config.properties
               sed -i "s#DR_NODEID=#DR_NODEID=${nid}#g" ~/zwb/temp/home/pgw3/cgw/bin/config.properties
               sed -i "s#SA_LISTEN_IP=10.46.228.172#SA_LISTEN_IP=${ip}#g" ~/zwb/temp/home/pgw3/cgw/bin/config.properties
               sed -i "s#NODE_INDEX=2#NODE_INDEX=$((${nid}-1))#g" ~/zwb/temp/home/pgw3/cgw/bin/config.properties
               
               sed -i "s#10.46.228.172#${ip}#g" ~/zwb/temp/home/pgw3/cgw/conf/config.xml
               sed -i "s#admintooladrr=10.46.228.172:5442#admintooladrr=${ip}:5442#g" ~/zwb/temp/home/pgw3/cgw/conf/cgw_command_net.cfg
               ##生产环境只配置一个地址，是否支持多个地址配置？ 
               #sed -i "s#zookeeper.address=10.48.121.4:6830#zookeeper.address=10.48.121.4:6830|10.48.121.5:6830...#g" ~/zwb/temp/home/pgw3/cgw/conf/pc_zookeeper.properties
			   sed -i "s#zookeeper.address=10.48.121.4:6830#zookeeper.address=10.48.121.4:6830\\,10.48.121.5:6830\\,10.48.121.6:6830\\,10.48.121.7:6830\\,10.48.121.8:6830\\,10.48.121.9:6830\\,10.48.121.10:6830\\,10.48.121.11:6830\\,10.48.121.12:6830#g" ~/zwb/temp/home/pgw3/cgw/conf/pc_zookeeper.properties
			   sed -i "s#10.46.228.172#${ip}#g" ~/zwb/temp/home/pgw3/cgw/conf/dsf/dsf.properties
               sed -i "s#10.46.228.172#${ip}#g" ~/zwb/temp/home/pgw3/cgw/conf/dsf/cgw.resourceLocal.properties
               sed -i "s#10.46.228.172#${ip}#g" ~/zwb/temp/home/pgw3/cgw/conf/cgw/DiamBaseConfig.xml
               sed -i "s#10.46.228.172#${ip}#g" ~/zwb/temp/home/pgw3/cgw/conf/uniagent/so/monitor.cfg
               sed -i "s#10.46.228.172#${ip}#g" ~/zwb/temp/home/pgw3/cgw/conf/uniagent/so/module.properties
               sed -i "s#10.46.228.172#${ip}#g" ~/zwb/temp/home/pgw3/uniAgent/conf/uoa.properties
               sed -i "s#10.46.228.172#${ip}#g" ~/zwb/temp/home/pgw3/uniAgent/conf/flume_agent.conf
               sed -i "s#10.46.228.172#${ip}#g" ~/zwb/temp/home/pgw3/uniAgent/work/cgw/monitor.cfg
               sed -i "s#10.46.228.172#${ip}#g" ~/zwb/temp/home/pgw3/bin/compinfo.cfg
               
               ##允许root直连
               sed -i "s#PermitRootLogin no#PermitRootLogin yes#g" ~/zwb/temp/etc/ssh/sshd_config
               sed -i "s#UsePrivilegeSeparation sandbox##g" ~/zwb/temp/etc/ssh/sshd_config
               ##保留远程账号
              # keepaccount ${ip} ${passwd} #&>/dev/null
              # [ -f ~/zwb/temp/${ip}_shadow -a ~/zwb/temp/${ip}_passwd ] && {
              #   grep -v "^root" ~/zwb/temp/etc/passwd > ~/zwb/temp/etc/passwd_temp
              #   grep -v "^root" ~/zwb/temp/etc/shadow > ~/zwb/temp/etc/shadow_temp
              #   grep "^root" ~/zwb/temp/${ip}_passwd >> ~/zwb/temp/etc/passwd_temp
              #   grep "^root" ~/zwb/temp/${ip}_shadow >> ~/zwb/temp/etc/shadow_temp
              #   cat ~/zwb/temp/etc/passwd_temp > ~/zwb/temp/etc/passwd
              #   cat ~/zwb/temp/etc/shadow_temp > ~/zwb/temp/etc/shadow
              #     }
               ##拷贝数据到目标主机
               zwbscp ${ip} ${passwd} #&>/dev/null
	       ##是否使用远程主机账号密码
              ## zwbscpaccount ${ip} ${passwd} #&>/dev/null
               echo "${ip} 已经处理完成。"
			   echo "${ip} 已经处理完成。">> ~/zwb/temp/zwb.log
        fi
    else 
        echo "{array} 失败！！"
        echo "{array} 失败！！" >> ~/zwb/temp/zwb_failed.log
        continue
  fi
done
}



main $*
