curl -X POST \
  http://10.124.52.11:8000/nae/pae/xml/ExtendedService/sendSms \
  -H 'content-type: text/xml; charset=UTF-8' \
  -H 'Proxy-Connection: Keep-Alive' \
  -H 'timeStamp: 30001010101010' \
  -H 'sourceDeviceCode: pbsportal' \
  -H 'authenticatorSource: 121facb0a720360fa47a2a27a2125d6816542271a62ffb4e725811eb6d254a89' \
  -H 'version: 1.0' \
  -H 'User-Agent: Jakarta Commons-HttpClient/3.1' \
  -d '<?xml version="1.0" encoding="UTF-8" ?>
<sendSmsReq>
  <header>
    <spId>hgpt</spId>
    <serviceId>35000001000222</serviceId>
    <timeStamp>€a</timeStamp>
    <OA>18206067622</OA>
    <FA>18206067622</FA>
  </header>
  <addresses>€b</addresses>
  <senderName>10658099210</senderName>
  <message>€c</message>
</sendSmsReq>'
