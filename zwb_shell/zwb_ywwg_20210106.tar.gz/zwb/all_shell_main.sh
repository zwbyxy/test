#!/bin/bash
#所有监控主控制脚本
##1、磁盘监控
#/home/ccbm/zwb/diskspace_monitor.sh >> /home/ccbm/zwb/temp/zwbtemp.log

##2、负载监控
#sh /home/ccbm/zwb/load_average_monitor.sh >> /home/ccbm/zwb/temp/zwbtemp.log

##3、ecpe 日志异常、es成功率告警
sh /home/ccbm/zwb/ecpelogs_es_monitor.sh >> /home/ccbm/zwb/temp/zwbtemp.log

##4、ecpfep tps 告警
#sh /home/ccbm/zwb/ecpfep_tps_monitor.sh >> /home/ccbm/zwb/temp/zwbtemp.log

##5、ecpfep deliveryResultNotify错误信息告警 
#sh /home/ccbm/zwb/ecpfeplog_check.sh >> /home/ccbm/zwb/temp/zwbtemp.log

##6、ecpe es日子告警
now_time=`date -u  +%Y-%m-%dT%H:%M:%S`
before_time=`date -d "5 minute ago" -u +%Y-%m-%dT%H:%M:%S`
#ecpe
cat /home/ccbm/zwb/es_monitor.sh > /home/ccbm/zwb/es_monitor_temp.sh
sed -i "s#€zwba#${before_time}#g"  /home/ccbm/zwb/es_monitor_temp.sh
sed -i "s#€zwbb#${now_time}#g"  /home/ccbm/zwb/es_monitor_temp.sh
chmod 755 /home/ccbm/zwb/es_monitor_temp.sh
sh /home/ccbm/zwb/es_monitor_temp.sh
sleep 0.5
#ecpfep
cat /home/ccbm/zwb/es_monitor_ecpfep.sh > /home/ccbm/zwb/es_monitor_temp_ecpfep.sh
sed -i "s#€zwba#${before_time}#g"  /home/ccbm/zwb/es_monitor_temp_ecpfep.sh
sed -i "s#€zwbb#${now_time}#g"  /home/ccbm/zwb/es_monitor_temp_ecpfep.sh
chmod 755 /home/ccbm/zwb/es_monitor_temp_ecpfep.sh
sh /home/ccbm/zwb/es_monitor_temp_ecpfep.sh
sleep 0.5
#ecpm
cat /home/ccbm/zwb/es_monitor_ecpm.sh > /home/ccbm/zwb/es_monitor_temp_ecpm.sh
sed -i "s#€zwba#${before_time}#g"  /home/ccbm/zwb/es_monitor_temp_ecpm.sh
sed -i "s#€zwbb#${now_time}#g"  /home/ccbm/zwb/es_monitor_temp_ecpm.sh
chmod 755 /home/ccbm/zwb/es_monitor_temp_ecpm.sh
sh /home/ccbm/zwb/es_monitor_temp_ecpm.sh
sleep 0.5
#dsum
cat /home/ccbm/zwb/es_monitor_dsum.sh > /home/ccbm/zwb/es_monitor_temp_dsum.sh
sed -i "s#€zwba#${before_time}#g"  /home/ccbm/zwb/es_monitor_temp_dsum.sh
sed -i "s#€zwbb#${now_time}#g"  /home/ccbm/zwb/es_monitor_temp_dsum.sh
chmod 755 /home/ccbm/zwb/es_monitor_temp_dsum.sh
sh /home/ccbm/zwb/es_monitor_temp_dsum.sh

#cardmanager
cat es_monitor_cardmanager.sh > es_monitor_temp_cardmanager.sh
sed -i "s#€zwba#${before_time}#g"  es_monitor_temp_cardmanager.sh
sed -i "s#€zwbb#${now_time}#g"  es_monitor_temp_cardmanager.sh
chmod 755 es_monitor_temp_cardmanager.sh
sh es_monitor_temp_cardmanager.sh
