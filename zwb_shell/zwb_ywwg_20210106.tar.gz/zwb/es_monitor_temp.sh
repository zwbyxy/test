##########1、es 查询必要数据  ##########
curl -u huawei-log-user:EYzRgqXo1p -XGET '10.114.102.34:9200/jimei-hw-qgcy-ecpelog-*/_search?pretty'  -H 'Content-Type: application/json' -d'
{
"from" : 0,
"size":  0,
  "query": {
    "bool": {
      "must": [
                {
          "bool": {
            "should": [
              {
                "term": {
                  "messageType.keyword": {
                    "value": "RSP",
                    "boost": 1
                  }
                }
              }
            ]


          }
        },
        {
          "range": {
            "@timestamp": {
              "from": "2021-01-06T08:11:15.000Z",
              "to": "2021-01-06T08:16:15.999Z",
              "include_lower": true,
              "include_upper": true,
              "boost": 1
            }
          }
        }
      ]
    }
  },
  
    "aggs" : {
        "pre" : {
            "terms" : {
                                "script": "doc[\u0027interfaceName.keyword\u0027].value+\u0027|\u0027+doc[\u0027rspCode.keyword\u0027].value",
                                "size": 1000
            }
        }
    }
}
' > ~/zwb/temp/json_test.txt

##########2、初始化数据##########
echo -n '' > ~/zwb/temp/msg_temp.txt
succFlat='0.9'

##########3、告警短信下发  ##########
sendMsg(){
 ##sag短信投递部分##
#sag参数时间搓、手机号码、内容，组装到sms.txt 
#time=$(date "+%Y%m%d%H%M%S")
#phone=`cat /home/ccbm/zwb/phone.txt`
#sed -i "s#€1#${time}#g" /home/ccbm/zwb/sms.txt
#sed -i "s#€2#${phone}#g" /home/ccbm/zwb/sms.txt
#sed -i "s#€3#${msg}#g" /home/ccbm/zwb/sms.txt

#投递请求
sh /home/ccbm/zwb/sendsms.sh

##nae短信投递部分##
time=$(date "+%Y%m%d%H%M%S")
phone=`cat ~/zwb/phone_nae.txt|grep -v "^#"`
cat ~/zwb/temp/msg_temp.txt|tr '\n' '@' > ~/zwb/temp/msg.txt
dos2unix  ~/zwb/temp/msg.txt
msg=`cat ~/zwb/temp/msg.txt`
cp -rp ~/zwb/sendsms_nae_tamplate.sh ~/zwb/sendsms_nae_exec.sh
sed -i "s#€a#${time}#g"  ~/zwb/sendsms_nae_exec.sh
sed -i "s#€b#${phone}#g"  ~/zwb/sendsms_nae_exec.sh
sed -i "s#€c#${msg}#g"  ~/zwb/sendsms_nae_exec.sh
cat ~/zwb/sendsms_nae_exec.sh |tr '@' '\n' > ~/zwb/sendsms_nae_exec_temp.sh
chmod 755 ~/zwb/sendsms_nae_exec_temp.sh
sh ~/zwb/sendsms_nae_exec_temp.sh
}


##########4、实现功能##########
#（1）、json文件处理，整合成： 开始时间|结束时间|接口名|总量|成功量|失败量|成功率
#（2）、短信告警
grep -A1 "|" ~/zwb/temp/json_test.txt  |grep doc_count |awk -F " : " '{print $2}' > ~/zwb/temp/doc_count.txt
grep -A1 "|" ~/zwb/temp/json_test.txt  |grep key |awk -F '\"' '{print $4}' > ~/zwb/temp/key.txt
paste -d '|' ~/zwb/temp/key.txt ~/zwb//temp/doc_count.txt > ~/zwb/temp/file_exec_end.txt


#获取接口名称`cat ./temp/file_exec_end.txt |awk -F "|" '{print $1}' |sort |uniq -c |awk -F " " '{print $NF}'`
#接口总量`cat ./temp/file_exec_end.txt | awk -F "|" '{ if ( $1=="queryProductSubscribe" ) print $3 }' |awk '{sum+=$1} END {print sum}'`
#接口成功量` cat ./temp/file_exec_end.txt | awk -F "|" '{ if ( $1=="queryProductSubscribe" && $2=="RC00000000" )  print $3 }' |awk '{sum+=$1} END {print sum}'`
#接口失败量`cat ./temp/file_exec_end.txt | awk -F "|" '{ if ( $1=="queryProductSubscribe" && $2!="RC00000000" )  print $3 }' |awk '{sum+=$1} END {print sum}'`

#循环次数累加变量
loopCountSum=0
#总循环次数
#loopCount=`cat ~/zwb/temp/file_exec_end.txt |awk -F "|" '{print $1}' |sort |uniq -c |awk -F " " '{print $NF}'|grep -wv '/ecpfep/deliveryServices/userResponseContent'|wc -l`

loopCount=`cat ~/zwb/temp/file_exec_end.txt |awk -F "|" '{print $1}' |sort |uniq -c |awk -F " " '{print $NF}'|grep -wv '/ecpfep/deliveryServices/userResponseContent'|wc -l`
#是否需要发短信，0不需要，1需要
flag=0
echo "ecpe接口日志告警：" > ~/zwb/temp/msg_temp.txt
for i in `cat ~/zwb/temp/file_exec_end.txt |awk -F "|" '{print $1}' |sort |uniq -c |awk -F " " '{print $NF}'|grep -wv '/ecpfep/deliveryServices/userResponseContent'`
do
        loopCountSum=$((${loopCountSum}+1))
        allCount=`cat ~/zwb/temp/file_exec_end.txt | awk -v inerName="$i" -F "|" '{ if ( $1==inerName ) print $3 }' |awk '{sum+=$1} END {print sum}'`
        succCount=`cat ~/zwb/temp/file_exec_end.txt | awk -v inerName="$i" -F "|" '{ if ( $1==inerName && $2=="RC00000000" )  print $3 }' |awk '{sum+=$1} END {print sum}'`
        failCount=`cat ~/zwb/temp/file_exec_end.txt | awk -v inerName="$i" -F "|" '{ if ( $1==inerName && $2!="RC00000000" )  print $3 }' |awk '{sum+=$1} END {print sum}'`
	if [ -z $succCount ]
        then
        succCount=0
        fi
        if [ -z $failCount ]
        then
        failCount=0
        fi
        echo -e "0\c" > ~/zwb/temp/rate.txt;echo "scale = 2; $succCount / $allCount" | bc >> ~/zwb/temp/rate.txt
        succRate=`cat ~/zwb//temp/rate.txt`
  
    #时间转换为北京时间
    stime=2021-01-06T08:11:15
    etime=2021-01-06T08:16:15

    starttime=`echo "$stime" |sed "s#T# #g"`
    endtime=`echo "$etime"|sed "s#T# #g"`

    seconds_stime=`date -d "$starttime" +%s`
    seconds_stime_temp=`expr $seconds_stime + 28800`
    stime=`date -d @$seconds_stime_temp "+%Y-%m-%d %H:%M:%S"`

    seconds_etime=`date -d "$endtime" +%s`
    seconds_etime_temp=`expr $seconds_etime + 28800`
    etime=`date -d @$seconds_etime_temp "+%Y-%m-%d %H:%M:%S"`
        echo "${stime}|${etime}|${i}|${allCount}|${succCount}|${failCount}|${succRate}" >> ~/zwb/temp/record_temp.txt
        ##判断成功率，调用短信投递函数进行投递
#        [ ${allCount} -lt 10 ] && {
#        echo "sum lt 10!!,continue."
#        continue 
#                }
        if [ `expr ${succRate}  \> ${succFlat}` -eq 0 -a "${succRate}" != "01.00" ]
        then
        echo "告警指标:成功率${succRate}小于等于${succFlat}" >> ~/zwb/temp/msg_temp.txt
        echo "接口:${i}" >> ~/zwb/temp/msg_temp.txt
        echo "时间段:${stime}至${etime}" >> ~/zwb/temp/msg_temp.txt
        echo "总量:${allCount}" >> ~/zwb/temp/msg_temp.txt
        echo "成功量:${succCount}" >> ~/zwb/temp/msg_temp.txt
        echo "失败量:${failCount}" >> ~/zwb/temp/msg_temp.txt
        echo "成功率:${succRate}" >> ~/zwb/temp/msg_temp.txt
        flag=1
	fi
        #最后一次循环进行告警
        #echo "loopCountSum|loopCount的值:${loopCountSum}|${loopCount}" >> ~/zwb/temp/test.log   
        if [ ${loopCountSum} -eq ${loopCount} -a ${flag} -eq 1 ]
        then
                echo "执行了ecpe sendMsg函数">>~/zwb/temp/test.log   
                sendMsg
        fi
done
