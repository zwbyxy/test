#!/bin/bash
##检查出未备份的文件名称
rm -rf ~/zwb/remotetemp/checklog_temp_temp 
mkdir -p ~/zwb/remotetemp/
[ -e ~/zwb/remotetemp/checklogall.txt ] || {
cd  ~/zwb/remotetemp/
#touch checklogall.txt
find €a -mmin +2 -type f | xargs ls -al --time-style="+%Y-%m-%d %H:%M:%S" |grep '.log' | awk '{print $6"_"$7"|"$8}'>~/zwb/remotetemp/checklogall.txt
}

find €a -mmin +2 -type f | xargs ls -al --time-style="+%Y-%m-%d %H:%M:%S" |grep '.log' | awk '{print $6"_"$7"|"$8}'> ~/zwb/remotetemp/checklognewnote.txt
##根据时间获取未备份的日志名称,并将所有数据备份记录到~/zwb/remotetemp/checklogall.txt
cat  ~/zwb/remotetemp/checklognewnote.txt >  ~/zwb/remotetemp/checklog_temp.txt
for rule in  `cat ~/zwb/remotetemp/checklognewnote.txt`
do
filedate=`echo ${rule}|awk -F "|" '{print $1}'`
filename=`echo ${rule}|awk -F "|" '{print $2}'`

sametime=`awk -v filedate="$filedate" -v  filename="$filename"  'BEGIN{FS=OFS="|"}{if ($1==filedate) print $1}' ~/zwb/remotetemp/checklogall.txt` 
if [ -z ${sametime}  ]
then
echo "${sametime} is null."
else
grep -v "${sametime}"  ~/zwb/remotetemp/checklog_temp.txt > ~/zwb/remotetemp/checklog_temp_temp
fi

if [ -e ~/zwb/remotetemp/checklog_temp_temp ]
then
cat ~/zwb/remotetemp/checklog_temp_temp > ~/zwb/remotetemp/checklog_temp.txt
echo "after1:"
#cat ~/zwb/remotetemp/checklog_temp.txt 
else
echo "after2:"
#cat ~/zwb/remotetemp/checklog_temp.txt 
fi

done
cat  ~/zwb/remotetemp/checklog_temp.txt >> ~/zwb/remotetemp/checklogall.txt
