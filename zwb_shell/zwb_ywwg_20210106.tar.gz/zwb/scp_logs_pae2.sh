ip="10.46.229.108"
port="22"
user="pae"
passwd="Ky9!mZqe"
mkdir -p /home/ccbm/zwb/base_logs/
mkdir -p /home/ccbm/zwb/min_logs/
mkdir -p /home/ccbm/zwb/logs_bak/
mkdir -p /home/ccbm/zwb/txt/
baselogs="/home/ccbm/zwb/base_logs"
minlogs="/home/ccbm/zwb/min_logs"
logbak="/home/ccbm/zwb/logs_bak"

rm -rf /home/ccbm/zwb/base_logs/*.log
rm -rf  /home/ccbm/zwb/min_logs/*.log
rm -rf /home/ccbm/zwb/txt/*.txt
cd
###拷贝远程日志###
echo '拷贝远程日志开始...'
/usr/bin/expect << EOD
set timeout 6000
eval spawn scp -rp ${user}@${ip}:/home/pae/tomcat/logs/portal/interface/PORTAL_interface.log   /home/ccbm/zwb/base_logs/
expect {
    "refused"
    {
        exit
    }
    "Permission"
    {
        send_user "[exec echo \"Error:Password is wrong\"]"
        exit
    }
    "(yes/no)?"
    {
        send "yes\r"
        expect "*?assword:" { send "${passwd}\r"}
    }
    "*?assword:"
    {
       send "${passwd}\r"
    }
}


expect eof
EOD
echo "拷贝远程日志完成"

##过滤前5分钟日志
#DATETEST="2019-10-22 11:09"
nowdate=$(date "+%Y-%m-%d")
DATE=$(date "+%Y-%m-%d %H:%M")
DATE1=$(date -d '-1 minute' "+%Y-%m-%d %H:%M")
DATE2=$(date -d '-2 minute' "+%Y-%m-%d %H:%M")
DATE3=$(date -d '-3 minute' "+%Y-%m-%d %H:%M")
DATE4=$(date -d '-4 minute' "+%Y-%m-%d %H:%M")
DATE5=$(date -d '-5 minute' "+%Y-%m-%d %H:%M")

mkdir -p  ${logbak}/${nowdate}
cd ${baselogs}
#grep "${DATETEST}" *.log.10* > ../logmin_log/"${DATETEST}".interface.log
grep "${DATE1}" *.log* > ${minlogs}/"${DATE1}".interface.log
grep "${DATE2}" *.log* > ${minlogs}/"${DATE2}".interface.log
grep "${DATE3}" *.log* > ${minlogs}/"${DATE3}".interface.log
grep "${DATE4}" *.log* > ${minlogs}/"${DATE4}".interface.log
grep "${DATE5}" *.log* > ${minlogs}/"${DATE5}".interface.log

#chown -R logstash:elk ${minlogs}/*

cd ${minlogs}
##获取每分钟文件名
find ./ |grep "\.log" |awk -F "/" '{print $2}' > /home/ccbm/zwb/txt/filename.txt

cd ${logbak}/${nowdate}/
find ./ |grep "\.log" |awk -F "/" '{print $2}' > /home/ccbm/zwb/txt/bakfilename.txt


##如果有备份文件过滤掉备份文件再拷贝数据
cd ${logbak}/${nowdate}
count2=`ls | wc -l`
if [ ${count2} -gt 0 ];
 then
#for 循环中有空格会导致异常处理
 IFS=$'\n'
 OLDIFS="$IFS"
for i in `cat /home/ccbm/zwb/txt/bakfilename.txt`
 do
 grep -v "${i}" /home/ccbm/zwb/txt/filename.txt > /home/ccbm/zwb/txt/filename2.txt
 cat /home/ccbm/zwb/txt/filename2.txt > /home/ccbm/zwb/txt/filename.txt 
 done
IFS="$OLDIFS"

##过滤完备份文件后，如果有数据需要进行处理
count=`cat /home/ccbm/zwb/txt/filename.txt |wc -l`
if [ ${count} -gt 0 ];
 then

#for 循环中有空格会导致异常处理
 IFS=$'\n'
 OLDIFS="$IFS"

##循环拷贝新数据到指定目录
 for ii in `cat /home/ccbm/zwb/txt/filename.txt`
  do
  scp -rp ${minlogs}/"${ii}" ${logbak}/${nowdate}/
  scp -rp ${minlogs}/"${ii}" /home/ccbm/zwb/logstash/
  done
 IFS="$OLDIFS"

 else
##如果没有数据无需拷贝
 echo "无需拷贝"
 fi

else
##如果不在备份文件中，直接拷贝数据
cp -rp ${minlogs}/* ${logbak}/${nowdate}/
cp -rp ${minlogs}/* /home/ccbm/zwb/logstash/
fi
