#!/bin/bash
date=`date +%Y%m%d`
namelist=(
IDType€IDValue€OprCode€OprNumb€BizType€SPID€BizCode€OprNumb€Channel
)

for array in ${namelist[*]}
do
IDType=`echo ${array} |awk -F "€" '{print $1}'`
IDValue=`echo ${array} |awk -F "€" '{print $2}'`
OprCode=`echo ${array} |awk -F "€" '{print $3}'`
OprNumb=`echo ${array} |awk -F "€" '{print $4}'`
BizType=`echo ${array} |awk -F "€" '{print $5}'`
SPID=`echo ${array} |awk -F "€" '{print $6}'`
BizCode=`echo ${array} |awk -F "€" '{print $7}'`
EfftTime=`echo ${array} |awk -F "€" '{print $8}'`
Channel=`echo ${array} |awk -F "€" '{print $9}'`





dos2unix ~/zwb/temp/pt_to_boss_json.txt  
sed -i 's#\\##g' ~/zwb/temp/pt_to_boss_json.txt


grep -Po "${IDType}[\" :]+\K[^\"]+"  ~/zwb/temp/pt_to_boss_json.txt > ~/zwb/temp/IDType_field.txt
grep -Po "${IDValue}[\" :]+\K[^\"]+"  ~/zwb/temp/pt_to_boss_json.txt > ~/zwb/temp/IDValue_field.txt
grep -Po "${OprCode}[\" :]+\K[^\"]+"  ~/zwb/temp/pt_to_boss_json.txt > ~/zwb/temp/OprCode_field.txt
grep -Po "${OprNumb}[\" :]+\K[^\"]+"  ~/zwb/temp/pt_to_boss_json.txt > ~/zwb/temp/OprNumb_field.txt
grep -Po "${BizType}[\" :]+\K[^\"]+"  ~/zwb/temp/pt_to_boss_json.txt > ~/zwb/temp/BizType_field.txt
grep -Po "${SPID}[\" :]+\K[^\"]+"  ~/zwb/temp/pt_to_boss_json.txt > ~/zwb/temp/SPID_field.txt
grep -Po "${BizCode}[\" :]+\K[^\"]+"  ~/zwb/temp/pt_to_boss_json.txt > ~/zwb/temp/BizCode_field.txt
grep -Po "${EfftTime}[\" :]+\K[^\"]+"  ~/zwb/temp/pt_to_boss_json.txt > ~/zwb/temp/EfftTime_field.txt
grep -Po "${Channel}[\" :]+\K[^\"]+"  ~/zwb/temp/pt_to_boss_json.txt > ~/zwb/temp/Channel_field.txt


mkdir -p ~/zwb/es_cdr/
paste -d"|" ~/zwb/temp/IDType_field.txt ~/zwb/temp/IDValue_field.txt ~/zwb/temp/OprCode_field.txt ~/zwb/temp/OprNumb_field.txt ~/zwb/temp/BizType_field.txt ~/zwb/temp/SPID_field.txt ~/zwb/temp/BizCode_field.txt ~/zwb/temp/EfftTime_field.txt ~/zwb/temp/Channel_field.txt >>~/zwb/es_cdr/pt_to_boss_${date}.txt

done
