curl -X POST \
  http://10.124.52.11:8000/nae/pae/xml/ExtendedService/sendSms \
  -H 'content-type: text/xml; charset=UTF-8' \
  -H 'Proxy-Connection: Keep-Alive' \
  -H 'timeStamp: 30001010101010' \
  -H 'sourceDeviceCode: pbsportal' \
  -H 'authenticatorSource: 121facb0a720360fa47a2a27a2125d6816542271a62ffb4e725811eb6d254a89' \
  -H 'version: 1.0' \
  -H 'User-Agent: Jakarta Commons-HttpClient/3.1' \
  -d '<?xml version="1.0" encoding="UTF-8" ?>
<sendSmsReq>
  <header>
    <spId>hgpt</spId>
    <serviceId>35000001000222</serviceId>
    <timeStamp>20210106161055</timeStamp>
    <OA>18206067622</OA>
    <FA>18206067622</FA>
  </header>
  <addresses>15280017653,14759209929,18206067622,18850195761,13559154295,13405955051,15980756238</addresses>
  <senderName>10658099210</senderName>
  <message>ecpfep接口日志告警：
告警指标:成功率0.89小于等于0.9
接口:delivery
时间段:2021-01-06 16:05:51至2021-01-06 16:10:51
总量:5121
成功量:4567
失败量:554
成功率:0.89
</message>
</sendSmsReq>'
