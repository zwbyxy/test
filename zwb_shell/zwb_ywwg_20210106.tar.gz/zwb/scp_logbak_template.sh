#!/usr/bin/expect
spawn scp -rp /home/ccbm/zwb/check_newlogfile.sh €a@€b:€c
set timeout 60000
expect {
    "refused"
    {
        exit
    }
    "Permission"
    {
        send_user "[exec echo \"Error:Password is wrong\"]"
        exit
    }
    "(yes/no)?"
    {
        send "yes\r"
        expect "*?assword:" { send "€d\r"}
    }
    "*?assword:"
    {
       send "€d\r"
    }
}
expect eof
exit
