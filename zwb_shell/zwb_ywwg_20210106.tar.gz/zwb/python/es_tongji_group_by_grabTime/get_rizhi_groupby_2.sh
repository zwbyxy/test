curl -u huawei-log-user:EYzRgqXo1p -XGET '10.114.102.34:9200/jimei-hw-qgcy-ecpfeplog-*/_search?pretty'  -H 'Content-Type: application/json' -d'
{
"from" : 0,
"size":  0,
  "query": {
    "bool": {
      "must": [
                {
          "bool": {
            "should": [
              {
                "term": {
                  "messageType.keyword": {
                    "value": "RSP",
                    "boost": 1
                  }
                }
              }
            ]


          }
        },
        {
          "range": {
            "@timestamp": {
              "from": "2021-01-06T00:40:00.000Z",
              "to": "2021-01-06T00:45:00.000Z",
              "include_lower": true,
              "include_upper": true,
              "boost": 1
            }
          }
        }
      ]
    }
  },
          // 不显示具体的内容
        // 聚合
        "aggs": {
            // 自己取的聚合名字
            "group_by_grabTime": {
                // es提供的时间处理函数
                "date_histogram": {
                    // 需要聚合分组的字段名称, 类型需要为date, 格式没有要求
                    "field": "@timestamp",
                    // 按什么时间段聚合, 5m这里是5分钟, 可用的interval在上面给出
                    "interval": "1s",
                    // 设置时区, 这样就相当于东八区的时间
                    "time_zone":"+08:00",
                    // 返回值格式化，HH大写，不然不能区分上午、下午
                    "format": "yyyy-MM-dd HH:mm:ss",  
                    // 为空的话则填充0
                    "min_doc_count": 0
                    // 需要填充0的范围
                    //"extended_bounds": {
                    //    "min": 1533556800000,
                    //    "max": 1533806520000
                    //}
                },
                // 聚合
                "aggs": {
                    // 自己取的名称
                    "group_by_status": {
                        // es提供
                        "terms": {
                            // 聚合字段名
                            "field": "interfaceName.keyword"
                        }
                    }
                }
            }
        }

}
'>json_result.txt
