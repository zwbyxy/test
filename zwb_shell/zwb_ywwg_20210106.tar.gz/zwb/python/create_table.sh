#!/bin/bash
#/create_table.sh 10 创建10列的表
if [ -n "$1" ]
	then
	num=$1
	python pytest3.py ${num} | sed "s#'##g" | sed 's#\[#(#g' | sed 's#\]#)#g'
	else
	python pytest3.py 20 | sed "s#'##g" | sed 's#\[#(#g' | sed 's#\]#)#g'
fi
