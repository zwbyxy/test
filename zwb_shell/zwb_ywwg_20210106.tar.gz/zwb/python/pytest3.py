#ecoding=utf-8
import sys
num = int(sys.argv[1])
a=[x for x in range(num)]
blist = []
for i in a:
	b='a%s varchar(1000) '%i
	blist.append(b)
print("create table t_zwb_temptest %s"%(blist))
