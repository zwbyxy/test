#!/usr/bin/expect

spawn ssh €c@€a
expect {
    "refused"
    {
        exit
    }
    "Permission"
    {
        send_user "[exec echo \"Error:Password is wrong\"]"
        exit
    }
    "(yes/no)?"
    {
        send "yes\r"
        expect "*?assword:" { send "€b\r"}
    }
    "*?assword:"
    {
       send "€b\r"
    }
}
expect "]*"
send "sh /home/ecpfep/zwb/load_average_check.sh \r"
#expect "]*"
#send "cat /home/ecpfep/zwb/temp/load_average_check.txt \r"
expect "]*"
send "exit\r"
expect eof
exit
