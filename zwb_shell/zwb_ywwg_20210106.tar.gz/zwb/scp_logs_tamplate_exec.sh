#!/usr/bin/expect
spawn scp -rp  ecpfep@10.124.72.47:/home/ecpfep/ecpfep_container/modules/ecpfep/logs/debug/debug.log.9 /hwlog/sys_logs/ecpfep/debug_bak/20200611/10.124.72.47_ecpfep_debug_2020-05-13_11:08:34.log
set timeout 60000
expect {
    "refused"
    {
        exit
    }
    "Permission"
    {
        send_user "[exec echo \"Error:Password is wrong\"]"
        exit
    }
    "(yes/no)?"
    {
        send "yes\r"
        expect "*?assword:" { send "Ch7\$A1%!Re\r"}
    }
    "*?assword:"
    {
       send "Ch7\$A1%!Re\r"
    }
}
expect eof
