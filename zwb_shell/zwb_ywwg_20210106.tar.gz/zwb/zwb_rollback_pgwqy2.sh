#!/bin/bash
##回滚主机最初状态
##业务ip€节点号€迁移后的root密码€管理ip€主机名
iplist=(
192.168.1.202€4€root€192.168.2.202€zwb-02
192.168.1.203€5€root€192.168.2.203€zwb-03
)
mkdir -p ~/zwb/rollback/
rm -rf /root/.ssh/known_hosts
rollback(){
[ -f ~/zwb/backfile/${1}_etc.tar.gz ] && {
cd ~/zwb/rollback/
tar zxvf ~/zwb/backfile/${1}_etc.tar.gz
sleep 1
/usr/bin/expect <<EOF
spawn scp -rp /root/zwb/rollback/etc root@${1}:/
set timeout 60000
expect {
    "refused"
    {
        exit
    }
    "Permission"
    {
        send_user "[exec echo \"Error:Password is wrong\"]"
        exit
    }
    "(yes/no)?"
    {
        send "yes\r"
        expect "*?assword:" { send "${2}\r"}
    }
    "*?assword:"
    {
       send "${2}\r"
    }
}
expect eof
EOF

sleep 2
rm -rf ~/zwb/rollback/etc
}
}

main(){
for array in ${iplist[*]}
do
  ip=`echo ${array} |awk -F "€" '{print $1}'`
  passwd=`echo ${array} |awk -F "€" '{print $3}'`
  glip=`echo ${array} |awk -F "€" '{print $4}'`
  hostname=`echo ${array} |awk -F "€" '{print $5}'`
  nid=`echo ${array} |awk -F "€" '{print $2}'`
  rollback ${ip} ${passwd}
done

}

main $*
