#!/bin/bash
##远程ip€远程密码€远程账号€需要备份文件绝对路径€备份本地位置€备份文件名称€执行脚本存放到远程的位置€远程增量备份存储文件位置
hostlist=(
10.124.72.45€Ch7\$A1%!Re€ecpfep€/home/ecpfep/ecpfep_container/modules/ecpfep/logs/debug/interface.log.*€/hwlog/sys_logs/ecpfep/interface_bak€10.124.72.47_ecpfep_interface€/home/ecpfep/zwb/€/home/ecpfep/zwb/remotetemp/
10.124.72.45€Ch7\$A1%!Re€ecpfep€/home/ecpfep/ecpfep_container/modules/ecpfep/logs/debug/debug.log.*€/hwlog/sys_logs/ecpfep/logbak/debug_bak€10.124.72.47_ecpfep_debug€/home/ecpfep/zwb/€/home/ecpfep/zwb/remotetemp/
10.124.72.46€Ch7\$A1%!Re€ecpfep€/home/ecpfep/ecpfep_container/modules/ecpfep/logs/debug/interface.log.*€/hwlog/sys_logs/ecpfep/interface_bak€10.124.72.47_ecpfep_interface€/home/ecpfep/zwb/€/home/ecpfep/zwb/remotetemp/
10.124.72.46€Ch7\$A1%!Re€ecpfep€/home/ecpfep/ecpfep_container/modules/ecpfep/logs/debug/debug.log.*€/hwlog/sys_logs/ecpfep/debug_bak€10.124.72.47_ecpfep_debug€/home/ecpfep/zwb/€/home/ecpfep/zwb/remotetemp/
10.124.72.47€Ch7\$A1%!Re€ecpfep€/home/ecpfep/ecpfep_container/modules/ecpfep/logs/debug/interface.log.*€/hwlog/sys_logs/ecpfep/interface_bak€10.124.72.47_ecpfep_interface€/home/ecpfep/zwb/€/home/ecpfep/zwb/remotetemp/
10.124.72.47€Ch7\$A1%!Re€ecpfep€/home/ecpfep/ecpfep_container/modules/ecpfep/logs/debug/debug.log.*€/hwlog/sys_logs/ecpfep/debug_bak€10.124.72.47_ecpfep_debug€/home/ecpfep/zwb/€/home/ecpfep/zwb/remotetemp/
)



main(){
for array in ${hostlist[*]}
do
 ##上传远程脚步部分  
  filepwd=`echo ${array} |awk -F "€" '{print $4}'`

  cat ~/zwb/check_newlogfile_template.sh >  ~/zwb/check_newlogfile.sh
  sed -i  "s#€a#${filepwd}#g"  ~/zwb/check_newlogfile.sh
  ip=`echo ${array} |awk -F "€" '{print $1}'`
  passwd=`echo ${array} |awk -F "€" '{print $2}'`
  loginname=`echo ${array} |awk -F "€" '{print $3}'`
  remotepwd=`echo ${array} |awk -F "€" '{print $7}'`
  cat ~/zwb/scp_logbak_template.sh > ~/zwb/scp_logbak_template_exec.sh
  sed -i "s#€a#${loginname}#g" ~/zwb/scp_logbak_template_exec.sh
  sed -i "s#€b#${ip}#g" ~/zwb/scp_logbak_template_exec.sh
  sed -i "s#€c#${remotepwd}#g" ~/zwb/scp_logbak_template_exec.sh
  sed -i "s#€d#${passwd}#g" ~/zwb/scp_logbak_template_exec.sh
  sed -i 's#\$#\\$#g'  ~/zwb/scp_logbak_template_exec.sh
  chmod 755  ~/zwb/scp_logbak_template_exec.sh
  ~/zwb/scp_logbak_template_exec.sh

#远程执行部分
  ip=`echo ${array} |awk -F "€" '{print $1}'`
  passwd=`echo ${array} |awk -F "€" '{print $2}'`
  loginname=`echo ${array} |awk -F "€" '{print $3}'`
  cp -rp ~/zwb/remote_exec_template_logbak.sh ~/zwb/remote_exec_template_logbak_exec.sh
  sed -i "s#€a#${ip}#g"  ~/zwb/remote_exec_template_logbak_exec.sh
  sed -i "s#€b#${passwd}#g"  ~/zwb/remote_exec_template_logbak_exec.sh
  sed -i "s#€c#${loginname}#g"  ~/zwb/remote_exec_template_logbak_exec.sh
  ##将特殊字符$转义\$ 注意sed需要使用单引号（’）
  sed -i 's#\$#\\$#g' ~/zwb/remote_exec_template_logbak_exec.sh 
  chmod 755 ~/zwb/remote_exec_template_logbak_exec.sh
  ~/zwb/remote_exec_template_logbak_exec.sh > ~/zwb/temp/logbak_text.txt

#拷贝远程需要备份的日志文件
  filepwd=`echo ${array} |awk -F "€" '{print $4}'`
  ip=`echo ${array} |awk -F "€" '{print $1}'`
  passwd=`echo ${array} |awk -F "€" '{print $2}'`
  loginname=`echo ${array} |awk -F "€" '{print $3}'`
  remotefilepwd=`echo ${array} |awk -F "€" '{print $8}'`
  cat ~/zwb/scp_logbak_getmoredate_template.sh > ~/zwb/scp_logbak_getmoredate_template_exec.sh
  sed -i "s#€a#${loginname}#g" ~/zwb/scp_logbak_getmoredate_template_exec.sh
  sed -i "s#€b#${ip}#g" ~/zwb/scp_logbak_getmoredate_template_exec.sh
  sed -i "s#€c#${remotefilepwd}#g" ~/zwb/scp_logbak_getmoredate_template_exec.sh
  sed -i "s#€d#${passwd}#g" ~/zwb/scp_logbak_getmoredate_template_exec.sh
  sed -i 's#\$#\\$#g'  ~/zwb/scp_logbak_getmoredate_template_exec.sh
  chmod 755  ~/zwb/scp_logbak_getmoredate_template_exec.sh
  ~/zwb/scp_logbak_getmoredate_template_exec.sh
#执行日志备份
  bakfilepwd=`echo ${array} |awk -F "€" '{print $5}'`
  datetime=$( date "+%Y%m%d")
  locpwd=${bakfilepwd}/${datetime}
  bakfilename=`echo ${array} |awk -F "€" '{print $6}'`
   mkdir -p ${bakfilepwd}/${datetime}
  
  for i in `cat ~/zwb/temp/checklog_temp.txt`
  do
   logsfilepwd=`echo $i | awk -F '|' '{print $2}'`
   logname="${bakfilename}_`echo $i | awk -F '|' '{print $1}'`.log"
   cat ~/zwb/scp_logs_tamplate.sh > ~/zwb/scp_logs_tamplate_exec.sh
   sed -i "s#€a#${loginname}#g" ~/zwb/scp_logs_tamplate_exec.sh
   sed -i "s#€b#${ip}#g" ~/zwb/scp_logs_tamplate_exec.sh
   sed -i "s#€c#${logsfilepwd}#g" ~/zwb/scp_logs_tamplate_exec.sh
   sed -i "s#€d#${passwd}#g" ~/zwb/scp_logs_tamplate_exec.sh
   sed -i "s#€e#${locpwd}#g" ~/zwb/scp_logs_tamplate_exec.sh
   sed -i "s#€f#${logname}#g" ~/zwb/scp_logs_tamplate_exec.sh
   sed -i 's#\$#\\$#g'  ~/zwb/scp_logs_tamplate_exec.sh
   chmod 755  ~/zwb/scp_logs_tamplate_exec.sh
  # ~/zwb/scp_logs_tamplate_exec.sh
   
  done


 
done
}

main $*
