#!/usr/bin/expect

spawn ssh root@10.124.72.140
expect {
    "refused"
    {
        exit
    }
    "Permission"
    {
        send_user "[exec echo \"Error:Password is wrong\"]"
        exit
    }
    "(yes/no)?"
    {
        send "yes\r"
        expect "*?assword:" { send "migucdn@1234\r"}
    }
    "*?assword:"
    {
       send "migucdn@1234\r"
    }
}
expect "]*"
send "sh /root/zwb/es_monitor.sh  \r"
#expect "]*"
#send "echo 1212 \r"
expect "]*"
send "exit\r"
expect eof
exit
