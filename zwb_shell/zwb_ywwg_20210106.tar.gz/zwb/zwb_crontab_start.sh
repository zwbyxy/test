#!/bin/bash
##自定义crontab任务##
hour=`date +"%k"`

crontab_start(){
	while true
	do
		sh /home/ccbm/zwb/all_shell_main.sh
		now_date=`date  +"%Y-%m-%d %H:%M:%S"`
		echo "$now_date远程任务执行了。" >>/home/ccbm/zwb/temp/zwbtemp.log
		##5分钟
		sleep 300
		hour=`date +"%k"`
		#if [  $hour -lt 5 -o $hour -gt 21 ]
		if [  $hour -lt 0 -o $hour -gt 210 ]
		then
			#flag.txt标记状态，0开始标志
			echo -n '0' > /home/ccbm/zwb/temp/flag.txt
			now_date=`date  +"%Y-%m-%d %H:%M:%S"`
			pid=`ps -ef | grep zwb_crontab_start | grep -v grep |awk '{print $2}'`
			echo "" >>/home/ccbm/zwb/temp/zwbtemp.log
			echo "============================">>/home/ccbm/zwb/temp/zwbtemp.log
			echo "$now_date :PID:$pid crontab_stop" >>/home/ccbm/zwb/temp/zwbtemp.log
			echo "============================">>/home/ccbm/zwb/temp/zwbtemp.log
			echo "" >>/home/ccbm/zwb/temp/zwbtemp.log
			#pid=`ps -ef | grep zwb_crontab_start | grep -v grep |awk '{print $2}'`

			#kill -9 ${pid}
			#exit 0
			break
		fi


	done
}


main(){
	while true
	do
		flag=`cat /home/ccbm/zwb/temp/flag.txt`
		##告警时间段##
                hour=`date +"%k"`
		if [ $hour -ge 0 -a $hour -le 24 -a $flag -eq 0 ]
		then
			#flag.txt标记状态，1结束
			echo -n '1' > /home/ccbm/zwb/temp/flag.txt
			now_date=`date  +"%Y-%m-%d %H:%M:%S"`
			pid=`ps -ef | grep zwb_crontab_start | grep -v grep |awk '{print $2}'`
			echo "" >>/home/ccbm/zwb/temp/zwbtemp.log
			echo "============================">>/home/ccbm/zwb/temp/zwbtemp.log
			echo "$now_date :PID:$pid crontab_start" >>/home/ccbm/zwb/temp/zwbtemp.log
			echo "============================">>/home/ccbm/zwb/temp/zwbtemp.log
			echo "" >>/home/ccbm/zwb/temp/zwbtemp.log


			crontab_start
		else
			now_date=`date  +"%Y-%m-%d %H:%M:%S"`
			pid=`ps -ef | grep zwb_crontab_start | grep -v grep |awk '{print $2}'`
			echo "" >>/home/ccbm/zwb/temp/zwbtemp.log
			echo "============================">>/home/ccbm/zwb/temp/zwbtemp.log
			echo "$now_date :PID:$pid crontab_stop" >>/home/ccbm/zwb/temp/zwbtemp.log
			echo "============================">>/home/ccbm/zwb/temp/zwbtemp.log
			echo "" >>/home/ccbm/zwb/temp/zwbtemp.log

			#kill -9 ${pid}

		fi

		sleep 300

	done
}

main $*
