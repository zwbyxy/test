#!/bin/bash
##pgw迁移脚本
mkdir -p ~/zwb/backfile
mkdir -p ~/zwb/basefile
mkdir -p ~/zwb/temp
##业务ip€节点号€root密码€管理ip€主机名
iplist=(
10.48.92.200€x€zBhV%suI3k€10.48.93.200€FJXM-DM-HW-SIS-21
10.48.92.199€x€zBhV%suI3k€10.48.93.199€FJXM-DM-HW-SIS-20
10.48.84.150€x€huawei€10.48.85.150€FJXM-DM2-HW-PAYMENT-10
10.48.84.151€x€huawei€10.48.85.151€FJXM-DM2-HW-PAYMENT-11
10.48.84.152€x€huawei€10.48.85.152€FJXM-DM2-HW-PAYMENT-12
10.48.84.153€x€huawei€10.48.85.153€FJXM-DM2-HW-PAYMENT-13
10.48.84.154€x€huawei€10.48.85.154€FJXM-DM2-HW-PAYMENT-14
10.48.84.155€x€huawei€10.48.85.155€FJXM-DM2-HW-PAYMENT-15
)









zwbscp(){
rm -rf ~/.ssh/known_hosts
if [ $# -ne 2 ]
then
echo "传参不是2个，退出"
exit 1
fi
[ -d ~/zwb/temp/home ] && {
/usr/bin/expect <<EOF
spawn scp -rp /home/ccbm/zwb/temp/home root@${1}:/
set timeout 60000
expect {
    "refused"
    {
        exit
    }
    "Permission"
    {
        send_user "[exec echo \"Error:Password is wrong\"]"
        exit
    }
    "(yes/no)?"
    {
        send "yes\r"
        expect "*?assword:" { send "${2}\r"}
    }
    "*?assword:"
    {
       send "${2}\r"
    }
}
expect eof


spawn scp -rp /home/ccbm/zwb/temp/etc/hosts root@${1}:/etc/hosts
set timeout 60000
expect {
    "refused"
    {
        exit
    }
    "Permission"
    {
        send_user "[exec echo \"Error:Password is wrong\"]"
        exit
    }
    "(yes/no)?"
    {
        send "yes\r"
        expect "*?assword:" { send "${2}\r"}
    }
    "*?assword:"
    {
       send "${2}\r"
    }
}
expect eof


EOF
rm -rf ~/.ssh/known_hosts
}

}




main(){
for array in ${iplist[*]}
do
  ip=`echo ${array} |awk -F "€" '{print $1}'`
  passwd=`echo ${array} |awk -F "€" '{print $3}'`
  glip=`echo ${array} |awk -F "€" '{print $4}'`
  hostname=`echo ${array} |awk -F "€" '{print $5}'`
  nid=`echo ${array} |awk -F "€" '{print $2}'`
 # backup ${array}
  if [ $? -eq 0 ] 
    then
        ## echo "{array} 备份成功。"
        cd ~/zwb/temp/
        if [ $? -eq 0 ]
           then
               rm -rf ~/zwb/temp/home
               rm -rf ~/zwb/temp/etc
               tar zxvf ~/zwb/basefile/etc.tar.gz &>/dev/null 
               tar zxvf ~/zwb/basefile/home.tar.gz &>/dev/null
               sleep 50
               ##修改配置文件
               sed -i "s#10.48.84.167#${ip}#g" ~/zwb/temp/etc/hosts
               sed -i "s#10.48.85.167#${glip}#g" ~/zwb/temp/etc/hosts
               sed -i "s#FJXM-DM2-HW-DSDP-03#${hostname}#g" ~/zwb/temp/etc/hosts
			   
               sed -i "s#admintooladrr=10.48.84.167#admintooladrr=${ip}#g" ~/zwb/temp/home/payment/payment_container/bin/compinfo.cfg
               sed -i "s#admintooladrr=10.48.84.167#admintooladrr=${ip}#g" ~/zwb/temp/home/payment/bin/compinfo.cfg
               sed -i "s#nodeinfo.ipaddr=10.48.84.167#nodeinfo.ipaddr=${ip}#g" ~/zwb/temp/home/payment/payment_container/modules/payment/conf/bme.basic.properties
               sed -i "s#om.global.localIP=10.48.84.167#om.global.localIP=${ip}#g" ~/zwb/temp/home/payment/payment_container/modules/payment/conf/bme.basic.properties
               sed -i "s#om.module.IP=10.48.84.167#om.module.IP=${ip}#g" ~/zwb/temp/home/payment/payment_container/modules/payment/conf/bme.basic.properties
               sed -i "s#om.module.extField=ServiceIP=10.48.84.167#om.module.extField=ServiceIP=${ip}#g" ~/zwb/temp/home/payment/payment_container/modules/payment/conf/bme.basic.properties


               sed -i "s#nodeinfo.ipaddr=10.48.84.167#nodeinfo.ipaddr=${ip}#g" ~/zwb/temp/home/payment/payment_container/modules/payment/conf/bme.properties

               sed -i "s#dsf.protocol.tcp.address=10.48.84.167#dsf.protocol.tcp.address=${ip}#g" ~/zwb/temp/home/payment/payment_container/modules/payment/conf/dsf.properties

               sed -i "s#commons.log.serverIp=10.48.84.167#commons.log.serverIp=${ip}#g" ~/zwb/temp/home/payment/payment_container/modules/payment/conf/payment.monitor.properties
               sed -i "s#payment.localIP=10.48.84.167#payment.localIP=${ip}#g" ~/zwb/temp/home/payment/payment_container/modules/payment/conf/payment.monitor.properties

               sed -i "s#localIP=10.48.84.167#localIP=${ip}#g" ~/zwb/temp/home/payment/payment_container/modules/payment/conf/payment.properties
               
			   sed -i "s#localip=10.48.84.167#localip=${ip}#g"  ~/zwb/temp/home/payment/uniAgent/conf/uoa.properties
			   sed -i "s#agent.sources.paymentcompAlarmSrc.moduleIp = 10.48.84.167#agent.sources.paymentcompAlarmSrc.moduleIp = ${ip}#g"  ~/zwb/temp/home/payment/uniAgent/conf/flume_agent.conf
               sed -i "s#hostname=FJXM-DM2-HW-DSDP-03#hostname=${hostname}#g"  ~/zwb/temp/home/payment/uniAgent/conf/uoa.properties

			   ##允许root直连
               sed -i "s#PermitRootLogin no#PermitRootLogin yes#g" ~/zwb/temp/etc/ssh/sshd_config
               sed -i "s#UsePrivilegeSeparation sandbox##g" ~/zwb/temp/etc/ssh/sshd_config
               ##保留远程账号
              # keepaccount ${ip} ${passwd} #&>/dev/null
              # [ -f ~/zwb/temp/${ip}_shadow -a ~/zwb/temp/${ip}_passwd ] && {
              #   grep -v "^root" ~/zwb/temp/etc/passwd > ~/zwb/temp/etc/passwd_temp
              #   grep -v "^root" ~/zwb/temp/etc/shadow > ~/zwb/temp/etc/shadow_temp
              #   grep "^root" ~/zwb/temp/${ip}_passwd >> ~/zwb/temp/etc/passwd_temp
              #   grep "^root" ~/zwb/temp/${ip}_shadow >> ~/zwb/temp/etc/shadow_temp
              #   cat ~/zwb/temp/etc/passwd_temp > ~/zwb/temp/etc/passwd
              #   cat ~/zwb/temp/etc/shadow_temp > ~/zwb/temp/etc/shadow
              #     }
               ##拷贝数据到目标主机
               zwbscp ${ip} ${passwd} #&>/dev/null
	       ##是否使用远程主机账号密码
              ## zwbscpaccount ${ip} ${passwd} #&>/dev/null
               echo "${ip} 已经处理完成。"
			   echo "${ip} 已经处理完成。">> ~/zwb/temp/zwb.log
        fi
    else 
        echo "{array} 失败！！"
        echo "{array} 失败！！" >> ~/zwb/temp/zwb_failed.log
        continue
  fi
done
}



main $*
