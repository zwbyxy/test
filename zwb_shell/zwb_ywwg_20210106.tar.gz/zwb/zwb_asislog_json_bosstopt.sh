#!/bin/bash
date=`date +%Y%m%d`
namelist=(
Opr€actionReasonID€BillFlg€OprTime€IDV€BizType€OldIDV€OprNumb€EffetiTime€Source€SPID€BizCode
)

for array in ${namelist[*]}
do
Opr=`echo ${array} |awk -F "€" '{print $1}'`
actionReasonID=`echo ${array} |awk -F "€" '{print $2}'`
BillFlg=`echo ${array} |awk -F "€" '{print $3}'`
OprTime=`echo ${array} |awk -F "€" '{print $4}'`
IDV=`echo ${array} |awk -F "€" '{print $5}'`
BizType=`echo ${array} |awk -F "€" '{print $6}'`
OldIDV=`echo ${array} |awk -F "€" '{print $7}'`
OprNumb=`echo ${array} |awk -F "€" '{print $8}'`
EffetiTime=`echo ${array} |awk -F "€" '{print $9}'`
Source=`echo ${array} |awk -F "€" '{print $10}'`
SPID=`echo ${array} |awk -F "€" '{print $11}'`
BizCode=`echo ${array} |awk -F "€" '{print $12}'`




dos2unix ~/zwb/temp/boss_to_pt.txt  
sed -i 's#\\##g' ~/zwb/temp/boss_to_pt.txt
 sed -ie 's/[[:space:]]*//g' ~/zwb/temp/boss_to_pt.txt

grep -Po "${Opr}[\" :]+\K[^\"]+"  ~/zwb/temp/boss_to_pt.txt |grep -v "^," > ~/zwb/temp/Opr_field.txt
grep -Po "${actionReasonID}[\" :]+\K[^\"]+"  ~/zwb/temp/boss_to_pt.txt|grep -v "^," > ~/zwb/temp/actionReasonID_field.txt
grep -Po "${BillFlg}[\" :]+\K[^\"]+"  ~/zwb/temp/boss_to_pt.txt|grep -v "^," > ~/zwb/temp/BillFlg_field.txt
grep -Po "${OprTime}[\" :]+\K[^\"]+"  ~/zwb/temp/boss_to_pt.txt|grep -v "^," > ~/zwb/temp/OprTime_field.txt
grep -Po "${IDV}[\" :]+\K[^\"]+"  ~/zwb/temp/boss_to_pt.txt|grep -v "^," > ~/zwb/temp/IDV_field.txt
grep -Po "${BizType}[\" :]+\K[^\"]+"  ~/zwb/temp/boss_to_pt.txt|grep -v "^," > ~/zwb/temp/BizType_field.txt
grep -Po "${OldIDV}[\" :]+\K[^\"]+"  ~/zwb/temp/boss_to_pt.txt|grep -v "^," > ~/zwb/temp/OldIDV_field.txt

grep -Po "${OprNumb}[\" :]+\K[^\"]+"  ~/zwb/temp/boss_to_pt.txt|grep -v "^," > ~/zwb/temp/OprNumb_field.txt
grep -Po "${EffetiTime}[\" :]+\K[^\"]+"  ~/zwb/temp/boss_to_pt.txt|grep -v "^," > ~/zwb/temp/EffetiTime_field.txt
grep -Po "${Source}[\" :]+\K[^\"]+"  ~/zwb/temp/boss_to_pt.txt|grep -v "^," > ~/zwb/temp/Source_field.txt
grep -Po "${SPID}[\" :]+\K[^\"]+"  ~/zwb/temp/boss_to_pt.txt|grep -v "^," > ~/zwb/temp/SPID_field.txt
grep -Po "${BizCode}[\" :]+\K[^\"]+"  ~/zwb/temp/boss_to_pt.txt|grep -v "^," > ~/zwb/temp/BizCode_field.txt

mkdir -p ~/zwb/es_cdr/
paste -d"|" ~/zwb/temp/Opr_field.txt ~/zwb/temp/actionReasonID_field.txt ~/zwb/temp/BillFlg_field.txt ~/zwb/temp/OprTime_field.txt ~/zwb/temp/IDV_field.txt ~/zwb/temp/BizType_field.txt ~/zwb/temp/OldIDV_field.txt ~/zwb/temp/OprNumb_field.txt ~/zwb/temp/EffetiTime_field.txt ~/zwb/temp/Source_field.txt ~/zwb/temp/SPID_field.txt ~/zwb/temp/BizCode_field.txt >>~/zwb/es_cdr/boss_to_pt_${date}.txt

done
