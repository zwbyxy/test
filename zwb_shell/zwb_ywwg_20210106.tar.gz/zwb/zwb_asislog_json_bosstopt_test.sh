#!/bin/bash
date=`date +%Y%m%d`
echo -n "" >~/zwb/temp/Opr_field.txt
echo -n ""> ~/zwb/temp/actionReasonID_field.txt
echo -n "">~/zwb/temp/BillFlg_field.txt
echo -n "">~/zwb/temp/OprTime_field.txt
echo -n "">~/zwb/temp/IDV_field.txt
echo -n "">~/zwb/temp/BizType_field.txt
echo -n "">~/zwb/temp/OldIDV_field.txt
echo -n ""> ~/zwb/temp/OprNumb_field.txt
echo -n "">~/zwb/temp/EffetiTime_field.txt
echo -n "">~/zwb/temp/Source_field.txt
echo -n "">~/zwb/temp/SPID_field.txt
echo -n "">~/zwb/temp/BizCode_field.txt



#dos2unix ~/zwb/temp/boss_to_pt_test.txt
#sed -i 's#\\##g' ~/zwb/temp/boss_to_pt_test.txt
#sed -ie 's/[[:space:]]*//g' ~/zwb/temp/boss_to_pt_test.txt
for i in `cat  ~/zwb/temp/boss_to_pt_test.txt`
do
if [ ` echo -n ${i} |grep -o '\"IDV\":' | wc -l` -gt 0  ]
then
count=`echo -n ${i}|grep -o '\"IDV\":' | wc -l`
for ((a=2;a<=${count}+1;a++));  
do   
#echo "${a}"  
##awk 传参

echo -n ${i} |awk -F '\"Opr\":' '{print $a_v }' a_v=${a}  | awk -F '\"' '{print $2 }'   >>  ~/zwb/temp/Opr_field.txt
echo -n ${i} |awk -F '\"actionReasonID\":' '{print $a_v}' a_v=${a}   | awk -F '\"' '{print $2}'  >>  ~/zwb/temp/actionReasonID_field.txt
echo -n ${i} |awk -F '\"BillFlg\":' '{print $a_v}' a_v=${a} | awk -F '\"' '{print 42}' >>  ~/zwb/temp/BillFlg_field.txt
echo -n ${i} |awk -F '\"OprTime\":' '{print $a_v}' a_v=${a} | awk -F '\"' '{print $2}'  >>  ~/zwb/temp/OprTime_field.txt
echo -n ${i} |awk -F '\"IDV\":' '{print $a_v}' a_v=${a} | awk -F '\"' '{print $2}' >>  ~/zwb/temp/IDV_field.txt
echo -n ${i} |awk -F '\"BizType\":' '{print $a_v}'  a_v=${a} | awk -F '\"' '{print $2}'  >>  ~/zwb/temp/BizType_field.txt
echo -n ${i} |awk -F '\"OldIDV\":' '{print $a_v}' a_v=${a} | awk -F '\"' '{print $2}'  >>  ~/zwb/temp/OldIDV_field.txt
echo -n ${i} |awk -F '\"OprNumb\":' '{print $a_v}' a_v=${a} | awk -F '\"' '{print $2}'  >>  ~/zwb/temp/OprNumb_field.txt
echo -n ${i} |awk -F '\"EffetiTime\":' '{print $a_v}' a_v=${a} | awk -F '\"' '{print $2}'  >>  ~/zwb/temp/EffetiTime_field.txt
echo -n ${i} |awk -F '\"Source\":' '{print $a_v}' a_v=${a} | awk -F '\"' '{print $2}'  >>  ~/zwb/temp/Source_field.txt
echo -n ${i} |awk -F '\"SPID\":' '{print $a_v}' a_v=${a} | awk -F '\"' '{print $2}'  >>  ~/zwb/temp/SPID_field.txt
echo -n ${i} |awk -F '\"BizCode\":' '{print $a_v}'  a_v=${a}| awk -F '\"' '{print $2}' >>  ~/zwb/temp/BizCode_field.txt


done  
 


else
echo ${i} |awk -F '\"Opr\":' '{print $2}'  | awk -F '\"' '{print $2}' >>  ~/zwb/temp/Opr_field.txt
echo ${i} |awk -F '\"actionReasonID\":' '{print $2}'   | awk -F '\"' '{print $2}'  >>  ~/zwb/temp/actionReasonID_field.txt
echo ${i} |awk -F '\"BillFlg\":' '{print $2}'  | awk -F '\"' '{print 42}' >>  ~/zwb/temp/BillFlg_field.txt
echo ${i} |awk -F '\"OprTime\":' '{print $2}'  | awk -F '\"' '{print $2}'  >>  ~/zwb/temp/OprTime_field.txt
echo ${i} |awk -F '\"IDV\":' '{print $2}'  | awk -F '\"' '{print $2}' >>~/zwb/temp/IDV_field.txt
echo ${i} |awk -F '\"BizType\":' '{print $2}'   | awk -F '\"' '{print $2}'  >>  ~/zwb/temp/BizType_field.txt
echo ${i} |awk -F '\"OldIDV\":' '{print $2}'  | awk -F '\"' '{print $2}'  >>  ~/zwb/temp/OldIDV_field.txt
echo ${i} |awk -F '\"OprNumb\":' '{print $2}'  | awk -F '\"' '{print $2}'  >>  ~/zwb/temp/OprNumb_field.txt
echo ${i} |awk -F '\"EffetiTime\":' '{print $2}'  | awk -F '\"' '{print $2}'  >>  ~/zwb/temp/EffetiTime_field.txt
echo ${i} |awk -F '\"Source\":' '{print $2}' | awk -F '\"' '{print $2}'  >>  ~/zwb/temp/Source_field.txt
echo ${i} |awk -F '\"SPID\":' '{print $2}'  | awk -F '\"' '{print $2}'  >>  ~/zwb/temp/SPID_field.txt
echo ${i} |awk -F '\"BizCode\":' '{print $2}'  | awk -F '\"' '{print $2}' >>  ~/zwb/temp/BizCode_field.txt
fi

done
mkdir -p ~/zwb/es_cdr/
paste -d"|" ~/zwb/temp/Opr_field.txt ~/zwb/temp/actionReasonID_field.txt ~/zwb/temp/BillFlg_field.txt ~/zwb/temp/OprTime_field.txt ~/zwb/temp/IDV_field.txt ~/zwb/temp
/BizType_field.txt ~/zwb/temp/OldIDV_field.txt ~/zwb/temp/OprNumb_field.txt ~/zwb/temp/EffetiTime_field.txt ~/zwb/temp/Source_field.txt ~/zwb/temp/SPID_field.txt ~/zw
b/temp/BizCode_field.txt >~/zwb/es_cdr/test_boss_to_pt_${date}.txt
