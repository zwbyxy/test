#获取es成功条数、失败条数
#sh /home/ccbm/zwb/es.sh
#sag参数时间搓、手机号码、成功率内容，组装到sms.txt 
time=$(date "+%Y%m%d%H%M%S")
phone=`cat /home/ccbm/zwb/phone.txt`
SucNum=`cat  /home/ccbm/zwb/success_count.txt`
TotalNum=`cat /home/ccbm/zwb/all_count.txt`
sed -i "s/€1/${time}/g" sms.txt
sed -i "s/€2/${phone}/g" sms.txt
echo -e "Success rate 0\c" > rate.txt
echo "scale = 2; $SucNum / $TotalNum" | bc >>rate.txt
ratesul=`cat rate.txt`
sed -i "s/€3/${ratesul}/g" sms.txt

#投递请求
sh /home/ccbm/zwb/sendsms.sh


