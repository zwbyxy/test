#!/usr/bin/expect
spawn scp -rp /home/ccbm/zwb/check_newlogfile.sh ecpfep@10.124.72.47:/home/ecpfep/zwb/
set timeout 60000
expect {
    "refused"
    {
        exit
    }
    "Permission"
    {
        send_user "[exec echo \"Error:Password is wrong\"]"
        exit
    }
    "(yes/no)?"
    {
        send "yes\r"
        expect "*?assword:" { send "Ch7\$A1%!Re\r"}
    }
    "*?assword:"
    {
       send "Ch7\$A1%!Re\r"
    }
}
expect eof


