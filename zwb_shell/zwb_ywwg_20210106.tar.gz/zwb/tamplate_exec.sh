curl -XGET '10.124.129.224:9200/provice_member/member_record/_delete_by_query'  -H 'Content-Type: application/json' -d'
{
  "query": {
  	"bool":{
  	  "must":{
	    "match": {
	      "msisdn": "19839360076"
            },
          "match": {
	      "enterpriseID": "30000683"
             }
       },
       "filter": {
       	"range":{
	      "@timestamp": {
	      	"gte":"2020-07-28T16:00:00.000Z"
	      	}
             }
       }
  	}
  }
}'
