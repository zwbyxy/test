##所有量
curl -XGET '10.124.72.189:9200/delivery_detail/delivery_record/_search?pretty'  -H 'Content-Type: application/json' -d'
{
  "from" : 0 ,
  "size" : 0 ,
    "query": {
    "bool": {
      "must": [
        {
          "match": {
            "enterpriseID": "30000042"
          }
        }
      ],
      "filter": {
        "range": {
          "colorPushTime": {
            "gte": "20190824000000001",
            "lt":  "20190824235959999"
          }
        }
      }
    
        }
     },
    "aggs" : {
        "return_sum" : {
            "sum" : {
                "field" : "chargeCount"
            }
        }
    }
}
' > /home/ccbm/zwb/30000042_all_json.txt

##成功量

curl -XGET '10.124.72.189:9200/delivery_detail/delivery_record/_search?pretty'  -H 'Content-Type: application/json' -d'
{
  "from" : 0 ,
  "size" : 0 ,
    "query": {
    "bool": {
      "must": [
        {
          "match": {
            "enterpriseID": "30000042"
          }
        }
      ],
      "filter": {
        "range": {
          "colorPushTime": {
            "gte": "20190824000000001",
            "lt":  "20190824235959999"
          }
        }
      },
    "minimum_should_match": 1,
                                        "should": [{
                                                "match_phrase": {
                                                        "deliveryResult": "0"
                                                }
                                        },
                                        {
                                                "match_phrase": {
                                                        "deliveryResult": "1"
                                                }
                                        },
                                        {
                                                "match_phrase": {
                                                        "deliveryResult": "2"
                                                }
                                        },

                                                                            {
                                                "match_phrase": {
                                                        "deliveryResult": "999"
                                                }
                                        },
                                        {
                                                "match_phrase": {
                                                        "deliveryResult": "8"
                                                }
                                        }]
        }
     },
    "aggs" : {
        "return_sum" : {
            "sum" : {
                "field" : "chargeCount"
            }
        }
    }
}
' > /home/ccbm/zwb/30000042_succes_json.txt

grep -A1 "hits" /home/ccbm/zwb/30000042_all_json.txt  |grep total |awk -F ": " '{print $2}' |awk -F "," '{print $1}' >/home/ccbm/zwb/all_count.txt
grep -A1 "hits" /home/ccbm/zwb/30000042_succes_json.txt  |grep total |awk -F ": " '{print $2}' |awk -F "," '{print $1}'>/home/ccbm/zwb/success_count.txt

