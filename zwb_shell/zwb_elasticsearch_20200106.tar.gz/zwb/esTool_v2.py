#encoding:utf-8
from __future__ import print_function
import csv
from elasticsearch import Elasticsearch
import sys

#python2 中文编码问题解决UnicodeEncodeError: 'ascii' codec can't encode characters in position 28-50: ordinal not in range(128)
reload(sys)
sys.setdefaultencoding('utf8')

# 查看参数配置：https://pypi.org/project/elasticsearch/
#es = Elasticsearch(hosts="http://10.124.72.189:9200/", http_auth=('abc','dataanalysis'))
es = Elasticsearch(hosts="http://10.124.72.189:9200/")
query_json = {
    "from": 0,
    "size": 1,
    "query": {
        "bool": {
            "must": [{
                "bool": {
                    "should": [{
                        "term": {
                            "enterpriseID": {
                                "value": "30000303",
                                "boost": 1
                            }
                        }
                    }]
                }
            },
            {
                "bool": {
                    "should": [{
                        "term": {
                            "deliveryResult": {
                                "value": "0",
                                "boost": 1
                            }
                        }
                    },
                    {
                        "term": {
                            "deliveryResult": {
                                "value": "1",
                                "boost": 1
                            }
                        }
                    },
                    {
                        "term": {
                            "deliveryResult": {
                                "value": "2",
                                "boost": 1
                            }
                        }
                    },
                    {
                        "term": {
                            "deliveryResult": {
                                "value": "8",
                                "boost": 1
                            }
                        }
                    },
                    {
                        "term": {
                            "deliveryResult": {
                                "value": "999",
                                "boost": 1
                            }
                        }
                    }]
                }
            },
            {
                "range": {
                    "@timestamp": {
                        "from": "2020-11-03T16:00:00.000Z",
                        "to": "2020-11-04T16:00:00.000Z",
                        "boost": 1
                    }
                }
            }]
        }
    }
}
query = es.search(index='delivery_detail',body=query_json,scroll='5m',size=100)

results = query['hits']['hits'] # es查询出的结果第一页
total = query['hits']['total']  # es查询出的结果总量
scroll_id = query['_scroll_id'] # 游标用于输出es查询出的所有结果
sum = 0
forallcount = int(total/100)
for i in range(0, int(total/100)+1):
    # scroll参数必须指定否则会报错
    query_scroll = es.scroll(scroll_id=scroll_id,scroll='5m')['hits']['hits']
    results += query_scroll

#python2只有3个参数，并且无法指定utf-8编码
#with open('./data/event_title.csv','w',newline='',encoding='utf-8') as flow:
with open('./data/event_title.csv','w') as flow:
    csv_writer = csv.writer(flow)
    print('需要导出总量：%d'%len(results))
    for res in results:
        #print(res)
        #如果去掉的字典值为空会报错：TypeError: coercing to Unicode: need string or buffer, NoneType Found，需要转换str
        csv_writer.writerow([str(res['_id'])+','+str(res['_source']['pushColorID'])+','+str(res['_source']['pushColorContent'])])
        sum += 1
        #print('\r导出进度：%d%%'%(sum/forallcount),end='')
        print("\r导出进度: {}%: ".format(sum/forallcount), "▋" * (sum/forallcount // 2), end="")
        
print('')
print('done!')
# print(es.info())
