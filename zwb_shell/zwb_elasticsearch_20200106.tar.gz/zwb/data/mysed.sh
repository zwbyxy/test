#!/bin/bash
sed -i "s#\"##g" event_title.csv
