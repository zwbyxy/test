#!/bin/bash
##size默认最大10000,需要通过设置最大值curl -H "Content-Type: application/json" -XPUT 10.124.72.189:9200/delivery_detail/_settings -d '{"index.max_result_window":"500000"}'
#第二个statID之后，是字段可为空的字段，通过获取statID的值来代替(本次取值根据结算话单字段提取，如果是经分话单还要关注下其他字段，其中变量字段结算话单规范不需要提供),字段es都能找到，无需数据库重新捞取
rm -f ~/zwb/rexian_esexport_shell/es_cdr/es_cdr_rexian.txt
curl -XGET '10.124.72.189:9200/delivery_detail/delivery_record/_search?pretty'  -H 'Content-Type: application/json' -d'
{
"from": 0,
"size": 300000,
  "query": {
    "bool": {
      "must": [
        {
          "bool": {
            "should": [
              {
                "term": {
                  "enterpriseID": {
                    "value": "50000102",
                    "boost": 1
                  }
                }
              }
            ]


          }
        }, 
{
          "bool": {
            "should": [
              {
                "term": {
                  "deliveryResult": {
                    "value": "0",
                    "boost": 1
                  }
                }
              },
                                        {
                "term": {
                  "deliveryResult": {
                    "value": "1",
                    "boost": 1
                  }
                }
              },
                                        {
                "term": {
                  "deliveryResult": {
                    "value": "2",
                    "boost": 1
                  }
                }
              },
                                        {
                "term": {
                  "deliveryResult": {
                    "value": "8",
                    "boost": 1
                  }
                }
              },
                          {
                "term": {
                  "deliveryResult": {
                    "value": "999",
                    "boost": 1
                  }
                }
              }
            ]


          }
        },


        {
          "range": {
            "@timestamp": {
              "from": "2020-10-28T16:00:00.000Z",
              "to": "2020-10-29T16:00:00.000Z",
              "include_lower": true,
              "include_upper": true,
              "boost": 1
            }
          }
        }
      ]
    }
  }

}
' > ~/zwb/rexian_esexport_shell/temp/es_json.txt

date=`date +%Y%m%d`

###将 \" 特殊字符替换为空，如果不替换grep -Po 解析json格式有问题
sed -i "s#[\\\]\"##g" ~/zwb/rexian_esexport_shell/temp/es_json.txt

namelist=(
serviceID€callingPhone€calledPhone€contRuleID€statID€callingIdentity€callingTime€noSendColorReason€colorPushTime€colorSendDelayTime€colorSendType€noUssdSendResult€ussdSendResult€pushColorContent€pushColorID€pushColorBoxID€callTimes€forwardPhone€chargeNumber€enterpriseID€enterpriseCode€enterpriseName€enterpriseType€serviceType€subServiceType€provinceIdentify€cityIdentify€sessionIdentify€contentIdentify€target€deliveryReqTime€deliveryRspTime€deliveryResultReqTime€deliveryResultRspTime€deliveryRspCode€deliveryResult€src€chargeCount€callEvent€callProcess€msgType€statID€statID€statID€owner€parentEnterpriseID€parentEnterpriseCode€parentEnterpriseName
)

for array in ${namelist[*]}
do
serviceID=`echo ${array} |awk -F "€" '{print $1}'`
callingPhone=`echo ${array} |awk -F "€" '{print $2}'`
calledPhone=`echo ${array} |awk -F "€" '{print $3}'`
contRuleID=`echo ${array} |awk -F "€" '{print $4}'`
statID=`echo ${array} |awk -F "€" '{print $5}'`
callingIdentity=`echo ${array} |awk -F "€" '{print $6}'`
callingTime=`echo ${array} |awk -F "€" '{print $7}'`
noSendColorReason=`echo ${array} |awk -F "€" '{print $8}'`
colorPushTime=`echo ${array} |awk -F "€" '{print $9}'`
colorSendDelayTime=`echo ${array} |awk -F "€" '{print $10}'`
colorSendType=`echo ${array} |awk -F "€" '{print $11}'`
noUssdSendResult=`echo ${array} |awk -F "€" '{print $12}'`
ussdSendResult=`echo ${array} |awk -F "€" '{print $13}'`
pushColorContent=`echo ${array} |awk -F "€" '{print $14}'`
pushColorID=`echo ${array} |awk -F "€" '{print $15}'`
pushColorBoxID=`echo ${array} |awk -F "€" '{print $16}'`
callTimes=`echo ${array} |awk -F "€" '{print $17}'`
forwardPhone=`echo ${array} |awk -F "€" '{print $18}'`
chargeNumber=`echo ${array} |awk -F "€" '{print $19}'`
enterpriseID=`echo ${array} |awk -F "€" '{print $20}'`
enterpriseCode=`echo ${array} |awk -F "€" '{print $21}'`
enterpriseName=`echo ${array} |awk -F "€" '{print $22}'`
enterpriseType=`echo ${array} |awk -F "€" '{print $23}'`
serviceType=`echo ${array} |awk -F "€" '{print $24}'`
subServiceType=`echo ${array} |awk -F "€" '{print $25}'`
provinceIdentify=`echo ${array} |awk -F "€" '{print $26}'`
cityIdentify=`echo ${array} |awk -F "€" '{print $27}'`
sessionIdentify=`echo ${array} |awk -F "€" '{print $28}'`
contentIdentify=`echo ${array} |awk -F "€" '{print $29}'`
target=`echo ${array} |awk -F "€" '{print $30}'`
deliveryReqTime=`echo ${array} |awk -F "€" '{print $31}'`
deliveryRspTime=`echo ${array} |awk -F "€" '{print $32}'`
deliveryResultReqTime=`echo ${array} |awk -F "€" '{print $33}'`
deliveryResultRspTime=`echo ${array} |awk -F "€" '{print $34}'`
deliveryRspCode=`echo ${array} |awk -F "€" '{print $35}'`
deliveryResult=`echo ${array} |awk -F "€" '{print $36}'`
src=`echo ${array} |awk -F "€" '{print $37}'`
chargeCount=`echo ${array} |awk -F "€" '{print $38}'`
callEvent=`echo ${array} |awk -F "€" '{print $39}'`
callProcess=`echo ${array} |awk -F "€" '{print $40}'`
msgType=`echo ${array} |awk -F "€" '{print $41}'`
owner=`echo ${array} |awk -F "€" '{print $45}'`
parentEnterpriseID=`echo ${array} |awk -F "€" '{print $46}'`
parentEnterpriseCode=`echo ${array} |awk -F "€" '{print $47}'`
parentEnterpriseName=`echo ${array} |awk -F "€" '{print $48}'`

#orderId=`echo ${array} |awk -F "€" '{print $46}'`
#subscribeId=`echo ${array} |awk -F "€" '{print $47}'`
#contentArgs=`echo ${array} |awk -F "€" '{print $48}'`
#deliveryTimestamp=`echo ${array} |awk -F "€" '{print $49}'`
#packageCode=`echo ${array} |awk -F "€" '{print $50}'`
#productCode=`echo ${array} |awk -F "€" '{print $51}'`
#timestamp=`echo ${array} |awk -F "€" '{print $52}'`
#sensitiveWords=`echo ${array} |awk -F "€" '{print $53}'`

grep -Po "${serviceID}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/serviceID
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/serviceID

grep -Po "${callingPhone}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/callingPhone
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/callingPhone

grep -Po "${calledPhone}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/calledPhone
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/calledPhone

grep -Po "${contRuleID}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/contRuleID
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/contRuleID
grep -Po "${statID}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/statID
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/statID

grep -Po "${callingIdentity}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/callingIdentity
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/callingIdentity

grep -Po "${callingTime}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/callingTime
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/callingTime

grep -Po "${noSendColorReason}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/noSendColorReason
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/noSendColorReason
grep -Po "${colorPushTime}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/colorPushTime
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/colorPushTime

grep -Po "${colorSendDelayTime}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/colorSendDelayTime
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/colorSendDelayTime

grep -Po "${colorSendType}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/colorSendType
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/colorSendType

grep -Po "${noUssdSendResult}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/noUssdSendResult
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/noUssdSendResult
grep -Po "${ussdSendResult}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/ussdSendResult
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/ussdSendResult

grep -Po "${pushColorContent}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/pushColorContent
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/pushColorContent

grep -Po "${pushColorID}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/pushColorID
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/pushColorID

grep -Po "${pushColorBoxID}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/pushColorBoxID
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/pushColorBoxID
grep -Po "${callTimes}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/callTimes
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/callTimes

grep -Po "${forwardPhone}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/forwardPhone
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/forwardPhone

grep -Po "${chargeNumber}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/chargeNumber
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/chargeNumber

grep -Po "${enterpriseID}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/enterpriseID
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/enterpriseID
grep -Po "${enterpriseCode}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/enterpriseCode
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/enterpriseCode

grep -Po "${enterpriseName}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/enterpriseName
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/enterpriseName

grep -Po "${enterpriseType}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/enterpriseType
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/enterpriseType

grep -Po "${serviceType}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/serviceType
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/serviceType
grep -Po "${subServiceType}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/subServiceType
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/subServiceType

grep -Po "${provinceIdentify}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/provinceIdentify
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/provinceIdentify

grep -Po "${cityIdentify}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/cityIdentify
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/cityIdentify

grep -Po "${sessionIdentify}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/sessionIdentify
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/sessionIdentify
grep -Po "${contentIdentify}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/contentIdentify
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/contentIdentify

grep -Po "${target}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/target
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/target

grep -Po "${deliveryReqTime}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/deliveryReqTime
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/deliveryReqTime

grep -Po "${deliveryRspTime}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/deliveryRspTime
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/deliveryRspTime
grep -Po "${deliveryResultReqTime}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/deliveryResultReqTime
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/deliveryResultReqTime

grep -Po "${deliveryResultRspTime}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/deliveryResultRspTime
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/deliveryResultRspTime

grep -Po "${deliveryRspCode}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/deliveryRspCode
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/deliveryRspCode

grep -Po "${deliveryResult}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/deliveryResult
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/deliveryResult
grep -Po "${src}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/src
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/src

grep -Po "${owner}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/owner
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/owner

grep -Po "${chargeCount}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/chargeCount
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/chargeCount

grep -Po "${callEvent}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/callEvent
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/callEvent
grep -Po "${callProcess}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/callProcess
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/callProcess

grep -Po "${parentEnterpriseID}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/parentEnterpriseID
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/parentEnterpriseID

grep -Po "${parentEnterpriseCode}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/parentEnterpriseCode
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/parentEnterpriseCode

grep -Po "${parentEnterpriseName}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/parentEnterpriseName
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/parentEnterpriseName
grep -Po "${msgType}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/msgType
sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/msgType

#grep -Po "${orderId}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/orderId
#sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/orderId

#grep -Po "${subscribeId}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/subscribeId
#sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/subscribeId

#grep -Po "${contentArgs}[\" :]+\K[^\"]*" ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/contentArgs
#sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/contentArgs
#grep -Po "${deliveryTimestamp}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/deliveryTimestamp
#sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/deliveryTimestamp

#grep -Po "${packageCode}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/packageCode
#sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/packageCode

#grep -Po "${productCode}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/productCode
#sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/productCode

#grep -Po "${timestamp}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/timestamp
#sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/timestamp
#grep -Po "${sensitiveWords}[\" :]+\K[^\"]+"  ~/zwb/rexian_esexport_shell/temp/es_json.txt > ~/zwb/rexian_esexport_shell/temp/sensitiveWords
#sed -i "s#|#l#g"  ~/zwb/rexian_esexport_shell/temp/sensitiveWords







paste -d"|" ~/zwb/rexian_esexport_shell/temp/serviceID ~/zwb/rexian_esexport_shell/temp/callingPhone ~/zwb/rexian_esexport_shell/temp/calledPhone ~/zwb/rexian_esexport_shell/temp/contRuleID ~/zwb/rexian_esexport_shell/temp/statID ~/zwb/rexian_esexport_shell/temp/callingIdentity ~/zwb/rexian_esexport_shell/temp/callingTime ~/zwb/rexian_esexport_shell/temp/noSendColorReason ~/zwb/rexian_esexport_shell/temp/colorPushTime ~/zwb/rexian_esexport_shell/temp/colorSendDelayTime ~/zwb/rexian_esexport_shell/temp/colorSendType ~/zwb/rexian_esexport_shell/temp/noUssdSendResult ~/zwb/rexian_esexport_shell/temp/ussdSendResult ~/zwb/rexian_esexport_shell/temp/pushColorContent ~/zwb/rexian_esexport_shell/temp/pushColorID ~/zwb/rexian_esexport_shell/temp/pushColorBoxID ~/zwb/rexian_esexport_shell/temp/callTimes ~/zwb/rexian_esexport_shell/temp/forwardPhone ~/zwb/rexian_esexport_shell/temp/chargeNumber ~/zwb/rexian_esexport_shell/temp/enterpriseID ~/zwb/rexian_esexport_shell/temp/enterpriseCode ~/zwb/rexian_esexport_shell/temp/enterpriseName ~/zwb/rexian_esexport_shell/temp/enterpriseType ~/zwb/rexian_esexport_shell/temp/serviceType ~/zwb/rexian_esexport_shell/temp/subServiceType ~/zwb/rexian_esexport_shell/temp/provinceIdentify ~/zwb/rexian_esexport_shell/temp/cityIdentify ~/zwb/rexian_esexport_shell/temp/sessionIdentify ~/zwb/rexian_esexport_shell/temp/contentIdentify ~/zwb/rexian_esexport_shell/temp/target ~/zwb/rexian_esexport_shell/temp/deliveryReqTime ~/zwb/rexian_esexport_shell/temp/deliveryRspTime ~/zwb/rexian_esexport_shell/temp/deliveryResultReqTime ~/zwb/rexian_esexport_shell/temp/deliveryResultRspTime ~/zwb/rexian_esexport_shell/temp/deliveryRspCode ~/zwb/rexian_esexport_shell/temp/deliveryResult ~/zwb/rexian_esexport_shell/temp/src ~/zwb/rexian_esexport_shell/temp/chargeCount ~/zwb/rexian_esexport_shell/temp/callEvent ~/zwb/rexian_esexport_shell/temp/callProcess  ~/zwb/rexian_esexport_shell/temp/msgType ~/zwb/rexian_esexport_shell/temp/statID ~/zwb/rexian_esexport_shell/temp/statID ~/zwb/rexian_esexport_shell/temp/statID ~/zwb/rexian_esexport_shell/temp/owner ~/zwb/rexian_esexport_shell/temp/parentEnterpriseID ~/zwb/rexian_esexport_shell/temp/parentEnterpriseCode ~/zwb/rexian_esexport_shell/temp/parentEnterpriseName  >> ~/zwb/rexian_esexport_shell/es_cdr/es_cdr_rexian.txt


#格式化话单，将“,|” 替换为“|”
cat ~/zwb/rexian_esexport_shell/es_cdr/es_cdr_rexian.txt  > ~/zwb/rexian_esexport_shell/es_cdr/es_cdr_rexian_temp.txt
sed  -i "s#,|#|#g"  ~/zwb/rexian_esexport_shell/es_cdr/es_cdr_rexian_temp.txt
sed  -i "s#null##g" ~/zwb/rexian_esexport_shell/es_cdr/es_cdr_rexian_temp.txt
sed  -i "s#,##g" ~/zwb/rexian_esexport_shell/es_cdr/es_cdr_rexian_temp.txt


done
