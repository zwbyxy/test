#!/bin/bash

#查询只能小于等于10000条,如果需要导出更多需要配置index.max_result_window参数
#"reason" : "Result window is too large, from + size must be less than or equal to: [10000] but was [50000]. See the scroll api for a more efficient way to request large data sets. This limit can be set by changing the [index.max_result_window] index level setting."

#每页个数设置
mygs=9999
#
#基于父企业脚本修改的。将子企业id传入父企业中
enterpriseID=50000102
parentEnterpriseID=${enterpriseID}
#模板id脚本此配置项无效
pushColorID=503219
#投递开始时间
#colorPushTimefrom=20200113080000000
colorPushTimefrom_temp="2020-05-01 00:00:00"
#投递结束时间
#colorPushTimeto=20200113085959999
colorPushTimeto_temp="2020-05-31 23:59:59"
#时间间隔单位秒
sc=300

##投递开始时间 、结束时间转换
seconds_start=`date -d "${colorPushTimefrom_temp}" +%s`       #得到时间戳 1578873600
colorPushTimefrom_var=`date -d @$seconds_start "+%Y%m%d%H%M%S"`000  #转化为20200113080060000

seconds_temp=`date -d "${colorPushTimeto_temp}" +%s`       #得到时间戳 1578873600
colorPushTimeto_var=`date -d @$seconds_temp "+%Y%m%d%H%M%S"`999  #转化为20200113080060000





##执行获取话单函数
exec_cdr(){
parentEnterpriseID=$1
pushColorID=$2
colorPushTimefrom=$3
colorPushTimeto=$4
mygs=$5
colorPushTimefrom_time=$6
colorPushTimeto_time=$7
##获取总total
cp -rp ~/zwb/e_jingfenrexian_total_tamplate.sh ~/zwb/temp/jingfenrexian_total_tamplate_temp.sh
sed -i "s#€ccc#${parentEnterpriseID}#g" ~/zwb/temp/jingfenrexian_total_tamplate_temp.sh
sed -i "s#€ddd#${pushColorID}#g" ~/zwb/temp/jingfenrexian_total_tamplate_temp.sh
sed -i "s#€eee#${colorPushTimefrom}#g" ~/zwb/temp/jingfenrexian_total_tamplate_temp.sh
sed -i "s#€fff#${colorPushTimeto}#g" ~/zwb/temp/jingfenrexian_total_tamplate_temp.sh
chmod 755 ~/zwb/temp/jingfenrexian_total_tamplate_temp.sh
sh ~/zwb/temp/jingfenrexian_total_tamplate_temp.sh
total=`grep -A1 hits ~/zwb/temp/es_get_total_jingfen_temp.txt |grep total |awk  '{print $3}' |awk -F "," '{print $1}'`


#时间段timetotal
cp -rp ~/zwb/e_jingfenrexian_rangetotal_tamplate.sh ~/zwb/temp/jingfenrexian_tamplate_temp.sh
sed -i "s#€ccc#${parentEnterpriseID}#g" ~/zwb/temp/jingfenrexian_tamplate_temp.sh
sed -i "s#€ddd#${pushColorID}#g" ~/zwb/temp/jingfenrexian_tamplate_temp.sh
sed -i "s#€eee#${colorPushTimefrom_time}#g" ~/zwb/temp/jingfenrexian_tamplate_temp.sh
sed -i "s#€fff#${colorPushTimeto_time}#g" ~/zwb/temp/jingfenrexian_tamplate_temp.sh
chmod 755 ~/zwb/temp/jingfenrexian_tamplate_temp.sh
sh ~/zwb/temp/jingfenrexian_tamplate_temp.sh
timetotal=`grep -A1 hits ~/zwb/temp/es_json_timetotal.txt |grep total |awk  '{print $3}' |awk -F "," '{print $1}'`
#大于默认限制值10000，退出执行
[ ${timetotal} -gt 10000 ] && {
#echo ${timetotal}
echo "企业id${parentEnterpriseID}时间段${colorPushTimefrom_time}到${colorPushTimeto_time}，${timetotal} 大于10000，无法使用查询导出数据。"
echo "企业id${parentEnterpriseID}时间段${colorPushTimefrom_time}到${colorPushTimeto_time}，${timetotal} 大于10000，无法使用查询导出数据。" >~/zwb/es_cdr.log
exit 0
}

#取页数，第一页=0   第二页=1 ...
ys=`echo "${timetotal}/${mygs}" | bc`


##提取话单数据
for i in $(seq 0 $ys)
do
echo $i
startflag=`echo "${i}*${mygs}" |bc`
echo ${startflag}
cp -rp ~/zwb/e_jingfenrexian_tamplate.sh ~/zwb/temp/jingfenrexian_tamplate_temp.sh

sed -i "s#€aaa#${startflag}#g" ~/zwb/temp/jingfenrexian_tamplate_temp.sh
sed -i "s#€bbb#${mygs}#g" ~/zwb/temp/jingfenrexian_tamplate_temp.sh
sed -i "s#€ccc#${parentEnterpriseID}#g" ~/zwb/temp/jingfenrexian_tamplate_temp.sh
sed -i "s#€ddd#${pushColorID}#g" ~/zwb/temp/jingfenrexian_tamplate_temp.sh
sed -i "s#€eee#${colorPushTimefrom_time}#g" ~/zwb/temp/jingfenrexian_tamplate_temp.sh
sed -i "s#€fff#${colorPushTimeto_time}#g" ~/zwb/temp/jingfenrexian_tamplate_temp.sh
sed -i "s#€ggg#${total}#g" ~/zwb/temp/jingfenrexian_tamplate_temp.sh
chmod 755 ~/zwb/temp/jingfenrexian_tamplate_temp.sh
sh ~/zwb/temp/jingfenrexian_tamplate_temp.sh
#cp -rp  ~/zwb/rexian_escdr_pushColorID_parentEnterpriseID_deliveryResult_colorPushTime_501750_tamplate.sh  ~/zwb/temp/rexian_escdr_pushColorID_parentEnterpriseID_deliveryResult_colorPushTime_501750_tamplate_temp.sh


done

}







###########第一次执行###########
###时间转换
echo "第一次执行开始"
seconds_start=`date -d "${colorPushTimefrom_temp}" +%s`       #得到时间戳 1578873600
colorPushTimefrom_one=`date -d @$seconds_start "+%Y%m%d%H%M%S"`000  #转化为20200113080060000
#echo  ${colorPushTimefrom}

seconds=`date -d "${colorPushTimefrom_temp}" +%s`       #得到时间戳 1578873600
seconds_end=`expr $seconds + ${sc}`                   #加上秒数30
colorPushTimeto=`date -d @$seconds_end "+%Y%m%d%H%M%S"`999  #转化为20200113080030999
#echo  ${colorPushTimeto}

seconds_temp=`date -d "${colorPushTimeto_temp}" +%s`       #得到时间戳 1578873600
colorPushTimeto_tp=`date -d @$seconds_temp "+%Y%m%d%H%M%S"`000  #转化为20200113080060000
#echo  ${colorPushTimeto_tp}

seconds_temp=`date -d "${colorPushTimeto_temp}" +%s`       #得到时间戳 1578873600
colorPushTimeto_tp_f=`date -d @$seconds_temp "+%Y%m%d%H%M%S"`999  #转化为20200113080060000
echo "执行时间段 ：${colorPushTimefrom_one} ${colorPushTimeto}"
exec_cdr ${parentEnterpriseID} ${pushColorID} ${colorPushTimefrom_one} ${colorPushTimeto_tp_f} ${mygs} ${colorPushTimefrom_one} ${colorPushTimeto}
echo "第一次执行完成"



##########中间执行处理#############
for  ((i=${seconds_end};i<${seconds_temp};))
do

seconds_start=${i}      #得到时间戳 1578873600
echo "seconds_start $seconds_start"
colorPushTimefrom=`date -d @$seconds_start "+%Y%m%d%H%M%S"`999  #转化为20200113080060000


i=`expr ${seconds_start} + ${sc}`      #加上秒数30
echo "i值：$i"
colorPushTimeto=`date -d @$i "+%Y%m%d%H%M%S"`999  #转化为20200113080030999
[ $i -lt ${seconds_temp} ] && {
echo "中间部分循环执行程序，时间段：${colorPushTimefrom} ${colorPushTimeto}"
exec_cdr ${parentEnterpriseID} ${pushColorID} ${colorPushTimefrom_one} ${colorPushTimeto_tp_f} ${mygs} ${colorPushTimefrom} ${colorPushTimeto}
i=`expr ${seconds_start} + ${sc}`
daoer_start=$i
echo "daoer_start $daoer_start"
}
done


#####最后一次执行处理########
colorPushTimefrom=`date -d @$daoer_start "+%Y%m%d%H%M%S"`999
seconds_temp=`date -d "${colorPushTimeto_temp}" +%s`       #得到时间戳 1578873600
colorPushTimeto_tp=`date -d @$seconds_temp "+%Y%m%d%H%M%S"`999  #转化为20200113080060000
echo "最后一次执行处理 ${colorPushTimefrom} ${colorPushTimeto_tp}"
exec_cdr ${parentEnterpriseID} ${pushColorID} ${colorPushTimefrom_one} ${colorPushTimeto_tp_f} ${mygs} ${colorPushTimefrom} ${colorPushTimeto_tp}
