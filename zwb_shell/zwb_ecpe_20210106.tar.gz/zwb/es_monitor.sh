#!/bin/bash
now_time=`date -u  +%Y-%m-%dT%H:%M:%S`
#now_time=`date +%Y%m%d%H%M%S`
before_time=`date -d "5 minute ago" -u +%Y-%m-%dT%H:%M:%S`
#before_time=`date -d "5 minute ago" +%Y%m%d%H%M%S`

echo "-----${before_time}start-----" >> ~/zwb/temp/note_all.txt
for i in `cat ~/zwb/enterprise_code.txt |grep -v "#"`
do 
ename=`grep "${i}|" ~/zwb/enterprise_name.txt  | awk -F "|" '{print $2}'`
sed -i "s/€a/${i}/g" ~/zwb/es.sh
sed -i "s/€c/${now_time}/g" ~/zwb/es.sh
sed -i "s/€b/${before_time}/g" ~/zwb/es.sh
sed -i "s/€h/${ename}/g" ~/zwb/es.sh
sh ~/zwb/es.sh
cat  ~/zwb/es_tamplate.sh >  ~/zwb/es.sh
done
echo "-----${now_time}end-----" >> ~/zwb/temp/note_all.txt

##ecpe日志告警部分##
sh ~/zwb/log_monitor.sh

##微位低于90%告警
for i in `cat ~/zwb/enterprise_code2.txt |grep -v "#"`
do
ename=`grep "${i}|" ~/zwb/enterprise_name2.txt  | awk -F "|" '{print $2}'`
sed -i "s/€a/${i}/g" ~/zwb/es2.sh
sed -i "s/€c/${now_time}/g" ~/zwb/es2.sh
sed -i "s/€b/${before_time}/g" ~/zwb/es2.sh
sed -i "s/€h/${ename}/g" ~/zwb/es2.sh
sh ~/zwb/es2.sh
cat  ~/zwb/es_tamplate2.sh >  ~/zwb/es2.sh
done

echo "-----${now_time}end-----" >> ~/zwb/temp/note_all.txt
 
