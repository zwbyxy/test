#!/bin/bash

##分割话单
#split_cdr(){
#num=$1
#mkdir -p ./cdr
#split -l ${num} cdr.txt ./cdr/cdr_
#}

#话单导入es函数
import_es(){
	for cdr in `find ./cdr/$1 |grep "_"`
	do
		name=$1
		mkdir -p ./shelltemp
		cp -rp ./json_tamplate.txt ./shelltemp/json_tamplate_temp_$name.sh
		for i in `echo $cdr|xargs cat`
		do
			echo $i >> ./cdr.log
			calledPhone=`echo "$i" |awk -F "|" '{print $1}'`
			pushColorBoxID=`echo "$i" |awk -F "|" '{print $2}'`
			type=`echo "$i" |awk -F "|" '{print $3}'`
			callTimes=`echo "$i" |awk -F "|" '{print $4}'`
			noUssdSendResult=`echo "$i" |awk -F "|" '{print $5}'`
			path=`echo "$i" |awk -F "|" '{print $6}'`
			colorSendType=`echo "$i" |awk -F "|" '{print $7}'`
			callingPhone=`echo "$i" |awk -F "|" '{print $8}'`
			userResponseContent=`echo "$i" |awk -F "|" '{print $9}'`
			version=`echo "$i" |awk -F "|" '{print $10}'`
			host=`echo "$i" |awk -F "|" '{print $1}'`
			ussdSendResult=`echo "$i" |awk -F "|" '{print $11}'`
			enterpriseID=`echo "$i" |awk -F "|" '{print $12}'`
			contRuleID=`echo "$i" |awk -F "|" '{print $13}'`
			owner=`echo "$i" |awk -F "|" '{print $14}'`
			callingIdentity=`echo "$i" |awk -F "|" '{print $15}'`
			colorSendDelayTime=`echo "$i" |awk -F "|" '{print $16}'`
			statID=`echo "$i" |awk -F "|" '{print $17}'`
			forwardPhone=`echo "$i" |awk -F "|" '{print $18}'`
			callingTime=`echo "$i" |awk -F "|" '{print $19}'`
			noSendColorReason=`echo "$i" |awk -F "|" '{print $20}'`
			pushColorContent=`echo "$i" |awk -F "|" '{print $21}'`
			pushColorID=`echo "$i" |awk -F "|" '{print $22}'`
			timestamp=`echo "$i" |awk -F "|" '{print $23}'`
			serviceID=`echo "$i" |awk -F "|" '{print $24}'`
			colorPushTime=`echo "$i" |awk -F "|" '{print $25}'`
			sed -i "s#€a#$calledPhone#" ./shelltemp/json_tamplate_temp_$name.sh
			sed -i "s#€b#$pushColorBoxID#" ./shelltemp/json_tamplate_temp_$name.sh
			sed -i "s#€c#$type#" ./shelltemp/json_tamplate_temp_$name.sh
			sed -i "s#€d#$callTimes#" ./shelltemp/json_tamplate_temp_$name.sh
			sed -i "s#€e#$noUssdSendResult#" ./shelltemp/json_tamplate_temp_$name.sh
			sed -i "s#€f#$path#" ./shelltemp/json_tamplate_temp_$name.sh
			sed -i "s#€g#$colorSendType#" ./shelltemp/json_tamplate_temp_$name.sh
			sed -i "s#€h#$callingPhone#" ./shelltemp/json_tamplate_temp_$name.sh
			sed -i "s#€i#$userResponseContent#" ./shelltemp/json_tamplate_temp_$name.sh
			sed -i "s#€j#$version#" ./shelltemp/json_tamplate_temp_$name.sh
			sed -i "s#€k#$host#" ./shelltemp/json_tamplate_temp_$name.sh
			sed -i "s#€l#$ussdSendResult#" ./shelltemp/json_tamplate_temp_$name.sh
			sed -i "s#€m#$enterpriseID#" ./shelltemp/json_tamplate_temp_$name.sh
			sed -i "s#€n#$contRuleID#" ./shelltemp/json_tamplate_temp_$name.sh
			sed -i "s#€o#$owner#" ./shelltemp/json_tamplate_temp_$name.sh
			sed -i "s#€p#$callingIdentity#" ./shelltemp/json_tamplate_temp_$name.sh
			sed -i "s#€q#$colorSendDelayTime#" ./shelltemp/json_tamplate_temp_$name.sh
			sed -i "s#€r#$statID#" ./shelltemp/json_tamplate_temp_$name.sh
			sed -i "s#€s#$forwardPhone#" ./shelltemp/json_tamplate_temp_$name.sh
			sed -i "s#€t#$callingTime#" ./shelltemp/json_tamplate_temp_$name.sh
			sed -i "s#€u#$noSendColorReason#" ./shelltemp/json_tamplate_temp_$name.sh
			sed -i "s#€v#$pushColorContent#" ./shelltemp/json_tamplate_temp_$name.sh
			sed -i "s#€w#$pushColorID#" ./shelltemp/json_tamplate_temp_$name.sh
			sed -i "s#€x#$timestamp#" ./shelltemp/json_tamplate_temp_$name.sh
			sed -i "s#€y#$serviceID#" ./shelltemp/json_tamplate_temp_$name.sh
			sed -i "s#€z#$colorPushTime#" ./shelltemp/json_tamplate_temp_$name.sh
			chmod 755 ./shelltemp/json_tamplate_temp_$name.sh
			#sh ./shelltemp/json_tamplate_temp_${name}.sh
		done

	done
}
main(){
	read -p "enter split line number (eg:10000):" number
	rm -rf ./cdr
	rm -rf ./temp
	rm -rf ./shelltemp
	mkdir -p ./temp
	mkdir -p ./cdr
	split -l $number cdr.txt ./temp/cdr_
	##话单数量
	counts=`cat ./cdr.txt|wc -l`
	echo $counts
	##文件数取整数
	filecount=$(( $counts / $number ))
	##取余数
	yushu=$(( $counts % $number ))
	##并行参数
	b=5
	##转移文件数
	wjs=$(( $filecount / $b ))
	##余数等于0，循环次数去file
	if [ $yushu == 0 ]
	then
		for c in $( seq 1 $b )
		do
			filepwd=`ls ./temp/cdr_* |head -n $wjs`
			mkdir -p ./cdr/$c
			for fpwd in  `echo $filepwd`
			do
				mv $fpwd ./cdr/$c/

			done
			echo $c
			import_es $c &

		done

		##余数不等于0，循环次数+1
	else
		filecounts=$(( $b+1 ))
		for c in $( seq 1 $filecounts )
		do
			filepwd=`ls ./temp/cdr_* |head -n $wjs`
			mkdir -p ./cdr/$c
			for fpwd in  `echo $filepwd`
			do
				mv $fpwd ./cdr/$c/

			done
			echo $c
			import_es $c &

		done


	fi
}
main $
