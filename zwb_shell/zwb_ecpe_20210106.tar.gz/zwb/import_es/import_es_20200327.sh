#!/bin/bash
#话单导入es函数
import_es(){
for i in `cat ./cdr.txt`
do
calledPhone=`echo "$i" |awk -F "|" '{print $1}'`
pushColorBoxID=`echo "$i" |awk -F "|" '{print $2}'`
type=`echo "$i" |awk -F "|" '{print $3}'`
callTimes=`echo "$i" |awk -F "|" '{print $4}'`
noUssdSendResult=`echo "$i" |awk -F "|" '{print $5}'`
path=`echo "$i" |awk -F "|" '{print $6}'`
colorSendType=`echo "$i" |awk -F "|" '{print $7}'`
callingPhone=`echo "$i" |awk -F "|" '{print $8}'`
userResponseContent=`echo "$i" |awk -F "|" '{print $9}'`
version=`echo "$i" |awk -F "|" '{print $10}'`
host=`echo "$i" |awk -F "|" '{print $1}'`
ussdSendResult=`echo "$i" |awk -F "|" '{print $11}'`
enterpriseID=`echo "$i" |awk -F "|" '{print $12}'`
contRuleID=`echo "$i" |awk -F "|" '{print $13}'`
owner=`echo "$i" |awk -F "|" '{print $14}'`
callingIdentity=`echo "$i" |awk -F "|" '{print $15}'`
colorSendDelayTime=`echo "$i" |awk -F "|" '{print $16}'`
statID=`echo "$i" |awk -F "|" '{print $17}'`
forwardPhone=`echo "$i" |awk -F "|" '{print $18}'`
callingTime=`echo "$i" |awk -F "|" '{print $19}'`
noSendColorReason=`echo "$i" |awk -F "|" '{print $20}'`
pushColorContent=`echo "$i" |awk -F "|" '{print $21}'`
pushColorID=`echo "$i" |awk -F "|" '{print $22}'`
timestamp=`echo "$i" |awk -F "|" '{print $23}'`
serviceID=`echo "$i" |awk -F "|" '{print $24}'`
colorPushTime=`echo "$i" |awk -F "|" '{print $25}'`

cp -rp ./json_tamplate.txt ./json_tamplate_temp.sh 
sed -i "s#€a#${calledPhone}#" ./json_tamplate_temp.sh
sed -i "s#€b#${pushColorBoxID}#" ./json_tamplate_temp.sh
sed -i "s#€c#${type}#" ./json_tamplate_temp.sh
sed -i "s#€d#${callTimes}#" ./json_tamplate_temp.sh
sed -i "s#€e#${noUssdSendResult}#" ./json_tamplate_temp.sh
sed -i "s#€f#${path}#" ./json_tamplate_temp.sh
sed -i "s#€g#${colorSendType}#" ./json_tamplate_temp.sh
sed -i "s#€h#${callingPhone}#" ./json_tamplate_temp.sh
sed -i "s#€i#${userResponseContent}#" ./json_tamplate_temp.sh
sed -i "s#€j#${version}#" ./json_tamplate_temp.sh
sed -i "s#€k#${host}#" ./json_tamplate_temp.sh
sed -i "s#€l#${ussdSendResult}#" ./json_tamplate_temp.sh
sed -i "s#€m#${enterpriseID}#" ./json_tamplate_temp.sh
sed -i "s#€n#${contRuleID}#" ./json_tamplate_temp.sh
sed -i "s#€o#${owner}#" ./json_tamplate_temp.sh
sed -i "s#€p#${callingIdentity}#" ./json_tamplate_temp.sh
sed -i "s#€q#${colorSendDelayTime}#" ./json_tamplate_temp.sh
sed -i "s#€r#${statID}#" ./json_tamplate_temp.sh
sed -i "s#€s#${forwardPhone}#" ./json_tamplate_temp.sh
sed -i "s#€t#${callingTime}#" ./json_tamplate_temp.sh
sed -i "s#€u#${noSendColorReason}#" ./json_tamplate_temp.sh
sed -i "s#€v#${pushColorContent}#" ./json_tamplate_temp.sh
sed -i "s#€w#${pushColorID}#" ./json_tamplate_temp.sh
sed -i "s#€x#${timestamp}#" ./json_tamplate_temp.sh
sed -i "s#€y#${serviceID}#" ./json_tamplate_temp.sh
sed -i "s#€z#${colorPushTime}#" ./json_tamplate_temp.sh
chmod 755 ./json_tamplate_temp.sh
#sh ./json_tamplate_temp.sh
done
}
main(){
import_es
}
main $*
