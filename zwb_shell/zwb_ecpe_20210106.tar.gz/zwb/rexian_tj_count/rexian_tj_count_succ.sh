#!/bin/bash
pidlist=(
572841
)


datelist=(
20200824€20200831
20200901€20200930
20201001€20201011
)

exec_es(){
cp -rp ~/zwb/rexian_tj_count/rexian_tj_succ_count_tamplate.sh ~/zwb/rexian_tj_count/rexian_tj_succ_count_tamplate_exec.sh

sed -i "s/€aaa/${1}/g" ~/zwb/rexian_tj_count/rexian_tj_succ_count_tamplate_exec.sh

chmod 755 ~/zwb/rexian_tj_count/rexian_tj_succ_count_tamplate_exec.sh
sh ~/zwb/rexian_tj_count/rexian_tj_succ_count_tamplate_exec.sh

}



main(){

for array in ${pidlist[*]}
do
pid=${array}
    exec_es ${pid}
done
}

main $*
