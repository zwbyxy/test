#!/bin/bash
curl -XGET '10.124.72.189:9200/delivery_detail/delivery_record/_search?pretty'  -H 'Content-Type: application/json' -d'
{
"from" : 0 ,
"size":  5,
  "query": {
    "bool": {
      "must": [
        {
          "bool": {
            "should": [
              {
                "term": {
                  "pushColorID": {
                    "value": "506416",
                    "boost": 1
                  }
                }
              }
            ]


          }
        },
{
          "bool": {
            "should": [
              {
                "term": {
                  "deliveryResult": {
                    "value": "0",
                    "boost": 1
                  }
                }
              },
                                        {
                "term": {
                  "deliveryResult": {
                    "value": "1",
                    "boost": 1
                  }
                }
              },
                                        {
                "term": {
                  "deliveryResult": {
                    "value": "2",
                    "boost": 1
                  }
                }
              },
                                        {
                "term": {
                  "deliveryResult": {
                    "value": "8",
                    "boost": 1
                  }
                }
              },
                          {
                "term": {
                  "deliveryResult": {
                    "value": "999",
                    "boost": 1
                  }
                }
              }
            ]


          }
        },


        {
          "range": {
            "@timestamp": {
              "from": "2020-06-30T16:00:00.000Z",
              "to": "2020-07-31T16:00:00.000Z",
              "include_lower": true,
              "include_upper": true,
              "boost": 1
            }
          }
        }
      ]
    }
  }
}' > /root/zwb/rexian_tj_count/temp/506416_temp_json.txt

reqcount=`grep -A1 hits ~/zwb/rexian_tj_count/temp/506416_temp_json.txt |grep total |awk '{print $3}' |awk -F "," '{print $1}'`
#话单输出：日期|子企业id|规则id|请求条数
echo -n "2020-07-31" >> ~/zwb/rexian_tj_count/temp/jingfen_mingpin_count.txt
echo -n "," >>  ~/zwb/rexian_tj_count/temp/jingfen_mingpin_count.txt
echo -n "506416" >> ~/zwb/rexian_tj_count/temp/jingfen_mingpin_count.txt
echo -n "," >>  ~/zwb/rexian_tj_count/temp/jingfen_mingpin_count.txt
echo -n ${reqcount} >> ~/zwb/rexian_tj_count/temp/jingfen_mingpin_count.txt
echo "">>  ~/zwb/rexian_tj_count/temp/jingfen_mingpin_count.txt
