curl -X POST \
  http://€p:19031/sms/send \
  -H 'Content-Type: application/json;charset=utf-8' \
  -H 'Connection: Keep-Alive' \
  -d '{
	"format":"NORMAL",
	"message":"企管成功率告警，€f",
	"receiver":"€d",
	"senderName":"10658086",
	"source":"ENTERPRISE"
}'
