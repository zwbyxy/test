#!/bin/bash
curl -XGET '10.124.72.189:9200/cy-detail/detail/_search?pretty'  -H 'Content-Type: application/json' -d'
{
 "size":  1,
  "query": {
    "bool": {
      "must": [
        {
          "bool": {
            "should": [
              {
                "term": {
                  "enterpriseID": {
                    "value": "€aaa",
                    "boost": 1
                  }
                }
              }
            ] 


          }
        }, 

        {
          "bool": {
            "should": [
              {
                "term": {
                  "noUssdSendResult": {
                    "value": "0",
                    "boost": 1
                  }
                }
              },
                           {
                "term": {
                  "ussdSendResult": {
                    "value": "0", 
                    "boost": 1
                  }
                }
              }
            ] 


          }
        },

        {
          "range": {
            "@timestamp": {
              "from": "€bbbT16:00:00.000Z",
              "to": "€cccT16:00:00.000Z",
              "include_lower": true,
              "include_upper": true,
              "boost": 1
            }
          }
        }
      ]
    }
  }
}
'> /root/zwb/mingpian_tj_count_by_date/temp/€aaa_temp_json.txt

reqcount=`grep -A1 hits ~/zwb/mingpian_tj_count_by_date/temp/€aaa_temp_json.txt |grep total |awk '{print $3}' |awk -F "," '{print $1}'`
#话单输出：日期|子企业id|规则id|请求条数
echo -n "€ccc" >> ~/zwb/mingpian_tj_count_by_date/temp/jingfen_mingpin_count.txt
echo -n "," >>  ~/zwb/mingpian_tj_count_by_date/temp/jingfen_mingpin_count.txt
echo -n "€aaa" >> ~/zwb/mingpian_tj_count_by_date/temp/jingfen_mingpin_count.txt
echo -n "," >>  ~/zwb/mingpian_tj_count_by_date/temp/jingfen_mingpin_count.txt
echo -n ${reqcount} >> ~/zwb/mingpian_tj_count_by_date/temp/jingfen_mingpin_count.txt
echo "">>  ~/zwb/mingpian_tj_count_by_date/temp/jingfen_mingpin_count.txt
