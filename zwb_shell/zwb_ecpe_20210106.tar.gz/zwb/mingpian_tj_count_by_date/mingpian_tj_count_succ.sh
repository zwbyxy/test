#!/bin/bash
pidlist=(
50000102
)


datelist=(
2020-10-28€2020-10-29
2020-10-29€2020-10-30
2020-07-31€2020-08-01
2020-08-01€2020-08-02
2020-08-02€2020-08-03
2020-08-03€2020-08-04
2020-08-04€2020-08-05
2020-08-05€2020-08-06
2020-08-06€2020-08-07
2020-08-07€2020-08-08
2020-08-08€2020-08-09
2020-08-09€2020-08-10
2020-08-10€2020-08-11
2020-08-11€2020-08-12
2020-08-12€2020-08-13
2020-08-13€2020-08-14
2020-08-14€2020-08-15
2020-08-15€2020-08-16
2020-08-16€2020-08-17
2020-08-17€2020-08-18
2020-08-18€2020-08-19
2020-08-19€2020-08-20
2020-08-20€2020-08-21
2020-08-21€2020-08-22
2020-08-22€2020-08-23
2020-08-23€2020-08-24
2020-08-24€2020-08-25
2020-08-25€2020-08-26
2020-08-26€2020-08-27
2020-08-27€2020-08-28
2020-08-28€2020-08-29
2020-08-29€2020-08-30
2020-08-30€2020-08-31
2020-08-31€2020-09-01
2020-10-02€2020-10-03
)

exec_es(){
cp -rp ~/zwb/mingpian_tj_count_by_date/rexian_tj_succ_count_tamplate.sh ~/zwb/mingpian_tj_count_by_date/rexian_tj_succ_count_tamplate_exec.sh

sed -i "s/€aaa/${1}/g" ~/zwb/mingpian_tj_count_by_date/rexian_tj_succ_count_tamplate_exec.sh
sed -i "s/€bbb/${2}/g" ~/zwb/mingpian_tj_count_by_date/rexian_tj_succ_count_tamplate_exec.sh
sed -i "s/€ccc/${3}/g" ~/zwb/mingpian_tj_count_by_date/rexian_tj_succ_count_tamplate_exec.sh
chmod 755 ~/zwb/mingpian_tj_count_by_date/rexian_tj_succ_count_tamplate_exec.sh
sh ~/zwb/mingpian_tj_count_by_date/rexian_tj_succ_count_tamplate_exec.sh

}



main(){

for array in ${pidlist[*]}
do
pid=${array}
	for arrayi in ${datelist[*]}
	do
	starttime=`echo ${arrayi} |awk -F "€" '{print $1}'`
	endtime=`echo ${arrayi} |awk -F "€" '{print $2}'`
	exec_es ${pid} ${starttime} ${endtime}
	done
done
}

main $*
