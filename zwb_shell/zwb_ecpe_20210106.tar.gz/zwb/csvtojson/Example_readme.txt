## level one
[root@localtest liuchao]# bash Excel2Json.sh LevelOne.csv
[
    {
        "id":1,
        "name":"北京"
    },
    {
        "id":2,
        "name":"陕西"
    },
    {
        "id":3,
        "name":"河北"
    },
]

# level two

[root@localtest liuchao]# bash Excel2Json.sh 2 LevelTwo.csv
[
    {
        "id": 1,
        "name": "北京",
        "List": [
            {
                 "id": 1,
                 "name": "东城区"
            },
            {
                 "id": 2,
                 "name": "西城区"
            },
            {
                 "id": 3,
                 "name": "崇文区"
            },
            {
                 "id": 4,
                 "name": "宣武区"
            },
....
