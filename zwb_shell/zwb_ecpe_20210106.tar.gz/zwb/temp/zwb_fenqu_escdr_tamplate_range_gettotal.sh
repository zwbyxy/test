#!/bin/bash

curl -XGET '10.124.72.189:9200/cy-detail/detail/_search'  -H 'Content-Type: application/json' -d'
{
	"query": {
		"bool": {
			"must": [{
				"range": {
					"colorPushTime": {
						"from": "20200320115000999",
						"to": "20200320115959999",
						"include_lower": true,
						"include_upper": true,
						"boost": 1.0
					}
				}
			},
			{
          "bool": {
            "should": [
              {
                "term": {
                  "noUssdSendResult": {
                    "value": "0",
                    "boost": 1
                  }
                }
              },
                           {
                "term": {
                  "ussdSendResult": {
                    "value": "0",
                    "boost": 1
                  }
                }
              }
            ]


          }
        },
			{
				"wildcard": {
					"contRuleID": {
						"wildcard": "*_30000435_*",
						"boost": 1.0
					}
				}
			}],
			"disable_coord": false,
			"adjust_pure_negative": true,
			"boost": 1.0
		}
	}
}
' > ~/zwb/temp/es_json_range_gettotal.txt

