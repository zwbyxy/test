#!/bin/bash

curl -XGET '10.124.72.189:9200/cy-detail/detail/_search'  -H 'Content-Type: application/json' -d'
{  
 "size":  10,
  "query": {
    "bool": {
      "must": [
        {
          "bool": {
            "should": [
              {
                "term": {
                  "contRuleID": {
                    "value": "01109_300003_1_1_500249", 
                    "boost": 1
                  }
                }
              },
               {
                "term": {
                  "contRuleID": {
                    "value": "01108_300003_1_1_500134", 
                    "boost": 1
                  }
                }
              }
            ] 


          }
        },  

        {
          "bool": {
            "should": [
              {
                "term": {
                  "noUssdSendResult": {
                    "value": "0",  
                    "boost": 1
                  }
                }
              },
                           {
                "term": {
                  "ussdSendResult": {
                    "value": "0", 
                    "boost": 1
                  }
                }
              }
            ] 


          }
        },

        {
          "range": {
            "colorPushTime": {
              "from": "20190401000000",
              "to": "20190431235959",
              "include_lower": true,
              "include_upper": true,
              "boost": 1
            }
          }
        }
      ]
    }
  }
}
' > ~/zwb/temp/es_json.txt

date=`date +%Y%m%d`


namelist=(
calledPhone€pushColorBoxID€type€callTimes€noUssdSendResult€path€colorSendType€callingPhone€userResponseContent€host€ussdSendResult€contRuleID€owner€callingIdentity€colorSendDelayTime€statID€forwardPhone€callingTime€noSendColorReason€pushColorContent€pushColorID€serviceID€colorPushTime€timestamp
)

for array in ${namelist[*]}
do
calledPhone=`echo ${array} |awk -F "€" '{print $1}'`
pushColorBoxID=`echo ${array} |awk -F "€" '{print $2}'`
callTimes=`echo ${array} |awk -F "€" '{print $4}'`
noUssdSendResult=`echo ${array} |awk -F "€" '{print $5}'`
path=`echo ${array} |awk -F "€" '{print $6}'`
colorSendType=`echo ${array} |awk -F "€" '{print $7}'`
callingPhone=`echo ${array} |awk -F "€" '{print $8}'`
userResponseContent=`echo ${array} |awk -F "€" '{print $9}'`
host=`echo ${array} |awk -F "€" '{print $10}'`
ussdSendResult=`echo ${array} |awk -F "€" '{print $11}'`
contRuleID=`echo ${array} |awk -F "€" '{print $12}'`
owner=`echo ${array} |awk -F "€" '{print $13}'`
callingIdentity=`echo ${array} |awk -F "€" '{print $14}'`
colorSendDelayTime=`echo ${array} |awk -F "€" '{print $15}'`
statID=`echo ${array} |awk -F "€" '{print $16}'`
forwardPhone=`echo ${array} |awk -F "€" '{print $17}'`
callingTime=`echo ${array} |awk -F "€" '{print $18}'`
noSendColorReason=`echo ${array} |awk -F "€" '{print $19}'`
pushColorContent=`echo ${array} |awk -F "€" '{print $20}'`
pushColorID=`echo ${array} |awk -F "€" '{print $21}'`
serviceID=`echo ${array} |awk -F "€" '{print $22}'`
colorPushTime=`echo ${array} |awk -F "€" '{print $23}'`
timestamp=`echo ${array} |awk -F "€" '{print $24}'`





##grep -Po "pushColorID[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt
##grep -Po 'pushColorID[" :]+\K[^"]+'  ~/zwb/temp/es_json.txt

grep -Po "${calledPhone}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/calledPhone_field.txt
sed -i "s#|#l#g"  ~/zwb/temp/calledPhone_field.txt

grep -Po "${pushColorBoxID}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/pushColorBoxID_field.txt
sed -i "s#|#l#g"  ~/zwb/temp/pushColorBoxID_field.txt
 
grep -Po "${types}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/types_field.txt
sed -i "s#|#l#g"  ~/zwb/temp/types_field.txt
grep -Po "${callTimes}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/callTimes_field.txt
sed -i "s#|#l#g"  ~/zwb/temp/callTimes_field.txt
grep -Po "${noUssdSendResult}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/noUssdSendResult_field.txt
sed -i "s#|#l#g"  ~/zwb/temp/noUssdSendResult_field.txt
grep -Po "${path}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/path_field.txt
sed -i "s#|#l#g"  ~/zwb/temp/path_field.txt
grep -Po "${colorSendType}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/colorSendType_field.txt
sed -i "s#|#l#g"  ~/zwb/temp/colorSendType_field.txt
grep -Po "${callingPhone}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/callingPhone_field.txt
sed -i "s#|#l#g"  ~/zwb/temp/callingPhone_field.txt
grep -Po "${userResponseContent}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/userResponseContent_field.txt
sed -i "s#|#l#g"  ~/zwb/temp/userResponseContent_field.txt
grep -Po "${host}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/host_field.txt
sed -i "s#|#l#g"  ~/zwb/temp/host_field.txt
grep -Po "${ussdSendResult}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/ussdSendResult_field.txt
sed -i "s#|#l#g"  ~/zwb/temp/ussdSendResult_field.txt
grep -Po "${contRuleID}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/contRuleID_field.txt
sed -i "s#|#l#g"  ~/zwb/temp/contRuleID_field.txt
grep -Po "${owner}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/owner_field.txt
sed -i "s#|#l#g"  ~/zwb/temp/owner_field.txt
grep -Po "${callingIdentity}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/callingIdentity_field.txt
sed -i "s#|#l#g"  ~/zwb/temp/callingIdentity_field.txt
grep -Po "${colorSendDelayTime}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/colorSendDelayTime_field.txt
sed -i "s#|#l#g"  ~/zwb/temp/colorSendDelayTime_field.txt
grep -Po "${statID}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/statID_field.txt
sed -i "s#|#l#g"  ~/zwb/temp/statID_field.txt
grep -Po "${forwardPhone}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/forwardPhone_field.txt
sed -i "s#|#l#g"  ~/zwb/temp/forwardPhone_field.txt
grep -Po "${callingTime}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/callingTime_field.txt
sed -i "s#|#l#g"  ~/zwb/temp/callingTime_field.txt
grep -Po "${noSendColorReason}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/noSendColorReason_field.txt
sed -i "s#|#l#g"  ~/zwb/temp/noSendColorReason_field.txt
grep -Po "${pushColorContent}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/pushColorContent_field.txt
sed -i "s#|#l#g"  ~/zwb/temp/pushColorContent_field.txt
grep -Po "${pushColorID}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/pushColorID_field.txt
sed -i "s#|#l#g"  ~/zwb/temp/pushColorID_field.txt
sed -i "s#|#l#g"  ~/zwb/temp/timestamp_field.txt
grep -Po "${serviceID}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/serviceID_field.txt
sed -i "s#|#l#g"  ~/zwb/temp/serviceID_field.txt
grep -Po "${colorPushTime}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/colorPushTime_field.txt
sed -i "s#|#l#g"  ~/zwb/temp/colorPushTime_field.txt
grep -Po "${timestamp}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/timestamp_field.txt
sed -i "s#|#l#g"  ~/zwb/temp/timestamp_field.txt

mkdir -p ~/zwb/es_cdr/
paste -d"|" ~/zwb/temp/calledPhone_field.txt ~/zwb/temp/pushColorBoxID_field.txt ~/zwb/temp/callTimes_field.txt ~/zwb/temp/noUssdSendResult_field.txt ~/zwb/temp/path_field.txt ~/zwb/temp/colorSendType_field.txt ~/zwb/temp/callingPhone_field.txt ~/zwb/temp/userResponseContent_field.txt ~/zwb/temp/host_field.txt ~/zwb/temp/ussdSendResult_field.txt ~/zwb/temp/contRuleID_field.txt ~/zwb/temp/owner_field.txt ~/zwb/temp/callingIdentity_field.txt ~/zwb/temp/colorSendDelayTime_field.txt ~/zwb/temp/statID_field.txt ~/zwb/temp/forwardPhone_field.txt ~/zwb/temp/callingTime_field.txt ~/zwb/temp/noSendColorReason_field.txt ~/zwb/temp/pushColorContent_field.txt ~/zwb/temp/pushColorID_field.txt ~/zwb/temp/serviceID_field.txt ~/zwb/temp/timestamp_field.txt  >>~/zwb/es_cdr/es_cdr_${date}.txt


done


