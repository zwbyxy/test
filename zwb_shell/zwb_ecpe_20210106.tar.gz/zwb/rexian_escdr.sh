#!/bin/bash
curl -XGET '10.124.72.189:9200/delivery_detail/delivery_record/_search?pretty'  -H 'Content-Type: application/json' -d'
{
 "size":  100,
  "query": {
    "bool": {
      "must": [
        {
          "bool": {
            "should": [
              {
                "term": {
                  "parentEnterpriseID": {
                    "value": "255003", 
                    "boost": 1
                  }
                }
              }
            ] 


          }
        },   

        {
          "bool": {
            "should": [
              {
                "term": {
                  "pushColorID": {
                    "value": "501290",   
                    "boost": 1
                  }
                }
              }
            ] 


          }
        },

        {
          "range": {
            "colorPushTime": {
              "from": "20200108000000",
              "to": "20200108235959",
              "include_lower": true,
              "include_upper": true,
              "boost": 1
            }
          }
        }
      ]
    }
  }
}
' > ~/zwb/temp/es_json.txt

###将 \" 特殊字符替换为空，如果不替换grep -Po 解析json格式有问题
sed -i "s#[\\\]\"##g" ~/zwb/temp/es_json.txt

date=`date +%Y%m%d`


namelist=(
serviceID€callingPhone€calledPhone€contRuleID€statID€callingIdentity€callingTime€noSendColorReason€colorPushTime€colorSendDelayTime€colorSendType€noUssdSendResult€ussdSendResult€pushColorContent€pushColorID€pushColorBoxID€callTimes€forwardPhone€chargeNumber€enterpriseID€enterpriseCode€enterpriseName€enterpriseType€serviceType€subServiceType€provinceIdentify€cityIdentify€sessionIdentify€contentIdentify€target€deliveryReqTime€deliveryRspTime€deliveryResultReqTime€deliveryResultRspTime€deliveryRspCode€deliveryResult€src€owner€chargeCount€callEvent€callProcess€parentEnterpriseID€parentEnterpriseCode€parentEnterpriseName€msgType€orderId€subscribeId€contentArgs€deliveryTimestamp€packageCode€productCode€timestamp€sensitiveWords
)

for array in ${namelist[*]}
do
serviceID=`echo ${array} |awk -F "€" '{print $1}'`
calledPhone=`echo ${array} |awk -F "€" '{print $2}'`
callingPhone=`echo ${array} |awk -F "€" '{print $3}'`
contRuleID=`echo ${array} |awk -F "€" '{print $4}'`
statID=`echo ${array} |awk -F "€" '{print $5}'`
callingIdentity=`echo ${array} |awk -F "€" '{print $6}'`
callingTime=`echo ${array} |awk -F "€" '{print $7}'`
noSendColorReason=`echo ${array} |awk -F "€" '{print $8}'`
colorPushTime=`echo ${array} |awk -F "€" '{print $9}'`
colorSendDelayTime=`echo ${array} |awk -F "€" '{print $10}'`
colorSendType=`echo ${array} |awk -F "€" '{print $11}'`
noUssdSendResult=`echo ${array} |awk -F "€" '{print $12}'`
ussdSendResult=`echo ${array} |awk -F "€" '{print $13}'`
pushColorContent=`echo ${array} |awk -F "€" '{print $14}'`
pushColorID=`echo ${array} |awk -F "€" '{print $15}'`
pushColorBoxID=`echo ${array} |awk -F "€" '{print $16}'`
callTimes=`echo ${array} |awk -F "€" '{print $17}'`
forwardPhone=`echo ${array} |awk -F "€" '{print $18}'`
chargeNumber=`echo ${array} |awk -F "€" '{print $19}'`
enterpriseID=`echo ${array} |awk -F "€" '{print $20}'`
enterpriseCode=`echo ${array} |awk -F "€" '{print $21}'`
enterpriseName=`echo ${array} |awk -F "€" '{print $22}'`
enterpriseType=`echo ${array} |awk -F "€" '{print $23}'`
serviceType=`echo ${array} |awk -F "€" '{print $24}'`
subServiceType=`echo ${array} |awk -F "€" '{print $25}'`
provinceIdentify=`echo ${array} |awk -F "€" '{print $26}'`
cityIdentify=`echo ${array} |awk -F "€" '{print $27}'`
sessionIdentify=`echo ${array} |awk -F "€" '{print $28}'`
contentIdentify=`echo ${array} |awk -F "€" '{print $29}'`
target=`echo ${array} |awk -F "€" '{print $30}'`
deliveryReqTime=`echo ${array} |awk -F "€" '{print $31}'`
deliveryRspTime=`echo ${array} |awk -F "€" '{print $32}'`
deliveryResultReqTime=`echo ${array} |awk -F "€" '{print $33}'`
deliveryResultRspTime=`echo ${array} |awk -F "€" '{print $34}'`
deliveryRspCode=`echo ${array} |awk -F "€" '{print $35}'`
deliveryResult=`echo ${array} |awk -F "€" '{print $36}'`
src=`echo ${array} |awk -F "€" '{print $37}'`
owner=`echo ${array} |awk -F "€" '{print $38}'`
chargeCount=`echo ${array} |awk -F "€" '{print $39}'`
callEvent=`echo ${array} |awk -F "€" '{print $40}'`
callProcess=`echo ${array} |awk -F "€" '{print $41}'`
parentEnterpriseID=`echo ${array} |awk -F "€" '{print $42}'`
parentEnterpriseCode=`echo ${array} |awk -F "€" '{print $43}'`
parentEnterpriseName=`echo ${array} |awk -F "€" '{print $44}'`
msgType=`echo ${array} |awk -F "€" '{print $45}'`
orderId=`echo ${array} |awk -F "€" '{print $46}'`
subscribeId=`echo ${array} |awk -F "€" '{print $47}'`
contentArgs=`echo ${array} |awk -F "€" '{print $48}'`
deliveryTimestamp=`echo ${array} |awk -F "€" '{print $49}'`
packageCode=`echo ${array} |awk -F "€" '{print $50}'`
productCode=`echo ${array} |awk -F "€" '{print $51}'`
timestamp=`echo ${array} |awk -F "€" '{print $52}'`
sensitiveWords=`echo ${array} |awk -F "€" '{print $53}'`


grep -Po "${serviceID}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/serviceID
sed -i "s#|#l#g"  ~/zwb/temp/serviceID

grep -Po "${callingPhone}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/callingPhone
sed -i "s#|#l#g"  ~/zwb/temp/callingPhone

grep -Po "${calledPhone}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/calledPhone
sed -i "s#|#l#g"  ~/zwb/temp/calledPhone

grep -Po "${contRuleID}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/contRuleID
sed -i "s#|#l#g"  ~/zwb/temp/contRuleID
grep -Po "${statID}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/statID
sed -i "s#|#l#g"  ~/zwb/temp/statID

grep -Po "${callingIdentity}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/callingIdentity
sed -i "s#|#l#g"  ~/zwb/temp/callingIdentity

grep -Po "${callingTime}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/callingTime
sed -i "s#|#l#g"  ~/zwb/temp/callingTime

grep -Po "${noSendColorReason}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/noSendColorReason
sed -i "s#|#l#g"  ~/zwb/temp/noSendColorReason
grep -Po "${colorPushTime}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/colorPushTime
sed -i "s#|#l#g"  ~/zwb/temp/colorPushTime

grep -Po "${colorSendDelayTime}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/colorSendDelayTime
sed -i "s#|#l#g"  ~/zwb/temp/colorSendDelayTime

grep -Po "${colorSendType}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/colorSendType
sed -i "s#|#l#g"  ~/zwb/temp/colorSendType

grep -Po "${noUssdSendResult}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/noUssdSendResult
sed -i "s#|#l#g"  ~/zwb/temp/noUssdSendResult
grep -Po "${ussdSendResult}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/ussdSendResult
sed -i "s#|#l#g"  ~/zwb/temp/ussdSendResult

grep -Po "${pushColorContent}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/pushColorContent
sed -i "s#|#l#g"  ~/zwb/temp/pushColorContent

grep -Po "${pushColorID}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/pushColorID
sed -i "s#|#l#g"  ~/zwb/temp/pushColorID

grep -Po "${pushColorBoxID}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/pushColorBoxID
sed -i "s#|#l#g"  ~/zwb/temp/pushColorBoxID
grep -Po "${callTimes}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/callTimes
sed -i "s#|#l#g"  ~/zwb/temp/callTimes

grep -Po "${forwardPhone}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/forwardPhone
sed -i "s#|#l#g"  ~/zwb/temp/forwardPhone

grep -Po "${chargeNumber}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/chargeNumber
sed -i "s#|#l#g"  ~/zwb/temp/chargeNumber

grep -Po "${enterpriseID}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/enterpriseID
sed -i "s#|#l#g"  ~/zwb/temp/enterpriseID
grep -Po "${enterpriseCode}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/enterpriseCode
sed -i "s#|#l#g"  ~/zwb/temp/enterpriseCode

grep -Po "${enterpriseName}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/enterpriseName
sed -i "s#|#l#g"  ~/zwb/temp/enterpriseName

grep -Po "${enterpriseType}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/enterpriseType
sed -i "s#|#l#g"  ~/zwb/temp/enterpriseType

grep -Po "${serviceType}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/serviceType
sed -i "s#|#l#g"  ~/zwb/temp/serviceType
grep -Po "${subServiceType}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/subServiceType
sed -i "s#|#l#g"  ~/zwb/temp/subServiceType

grep -Po "${provinceIdentify}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/provinceIdentify
sed -i "s#|#l#g"  ~/zwb/temp/provinceIdentify

grep -Po "${cityIdentify}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/cityIdentify
sed -i "s#|#l#g"  ~/zwb/temp/cityIdentify

grep -Po "${sessionIdentify}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/sessionIdentify
sed -i "s#|#l#g"  ~/zwb/temp/sessionIdentify
grep -Po "${contentIdentify}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/contentIdentify
sed -i "s#|#l#g"  ~/zwb/temp/contentIdentify

grep -Po "${target}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/target
sed -i "s#|#l#g"  ~/zwb/temp/target

grep -Po "${deliveryReqTime}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/deliveryReqTime
sed -i "s#|#l#g"  ~/zwb/temp/deliveryReqTime

grep -Po "${deliveryRspTime}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/deliveryRspTime
sed -i "s#|#l#g"  ~/zwb/temp/deliveryRspTime
grep -Po "${deliveryResultReqTime}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/deliveryResultReqTime
sed -i "s#|#l#g"  ~/zwb/temp/deliveryResultReqTime

grep -Po "${deliveryResultRspTime}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/deliveryResultRspTime
sed -i "s#|#l#g"  ~/zwb/temp/deliveryResultRspTime

grep -Po "${deliveryRspCode}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/deliveryRspCode
sed -i "s#|#l#g"  ~/zwb/temp/deliveryRspCode

grep -Po "${deliveryResult}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/deliveryResult
sed -i "s#|#l#g"  ~/zwb/temp/deliveryResult
grep -Po "${src}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/src
sed -i "s#|#l#g"  ~/zwb/temp/src

grep -Po "${owner}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/owner
sed -i "s#|#l#g"  ~/zwb/temp/owner

grep -Po "${chargeCount}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/chargeCount
sed -i "s#|#l#g"  ~/zwb/temp/chargeCount

grep -Po "${callEvent}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/callEvent
sed -i "s#|#l#g"  ~/zwb/temp/callEvent
grep -Po "${callProcess}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/callProcess
sed -i "s#|#l#g"  ~/zwb/temp/callProcess

grep -Po "${parentEnterpriseID}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/parentEnterpriseID
sed -i "s#|#l#g"  ~/zwb/temp/parentEnterpriseID

grep -Po "${parentEnterpriseCode}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/parentEnterpriseCode
sed -i "s#|#l#g"  ~/zwb/temp/parentEnterpriseCode

grep -Po "${parentEnterpriseName}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/parentEnterpriseName
sed -i "s#|#l#g"  ~/zwb/temp/parentEnterpriseName
grep -Po "${msgType}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/msgType
sed -i "s#|#l#g"  ~/zwb/temp/msgType

grep -Po "${orderId}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/orderId
sed -i "s#|#l#g"  ~/zwb/temp/orderId

grep -Po "${subscribeId}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/subscribeId
sed -i "s#|#l#g"  ~/zwb/temp/subscribeId

grep -Po "${contentArgs}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/contentArgs
sed -i "s#|#l#g"  ~/zwb/temp/contentArgs
grep -Po "${deliveryTimestamp}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/deliveryTimestamp
sed -i "s#|#l#g"  ~/zwb/temp/deliveryTimestamp

grep -Po "${packageCode}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/packageCode
sed -i "s#|#l#g"  ~/zwb/temp/packageCode

grep -Po "${productCode}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/productCode
sed -i "s#|#l#g"  ~/zwb/temp/productCode

grep -Po "${timestamp}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/timestamp
sed -i "s#|#l#g"  ~/zwb/temp/timestamp
grep -Po "${sensitiveWords}[\" :]+\K[^\"]+"  ~/zwb/temp/es_json.txt > ~/zwb/temp/sensitiveWords
sed -i "s#|#l#g"  ~/zwb/temp/sensitiveWords

paste -d"|" ~/zwb/temp/serviceID ~/zwb/temp/callingPhone ~/zwb/temp/calledPhone ~/zwb/temp/contRuleID ~/zwb/temp/statID ~/zwb/temp/callingIdentity ~/zwb/temp/callingTime ~/zwb/temp/noSendColorReason ~/zwb/temp/colorPushTime ~/zwb/temp/colorSendDelayTime ~/zwb/temp/colorSendType ~/zwb/temp/noUssdSendResult ~/zwb/temp/ussdSendResult ~/zwb/temp/pushColorContent ~/zwb/temp/pushColorID ~/zwb/temp/pushColorBoxID ~/zwb/temp/callTimes ~/zwb/temp/forwardPhone ~/zwb/temp/chargeNumber ~/zwb/temp/enterpriseID ~/zwb/temp/enterpriseCode ~/zwb/temp/enterpriseName ~/zwb/temp/enterpriseType ~/zwb/temp/serviceType ~/zwb/temp/subServiceType ~/zwb/temp/provinceIdentify ~/zwb/temp/cityIdentify ~/zwb/temp/sessionIdentify ~/zwb/temp/contentIdentify ~/zwb/temp/target ~/zwb/temp/deliveryReqTime ~/zwb/temp/deliveryRspTime ~/zwb/temp/deliveryResultReqTime ~/zwb/temp/deliveryResultRspTime ~/zwb/temp/deliveryRspCode ~/zwb/temp/deliveryResult ~/zwb/temp/src ~/zwb/temp/owner ~/zwb/temp/chargeCount ~/zwb/temp/callEvent ~/zwb/temp/callProcess ~/zwb/temp/parentEnterpriseID ~/zwb/temp/parentEnterpriseCode ~/zwb/temp/parentEnterpriseName ~/zwb/temp/msgType ~/zwb/temp/orderId ~/zwb/temp/subscribeId ~/zwb/temp/contentArgs ~/zwb/temp/deliveryTimestamp ~/zwb/temp/packageCode ~/zwb/temp/productCode ~/zwb/temp/timestamp ~/zwb/temp/sensitiveWords  >~/zwb/es_cdr/es_cdr_${date}.txt


done
