#!/bin/bash
curl -XGET '10.124.72.189:9200/delivery_detail/delivery_record/_search?pretty'  -H 'Content-Type: application/json' -d'
{
    "query": {
    "bool": {
      "must": [
        {
          "match": {
            "parentEnterpriseID": "20000037"
          }
        }
      ],
      "filter": {
        "range": {
          "colorPushTime": {
            "gte": "20200229000000000",
            "lt":  "20200301000000000"
          }
        }
      },
    "minimum_should_match": 1,
                                        "should": [{
                                                "match_phrase": {
                                                        "deliveryResult": "0"
                                                }
                                        },
                                        {
                                                "match_phrase": {
                                                        "deliveryResult": "1"
                                                }
                                        },
                                        {
                                                "match_phrase": {
                                                        "deliveryResult": "2"
                                                }
                                        },
                                                                                {
                                                "match_phrase": {
                                                        "deliveryResult": "8"
                                                }
                                        },
                                                                                {
                                                "match_phrase": {
                                                        "deliveryResult": "999"
                                                }
                                        }]
        }
     },
    "aggs" : {
        "return_sum" : {
            "sum" : {
                "field" : "chargeCount"
            }
        }
    }
}' > ~/zwb/temp/20000037_byday_json.txt

reqcount=`grep -A1 hits ~/zwb/temp/20000037_byday_json.txt |grep total |awk '{print $3}' |awk -F "," '{print $1}'`
jfcount=`grep -A1 return_sum ~/zwb/temp/20000037_byday_json.txt |grep value |awk '{print $NF}' |awk -F "." '{print $1}'`
#话单输出：日期|父企业id|请求条数|计费条数
echo -n "20200229" >> ~/zwb/temp/parentEnterpriseID_count.txt
echo -n "|" >>  ~/zwb/temp/parentEnterpriseID_count.txt
echo -n "20000037" >> ~/zwb/temp/parentEnterpriseID_count.txt
echo -n "|" >>  ~/zwb/temp/parentEnterpriseID_count.txt
echo -n ${reqcount} >> ~/zwb/temp/parentEnterpriseID_count.txt
echo -n "|" >>  ~/zwb/temp/parentEnterpriseID_count.txt
echo -n ${jfcount} >> ~/zwb/temp/parentEnterpriseID_count.txt
echo "">>  ~/zwb/temp/parentEnterpriseID_count.txt
