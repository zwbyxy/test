#!/bin/bash
es_getdata(){
##所有量
curl -XGET '10.124.72.189:9200/delivery_detail/delivery_record/_search?pretty'  -H 'Content-Type: application/json' -d'
{
	"from" : 0 ,
	"size" : 0 ,
	"query": {
		"bool": {
			"must": [
			{
				"match": {
					"enterpriseID": "€a"
				}
			}
			],
			"filter": {
				"range": {
					"@timestamp": {
						"gte": "€b.000Z",
						"lt":  "€c.000Z"
					}
				}
			}

		}
	},
	"aggs" : {
		"return_sum" : {
			"sum" : {
				"field" : "chargeCount"
			}
		}
	}
}
' > ~/zwb/temp/€a_all_json.txt

##成功量

curl -XGET '10.124.72.189:9200/delivery_detail/delivery_record/_search?pretty'  -H 'Content-Type: application/json' -d'
{
	"from" : 0 ,
	"size" : 0 ,
	"query": {
		"bool": {
			"must": [
			{
				"match": {
					"enterpriseID": "€a"
				}
			}
			],
			"filter": {
				"range": {
					"@timestamp": {
						"gte": "€b.000Z",
						"lt":  "€c.000Z"
					}
				}
			},
			"minimum_should_match": 1,
			"should": [{
				"match_phrase": {
					"deliveryResult": "0"
				}
			},
			{
				"match_phrase": {
					"deliveryResult": "1"
				}
			},
			{
				"match_phrase": {
					"deliveryResult": "2"
				}
			},

			{
				"match_phrase": {
					"deliveryResult": "999"
				}
			},
			{
				"match_phrase": {
					"deliveryResult": "8"
				}
			}]
		}
	},
	"aggs" : {
		"return_sum" : {
			"sum" : {
				"field" : "chargeCount"
			}
		}
	}
}
' > ~/zwb/temp/€a_succes_json.txt

##所有回调量按deliveryResult聚会统计
curl -XGET '10.124.72.189:9200/delivery_detail/delivery_record/_search?pretty'  -H 'Content-Type: application/json' -d'
{
	"from" : 0 ,
	"size" : 0 ,
	"query": {
		"bool": {
			"must": [
			{
				"term": {
					"enterpriseID": "€a"
				}
			}
			],
			"filter": {
				"range": {
					"@timestamp": {
						"gte": "€b.000Z",
						"lt":  "€c.000Z"
					}
				}
			}

		}
	},
	"aggs" : {
		"return_count" : {
			"terms" : {
				"field" : "deliveryResult.keyword"
			}
		}
	}
}
' > ~/zwb/temp/€a_all_deliveryResult_count_json.txt


###所有提交相应结果deliveryRspCode聚合统计
curl -XGET '10.124.72.189:9200/delivery_detail/delivery_record/_search?pretty'  -H 'Content-Type: application/json' -d'
{
	"from" : 0 ,
	"size" : 0 ,
	"query": {
		"bool": {
			"must": [
			{
				"term": {
					"enterpriseID": "€a"
				}
			}
			],
			"filter": {
				"range": {
					"@timestamp": {
						"gte": "€b.000Z",
						"lt":  "€c.000Z"
					}
				}
			}

		}
	},
	"aggs" : {
		"return_countss" : {
			"terms" : {
				"field" : "deliveryRspCode.keyword"
			}
		}
	}
}
' > ~/zwb/temp/€a_all_deliveryRspCode_count_json.txt
#移动总量
curl -XGET '10.124.72.189:9200/delivery_detail/delivery_record/_search?pretty'  -H 'Content-Type: application/json' -d'
{
        "from" : 0 ,
        "size" : 0 ,
        "query": {
                "bool": {
                        "must": [
                        {
                                "match": {
                                        "enterpriseID": "€a"
                                }
                        }
                        ],
						"must": [
                        {
                                "match": {
                                        "owner": "YD"
                                }
                        }
                        ],	
                        "filter": {
                                "range": {
                                        "@timestamp": {
                                                "gte": "€b.000Z",
                                                "lt":  "€c.000Z"
                                        }
                                }
                        }

                }
        },
        "aggs" : {
                "return_sum" : {
                        "sum" : {
                                "field" : "chargeCount"
                        }
                }
        }
}
' > ~/zwb/temp/€a_all_YD_json.txt



#联通总量
curl -XGET '10.124.72.189:9200/delivery_detail/delivery_record/_search?pretty'  -H 'Content-Type: application/json' -d'
{
        "from" : 0 ,
        "size" : 0 ,
        "query": {
                "bool": {
                        "must": [
                        {
                                "match": {
                                        "enterpriseID": "€a"
                                }
                        }
                        ],
						"must": [
                        {
                                "match": {
                                        "owner": "LT"
                                }
                        }
                        ],	
                        "filter": {
                                "range": {
                                        "@timestamp": {
                                                "gte": "€b.000Z",
                                                "lt":  "€c.000Z"
                                        }
                                }
                        }

                }
        },
        "aggs" : {
                "return_sum" : {
                        "sum" : {
                                "field" : "chargeCount"
                        }
                }
        }
}
' > ~/zwb/temp/€a_all_LT_json.txt


#电信总量
curl -XGET '10.124.72.189:9200/delivery_detail/delivery_record/_search?pretty'  -H 'Content-Type: application/json' -d'
{
        "from" : 0 ,
        "size" : 0 ,
        "query": {
                "bool": {
                        "must": [
                        {
                                "match": {
                                        "enterpriseID": "€a"
                                }
                        }
                        ],
						"must": [
                        {
                                "match": {
                                        "owner": "DX"
                                }
                        }
                        ],							
                        "filter": {
                                "range": {
                                        "@timestamp": {
                                                "gte": "€b.000Z",
                                                "lt":  "€c.000Z"
                                        }
                                }
                        }

                }
        },
        "aggs" : {
                "return_sum" : {
                        "sum" : {
                                "field" : "chargeCount"
                        }
                }
        }
}
' > ~/zwb/temp/€a_all_DX_json.txt

#移动成功量
curl -XGET '10.124.72.189:9200/delivery_detail/delivery_record/_search?pretty'  -H 'Content-Type: application/json' -d'
{
        "from" : 0 ,
        "size" : 0 ,
        "query": {
                "bool": {
                        "must": [
                        {
                                "match": {
                                        "enterpriseID": "€a"
                                }
                        }
                        ],
                        "must": [
                        {
                                "match": {
                                        "owner": "YD"
                                }
                        }
                        ],						
                        "filter": {
                                "range": {
                                        "@timestamp": {
                                                "gte": "€b.000Z",
                                                "lt":  "€c.000Z"
                                        }
                                }
                        },
                        "minimum_should_match": 1,
                        "should": [{
                                "match_phrase": {
                                        "deliveryResult": "0"
                                }
                        },
                        {
                                "match_phrase": {
                                        "deliveryResult": "1"
                                }
                        },
                        {
                                "match_phrase": {
                                        "deliveryResult": "2"
                                }
                        },

                        {
                                "match_phrase": {
                                        "deliveryResult": "999"
                                }
                        },
                        {
                                "match_phrase": {
                                        "deliveryResult": "8"
                                }
                        }]
                }
        },
        "aggs" : {
                "return_sum" : {
                        "sum" : {
                                "field" : "chargeCount"
                        }
                }
        }
}
' > ~/zwb/temp/€a_succes_YD_json.txt



#联通成功量
curl -XGET '10.124.72.189:9200/delivery_detail/delivery_record/_search?pretty'  -H 'Content-Type: application/json' -d'
{
        "from" : 0 ,
        "size" : 0 ,
        "query": {
                "bool": {
                        "must": [
                        {
                                "match": {
                                        "enterpriseID": "€a"
                                }
                        }
                        ],
                        "must": [
                        {
                                "match": {
                                        "owner": "LT"
                                }
                        }
                        ],						
                        "filter": {
                                "range": {
                                        "@timestamp": {
                                                "gte": "€b.000Z",
                                                "lt":  "€c.000Z"
                                        }
                                }
                        },
                        "minimum_should_match": 1,
                        "should": [{
                                "match_phrase": {
                                        "deliveryResult": "0"
                                }
                        },
                        {
                                "match_phrase": {
                                        "deliveryResult": "1"
                                }
                        },
                        {
                                "match_phrase": {
                                        "deliveryResult": "2"
                                }
                        },

                        {
                                "match_phrase": {
                                        "deliveryResult": "999"
                                }
                        },
                        {
                                "match_phrase": {
                                        "deliveryResult": "8"
                                }
                        }]
                }
        },
        "aggs" : {
                "return_sum" : {
                        "sum" : {
                                "field" : "chargeCount"
                        }
                }
        }
}
' > ~/zwb/temp/€a_succes_LT_json.txt


#电信成功量
curl -XGET '10.124.72.189:9200/delivery_detail/delivery_record/_search?pretty'  -H 'Content-Type: application/json' -d'
{
        "from" : 0 ,
        "size" : 0 ,
        "query": {
                "bool": {
                        "must": [
                        {
                                "match": {
                                        "enterpriseID": "€a"
                                }
                        }
                        ],
                        "must": [
                        {
                                "match": {
                                        "owner": "DX"
                                }
                        }
                        ],						
                        "filter": {
                                "range": {
                                        "@timestamp": {
                                                "gte": "€b.000Z",
                                                "lt":  "€c.000Z"
                                        }
                                }
                        },
                        "minimum_should_match": 1,
                        "should": [{
                                "match_phrase": {
                                        "deliveryResult": "0"
                                }
                        },
                        {
                                "match_phrase": {
                                        "deliveryResult": "1"
                                }
                        },
                        {
                                "match_phrase": {
                                        "deliveryResult": "2"
                                }
                        },

                        {
                                "match_phrase": {
                                        "deliveryResult": "999"
                                }
                        },
                        {
                                "match_phrase": {
                                        "deliveryResult": "8"
                                }
                        }]
                }
        },
        "aggs" : {
                "return_sum" : {
                        "sum" : {
                                "field" : "chargeCount"
                        }
                }
        }
}
' > ~/zwb/temp/€a_succes_DX_json.txt

}


date_filter(){
grep -A1 "hits" ~/zwb/temp/€a_all_json.txt  |grep total |awk -F ": " '{print $2}' |awk -F "," '{print $1}' > ~/zwb/temp/€a_all_count.txt
grep -A1 "hits" ~/zwb/temp/€a_succes_json.txt  |grep total |awk -F ": " '{print $2}' |awk -F "," '{print $1}'> ~/zwb/temp/€a_success_count.txt
grep -A1 "hits" ~/zwb/temp/€a_succes_YD_json.txt  |grep total |awk -F ": " '{print $2}' |awk -F "," '{print $1}'>~/zwb/temp/€a_success_YD_count.txt
grep -A1 "hits" ~/zwb/temp/€a_succes_LT_json.txt  |grep total |awk -F ": " '{print $2}' |awk -F "," '{print $1}'>~/zwb/temp/€a_success_LT_count.txt
grep -A1 "hits" ~/zwb/temp/€a_succes_DX_json.txt  |grep total |awk -F ": " '{print $2}' |awk -F "," '{print $1}'>~/zwb/temp/€a_success_DX_count.txt
grep -A1 "hits" ~/zwb/temp/€a_all_YD_json.txt  |grep total |awk -F ": " '{print $2}' |awk -F "," '{print $1}'>~/zwb/temp/€a_all_YD_count.txt
grep -A1 "hits" ~/zwb/temp/€a_all_LT_json.txt  |grep total |awk -F ": " '{print $2}' |awk -F "," '{print $1}'>~/zwb/temp/€a_all_LT_count.txt
grep -A1 "hits" ~/zwb/temp/€a_all_DX_json.txt  |grep total |awk -F ": " '{print $2}' |awk -F "," '{print $1}'>~/zwb/temp/€a_all_DX_count.txt
grep "\"doc_count\""  ~/zwb/temp/€a_all_deliveryResult_count_json.txt |awk '{print $3}' >  ~/zwb/temp/€a_deliveryResult_count.txt
grep -B1 "\"doc_count\""  ~/zwb/temp/€a_all_deliveryResult_count_json.txt |grep "\"key\"" |awk -F "\"" '{print $4}' > ~/zwb/temp/€a_deliveryResult_type.txt
paste ~/zwb/temp/€a_deliveryResult_count.txt ~/zwb/temp/€a_deliveryResult_type.txt > ~/zwb/temp/€a_deliveryResult_temp.txt
awk '{print "€a""|"$1"|"$2}' ~/zwb/temp/€a_deliveryResult_temp.txt >  ~/zwb/temp/€a_deliveryResult.txt

grep "\"doc_count\""  ~/zwb/temp/€a_all_deliveryRspCode_count_json.txt |awk '{print $3}' >  ~/zwb/temp/€a_deliveryRspCode_count.txt
grep -B1 "\"doc_count\""  ~/zwb/temp/€a_all_deliveryRspCode_count_json.txt |grep "\"key\"" |awk -F "\"" '{print $4}' > ~/zwb/temp/€a_deliveryRspCode_type.txt
paste ~/zwb/temp/€a_deliveryRspCode_count.txt ~/zwb/temp/€a_deliveryRspCode_type.txt > ~/zwb/temp/€a_deliveryRspCode_temp.txt
awk '{print "€a""|"$1"|"$2}' ~/zwb/temp/€a_deliveryRspCode_temp.txt >  ~/zwb/temp/€a_deliveryRspCode.txt

SucNum=`cat  ~/zwb/temp/€a_success_count.txt`
TotalNum=`cat ~/zwb/temp/€a_all_count.txt`
YdSuccNum=`cat ~/zwb/temp/€a_success_YD_count.txt`
DxSuccNum=`cat ~/zwb/temp/€a_success_DX_count.txt`
LtSuccNum=`cat ~/zwb/temp/€a_success_LT_count.txt`
YdAllNum=`cat ~/zwb/temp/€a_all_YD_count.txt`
LtAllNum=`cat ~/zwb/temp/€a_all_LT_count.txt`
DxAllNum=`cat ~/zwb/temp/€a_all_DX_count.txt`
echo -e "0\c" > ~/zwb/temp/€a_rate.txt
echo "scale = 2; $SucNum / $TotalNum" | bc >> ~/zwb/temp/€a_rate.txt

echo -e "0\c" > ~/zwb/temp/€a_rate_YD.txt
echo "scale = 2; $YdSuccNum / $YdAllNum" | bc >> ~/zwb/temp/€a_rate_YD.txt

echo -e "0\c" > ~/zwb/temp/€a_rate_LT.txt
echo "scale = 2; $LtSuccNum / $LtAllNum" | bc >> ~/zwb/temp/€a_rate_LT.txt


echo -e "0\c" > ~/zwb/temp/€a_rate_DX.txt
echo "scale = 2; $DxSuccNum / $DxAllNum" | bc >> ~/zwb/temp/€a_rate_DX.txt
}




sendip_get(){
##判断中央短信接口服务是否正常，如果不正常重新获取微服务ip
ip=`cat  ~/zwb/temp/ip.txt|grep "10.254"`
wget -T 3 --spider -t 2 $ip:19031 &>/dev/null
if [ $? -ne 8 ]
then
	~/zwb/ip_sms.sh >~/zwb/temp/ip_sms_list.txt
	grep "10.254" ~/zwb/temp/ip_sms_list.txt > ~/zwb/temp/ip.txt
	dos2unix  ~/zwb/temp/ip.txt
	ip=`cat  ~/zwb/temp/ip.txt|grep "10.254"`
fi
}


save_note(){
##记录开始时间|结束时间|企业编码|所有数量|成功数据量|成功率|移动总量|移动成功量|移动成功率|联通总量|联通成功量|联通成功率|电信总量|电信成功量|电信成功率
ename='€h'
echo -n "€b" >> ~/zwb/temp/note_all.txt
echo -n "|" >> ~/zwb/temp/note_all.txt
echo -n "€c" >> ~/zwb/temp/note_all.txt
echo -n "|" >> ~/zwb/temp/note_all.txt
echo -n "€a" >> ~/zwb/temp/note_all.txt
echo -n "|" >> ~/zwb/temp/note_all.txt
echo -n $ename >> ~/zwb/temp/note_all.txt
echo -n "|" >> ~/zwb/temp/note_all.txt
cat ~/zwb/temp/€a_all_count.txt | xargs echo -n >>~/zwb/temp/note_all.txt
echo -n "|" >> ~/zwb/temp/note_all.txt
cat ~/zwb/temp/€a_success_count.txt | xargs echo -n >>~/zwb/temp/note_all.txt
echo -n "|" >> ~/zwb/temp/note_all.txt
cat ~/zwb/temp/€a_rate.txt | xargs echo -n >>~/zwb/temp/note_all.txt
echo -n "|" >> ~/zwb/temp/note_all.txt
cat ~/zwb/temp/€a_all_YD_count.txt | xargs echo -n >>~/zwb/temp/note_all.txt
echo -n "|" >> ~/zwb/temp/note_all.txt
cat ~/zwb/temp/€a_success_YD_count.txt | xargs echo -n >>~/zwb/temp/note_all.txt
echo -n "|" >> ~/zwb/temp/note_all.txt
cat ~/zwb/temp/€a_rate_YD.txt | xargs echo -n >>~/zwb/temp/note_all.txt
echo -n "|" >> ~/zwb/temp/note_all.txt
cat ~/zwb/temp/€a_all_LT_count.txt | xargs echo -n >>~/zwb/temp/note_all.txt
echo -n "|" >> ~/zwb/temp/note_all.txt
cat ~/zwb/temp/€a_success_LT_count.txt | xargs echo -n >>~/zwb/temp/note_all.txt
echo -n "|" >> ~/zwb/temp/note_all.txt
cat ~/zwb/temp/€a_rate_LT.txt | xargs echo -n >>~/zwb/temp/note_all.txt
echo -n "|" >> ~/zwb/temp/note_all.txt
cat ~/zwb/temp/€a_all_DX_count.txt | xargs echo -n >>~/zwb/temp/note_all.txt
echo -n "|" >> ~/zwb/temp/note_all.txt
cat ~/zwb/temp/€a_success_DX_count.txt | xargs echo -n >>~/zwb/temp/note_all.txt
echo -n "|" >> ~/zwb/temp/note_all.txt
cat ~/zwb/temp/€a_rate_DX.txt | xargs echo -n >>~/zwb/temp/note_all.txt
echo "">> ~/zwb/temp/note_all.txt
}

send_sms(){
##告警屏显部分
[ "`cat  ~/zwb/temp/€a_all_count.txt`" -eq "0" ] && {
	echo "sum is zero!!,exit."
	exit 1
}
[ `cat  ~/zwb/temp/€a_all_count.txt` -lt 10 ] && {
	echo "sum lt 10!!,exit."
	exit 1
}
a=`cat ~/zwb/temp/€a_rate.txt`
b=0.80
acount=`cat ~/zwb/temp/€a_all_count.txt`
ccount=`cat ~/zwb/temp/€a_success_count.txt`
YDrate=`cat ~/zwb/temp/€a_rate_YD.txt`
LTrate=`cat ~/zwb/temp/€a_rate_LT.txt`
DXrate=`cat ~/zwb/temp/€a_rate_DX.txt`

if [ `expr $a  \> $b` -eq 0 -a "$a" != "01.00" ];
then
	echo "小于指标，需要发短信。"
	for string in `cat  ~/zwb/temp/€a_deliveryResult.txt`
	do
		type=`echo $string | awk -F "|" '{print "回调类型："$3","}'`
		type_count=`echo  $string | awk -F "|" '{print "数量："$2"； "}'`
		zwbmsg=$zwbmsg${type}$type_count

	done

	for stringc in `cat  ~/zwb/temp/€a_deliveryRspCode.txt`
	do
		typec=`echo $stringc | awk -F "|" '{print "投递响应类型："$3","}'`
		typec_count=`echo  $stringc | awk -F "|" '{print "数量："$2"； "}'`
		zwbmsgc=$zwbmsgc${typec}$typec_count

	done
	#移动、联通、电信成功量、成功率
	YdLtDxmsg=`echo "【移动总量:${YdAllNum},成功量:${YdSuccNum},成功率:${YDrate}】;【联通总量:${LtAllNum},成功量:${LtSuccNum},成功率:${LTrate}】;【电信总量:${DxAllNum},成功量:${DxSuccNum},成功率:${DXrate}】"`

	#时间转换为北京时间
	stime=€b
	etime=€c

	starttime=`echo "$stime" |sed "s#T# #g"`
	endtime=`echo "$etime"|sed "s#T# #g"`

	seconds_stime=`date -d "$starttime" +%s`
	seconds_stime_temp=`expr $seconds_stime + 28800`
	stime=`date -d @$seconds_stime_temp "+%Y-%m-%d %H:%M:%S"`

	seconds_etime=`date -d "$endtime" +%s`
	seconds_etime_temp=`expr $seconds_etime + 28800`
	etime=`date -d @$seconds_etime_temp "+%Y-%m-%d %H:%M:%S"`

	msg="企业：$ename，编码€a,于$stime到$etime,投递量：$acount,成功量$ccount：成功率：$a，小于等于指标$b。【$zwbmsgc;】 【$zwbmsg】;${YdLtDxmsg}"

	sed -i "s/€f/$msg/g"  /data/qglogs/ecpe/debug/zwb_post/zwb_sms_post.sh
	sed -i "s/€p/$ip/g"  /data/qglogs/ecpe/debug/zwb_post/zwb_sms_post.sh
	cp /data/qglogs/ecpe/debug/zwb_post/zwb_sms_post.sh /data/qglogs/ecpe/debug/zwb_post/zwb_sms_post_temp.sh

	for p in `cat ~/zwb/phone.txt`
	do
		cat  /data/qglogs/ecpe/debug/zwb_post/zwb_sms_post_temp.sh >  /data/qglogs/ecpe/debug/zwb_post/zwb_sms_post.sh
		sed -i "s/€d/$p/g" /data/qglogs/ecpe/debug/zwb_post/zwb_sms_post.sh

		sh /data/qglogs/ecpe/debug/zwb_post/zwb_sms_post.sh

		cat /data/qglogs/ecpe/debug/zwb_post/zwb_sms_post.sh >> ~/zwb/temp/zwb.log
		if [ $? -eq 0 ]
		then
			echo "告警内容：“$msg” 下发成功。"
		else
			echo "告警内容：“$msg” 下发失败。"
		fi
	done
	cat /data/qglogs/ecpe/debug/zwb_post/zwb_sms_post.sh >  /data/qglogs/ecpe/debug/zwb_post/zwb_sms_post.sh_bak
	cat  /root/zwb/zwb_sms_post_template.sh >  /data/qglogs/ecpe/debug/zwb_post/zwb_sms_post.sh

else
	echo "不需要发短信。"
fi
}

main(){
es_getdata
date_filter
sendip_get
save_note
send_sms
}

main $*
