#!/bin/bash
##检查出未备份的文件名称
rm -rf ~/zwb/temp/checklog_temp_temp 
mkdir -p ~/zwb/temp/
[ -e ~/zwb/temp/checklogall.txt ] || {
cd  ~/zwb/temp/
#touch checklogall.txt
find €a -mmin +2 -type f | xargs ls -al --time-style="+%Y-%m-%d %H:%M:%S" |grep '.log' | awk '{print $6"_"$7"|"$8}'>~/zwb/temp/checklogall.txt
}

find €a -mmin +2 -type f | xargs ls -al --time-style="+%Y-%m-%d %H:%M:%S" |grep '.log' | awk '{print $6"_"$7"|"$8}'> ~/zwb/temp/checklognewnote.txt
##根据时间获取未备份的日志名称,并将所有数据备份记录到~/zwb/temp/checklogall.txt
cat  ~/zwb/temp/checklognewnote.txt >  ~/zwb/temp/checklog_temp.txt
for rule in  `cat ~/zwb/temp/checklognewnote.txt`
do
filedate=`echo ${rule}|awk -F "|" '{print $1}'`
filename=`echo ${rule}|awk -F "|" '{print $2}'`

sametime=`awk -v filedate="$filedate" -v  filename="$filename"  'BEGIN{FS=OFS="|"}{if ($1==filedate) print $1}' ~/zwb/temp/checklogall.txt` 
if [ -z ${sametime}  ]
then
echo "${sametime} is null."
else
grep -v "${sametime}"  ~/zwb/temp/checklog_temp.txt > ~/zwb/temp/checklog_temp_temp
fi

if [ -e ~/zwb/temp/checklog_temp_temp ]
then
cat ~/zwb/temp/checklog_temp_temp > ~/zwb/temp/checklog_temp.txt
echo "after1:"
#cat ~/zwb/temp/checklog_temp.txt 
else
echo "after2:"
#cat ~/zwb/temp/checklog_temp.txt 
fi

done
cat  ~/zwb/temp/checklog_temp.txt >> ~/zwb/temp/checklogall.txt

