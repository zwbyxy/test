curl -XGET '10.124.72.189:9200/delivery_detail/delivery_record/_search?pretty'  -H 'Content-Type: application/json' -d'
{
        "from" : 0 ,
        "size" : 0 ,
        "query": {
                "bool": {
                        "must": [
                        {
                                "match": {
                                        "enterpriseID": "30000726"
                                }
                        }
                        ],
                        "filter": {
                                "range": {
                                        "@timestamp": {
                                                "gte": "2020-11-27T03:24:05.000Z",
                                                "lt":  "2020-11-27T03:29:05.000Z"
                                        }
                                }
                        }

                }
        },
        "aggs" : {
                "return_sum" : {
                        "sum" : {
                                "field" : "chargeCount"
                        }
                }
        }
}'
