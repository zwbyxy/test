a="^50082605|^50082606"
echo ${a}
grep -vE "${a}" 1.txt
