#!/bin/bash
curl -XGET '10.124.72.189:9200/cy-detail/detail/_search?pretty'  -H 'Content-Type: application/json' -d'
{
 "size":  1,
  "query": {
    "bool": {
      "must": [
        {
          "bool": {
            "should": [
              {
                "term": {
                  "contRuleID": {
                    "value": "01101_30000554_1_1_506015",
                    "boost": 1
                  }
                }
              }
            ] 


          }
        }, 

        {
          "bool": {
            "should": [
              {
                "term": {
                  "noUssdSendResult": {
                    "value": "0",
                    "boost": 1
                  }
                }
              },
                           {
                "term": {
                  "ussdSendResult": {
                    "value": "0", 
                    "boost": 1
                  }
                }
              }
            ] 


          }
        },

        {
          "range": {
            "colorPushTime": {
              "from": "20200402000000",
              "to": "20200403000000",
              "include_lower": true,
              "include_upper": true,
              "boost": 1
            }
          }
        }
      ]
    }
  }
}
' > ~/zwb/temp/01101_30000554_1_1_506015_byday_json.txt

reqcount=`grep -A1 hits ~/zwb/temp/01101_30000554_1_1_506015_byday_json.txt |grep total |awk '{print $3}' |awk -F "," '{print $1}'`
enpid=`echo "01101_30000554_1_1_506015" |awk -F "_" '{print $2}'`
#话单输出：日期|子企业id|规则id|请求条数
echo -n "20200402" >> ~/zwb/temp/jingfen_mingpin_count.txt
echo -n "|" >>  ~/zwb/temp/jingfen_mingpin_count.txt
echo -n "$enpid" >> ~/zwb/temp/jingfen_mingpin_count.txt
echo -n "|" >>  ~/zwb/temp/jingfen_mingpin_count.txt
echo -n "01101_30000554_1_1_506015" >> ~/zwb/temp/jingfen_mingpin_count.txt
echo -n "|" >>  ~/zwb/temp/jingfen_mingpin_count.txt
echo -n ${reqcount} >> ~/zwb/temp/jingfen_mingpin_count.txt
echo "">>  ~/zwb/temp/jingfen_mingpin_count.txt
