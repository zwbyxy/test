##获取total
curl -XGET '10.124.72.189:9200/cy-detail/detail/_search'  -H 'Content-Type: application/json' -d'
{
 "size":  10,
  "query": {
    "bool": {
      "must": [
        {
          "bool": {
            "should": [
               {
                "term": {
                  "contRuleID": {
                    "value": "€ccc",
                    "boost": 1
                  }
                }
              }
            ]


          }
        },

        {
          "bool": {
            "should": [
              {
                "term": {
                  "noUssdSendResult": {
                    "value": "0",
                    "boost": 1
                  }
                }
              },
                           {
                "term": {
                  "ussdSendResult": {
                    "value": "0", 
                    "boost": 1
                  }
                }
              }
            ]


          }
        },

        {
          "range": {
            "colorPushTime": {
              "from": "€eee",
              "to": "€fff",
              "include_lower": true,
              "include_upper": true,
              "boost": 1
            }
          }
        }
      ]
    }
  }
}
' > ~/zwb/temp/es_get_mingpian_total_temp.txt
