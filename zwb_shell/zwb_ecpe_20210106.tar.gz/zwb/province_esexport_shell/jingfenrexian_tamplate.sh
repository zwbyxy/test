#!/bin/bash

curl -XGET '10.124.72.189:9200/delivery_detail/delivery_record/_search?pretty'  -H 'Content-Type: application/json' -d'
{
"from": €aaa,
"size": €bbb,
  "query": {
    "bool": {
      "must": [
        {
          "bool": {
            "should": [
              {
                "term": {
                  "provinceIdentify": {
                    "value": "€ccc",
                    "boost": 1
                  }
                }
              }
            ]


          }
        }, 
{
          "bool": {
            "should": [
              {
                "term": {
                  "deliveryResult": {
                    "value": "0",
                    "boost": 1
                  }
                }
              },
                                        {
                "term": {
                  "deliveryResult": {
                    "value": "1",
                    "boost": 1
                  }
                }
              },
                                        {
                "term": {
                  "deliveryResult": {
                    "value": "2",
                    "boost": 1
                  }
                }
              },
                                        {
                "term": {
                  "deliveryResult": {
                    "value": "8",
                    "boost": 1
                  }
                }
              },
                          {
                "term": {
                  "deliveryResult": {
                    "value": "999",
                    "boost": 1
                  }
                }
              }
            ]


          }
        },


        {
          "range": {
            "colorPushTime": {
              "from": "€eee",
              "to": "€fff",
              "include_lower": true,
              "include_upper": true,
              "boost": 1
            }
          }
        }
      ]
    }
  },

"sort" : [
    {
      "deliveryReqTime" : {
        "order" : "desc"
      }
    }
  ]

}
' > ~/zwb/province_esexport_shell/temp/es_json.txt

date=`date +%Y%m%d`

###将 \" 特殊字符替换为空，如果不替换grep -Po 解析json格式有问题
sed -i "s#[\\\]\"##g" ~/zwb/province_esexport_shell/temp/es_json.txt

namelist=(
serviceID€callingPhone€calledPhone€contRuleID€statID€callingIdentity€callingTime€noSendColorReason€colorPushTime€colorSendDelayTime€colorSendType€noUssdSendResult€ussdSendResult€pushColorContent€pushColorID€pushColorBoxID€callTimes€forwardPhone€chargeNumber€enterpriseID€enterpriseCode€enterpriseName€enterpriseType€serviceType€subServiceType€provinceIdentify€cityIdentify€sessionIdentify€contentIdentify€target€deliveryReqTime€deliveryRspTime€deliveryResultReqTime€deliveryResultRspTime€deliveryRspCode€deliveryResult€src€owner€chargeCount€callEvent€callProcess€parentEnterpriseID€parentEnterpriseCode€parentEnterpriseName€msgType€orderId€subscribeId€contentArgs€deliveryTimestamp€packageCode€productCode€timestamp€sensitiveWords
)

for array in ${namelist[*]}
do
serviceID=`echo ${array} |awk -F "€" '{print $1}'`
calledPhone=`echo ${array} |awk -F "€" '{print $2}'`
callingPhone=`echo ${array} |awk -F "€" '{print $3}'`
contRuleID=`echo ${array} |awk -F "€" '{print $4}'`
statID=`echo ${array} |awk -F "€" '{print $5}'`
callingIdentity=`echo ${array} |awk -F "€" '{print $6}'`
callingTime=`echo ${array} |awk -F "€" '{print $7}'`
noSendColorReason=`echo ${array} |awk -F "€" '{print $8}'`
colorPushTime=`echo ${array} |awk -F "€" '{print $9}'`
colorSendDelayTime=`echo ${array} |awk -F "€" '{print $10}'`
colorSendType=`echo ${array} |awk -F "€" '{print $11}'`
noUssdSendResult=`echo ${array} |awk -F "€" '{print $12}'`
ussdSendResult=`echo ${array} |awk -F "€" '{print $13}'`
pushColorContent=`echo ${array} |awk -F "€" '{print $14}'`
pushColorID=`echo ${array} |awk -F "€" '{print $15}'`
pushColorBoxID=`echo ${array} |awk -F "€" '{print $16}'`
callTimes=`echo ${array} |awk -F "€" '{print $17}'`
forwardPhone=`echo ${array} |awk -F "€" '{print $18}'`
chargeNumber=`echo ${array} |awk -F "€" '{print $19}'`
enterpriseID=`echo ${array} |awk -F "€" '{print $20}'`
enterpriseCode=`echo ${array} |awk -F "€" '{print $21}'`
enterpriseName=`echo ${array} |awk -F "€" '{print $22}'`
enterpriseType=`echo ${array} |awk -F "€" '{print $23}'`
serviceType=`echo ${array} |awk -F "€" '{print $24}'`
subServiceType=`echo ${array} |awk -F "€" '{print $25}'`
provinceIdentify=`echo ${array} |awk -F "€" '{print $26}'`
cityIdentify=`echo ${array} |awk -F "€" '{print $27}'`
sessionIdentify=`echo ${array} |awk -F "€" '{print $28}'`
contentIdentify=`echo ${array} |awk -F "€" '{print $29}'`
target=`echo ${array} |awk -F "€" '{print $30}'`
deliveryReqTime=`echo ${array} |awk -F "€" '{print $31}'`
deliveryRspTime=`echo ${array} |awk -F "€" '{print $32}'`
deliveryResultReqTime=`echo ${array} |awk -F "€" '{print $33}'`
deliveryResultRspTime=`echo ${array} |awk -F "€" '{print $34}'`
deliveryRspCode=`echo ${array} |awk -F "€" '{print $35}'`
deliveryResult=`echo ${array} |awk -F "€" '{print $36}'`
src=`echo ${array} |awk -F "€" '{print $37}'`
owner=`echo ${array} |awk -F "€" '{print $38}'`
chargeCount=`echo ${array} |awk -F "€" '{print $39}'`
callEvent=`echo ${array} |awk -F "€" '{print $40}'`
callProcess=`echo ${array} |awk -F "€" '{print $41}'`
parentEnterpriseID=`echo ${array} |awk -F "€" '{print $42}'`
parentEnterpriseCode=`echo ${array} |awk -F "€" '{print $43}'`
parentEnterpriseName=`echo ${array} |awk -F "€" '{print $44}'`
msgType=`echo ${array} |awk -F "€" '{print $45}'`
orderId=`echo ${array} |awk -F "€" '{print $46}'`
subscribeId=`echo ${array} |awk -F "€" '{print $47}'`
contentArgs=`echo ${array} |awk -F "€" '{print $48}'`
deliveryTimestamp=`echo ${array} |awk -F "€" '{print $49}'`
packageCode=`echo ${array} |awk -F "€" '{print $50}'`
productCode=`echo ${array} |awk -F "€" '{print $51}'`
timestamp=`echo ${array} |awk -F "€" '{print $52}'`
sensitiveWords=`echo ${array} |awk -F "€" '{print $53}'`


grep -Po "${serviceID}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/serviceID
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/serviceID

grep -Po "${callingPhone}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/callingPhone
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/callingPhone

grep -Po "${calledPhone}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/calledPhone
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/calledPhone

grep -Po "${contRuleID}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/contRuleID
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/contRuleID
grep -Po "${statID}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/statID
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/statID

grep -Po "${callingIdentity}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/callingIdentity
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/callingIdentity

grep -Po "${callingTime}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/callingTime
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/callingTime

grep -Po "${noSendColorReason}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/noSendColorReason
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/noSendColorReason
grep -Po "${colorPushTime}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/colorPushTime
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/colorPushTime

grep -Po "${colorSendDelayTime}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/colorSendDelayTime
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/colorSendDelayTime

grep -Po "${colorSendType}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/colorSendType
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/colorSendType

grep -Po "${noUssdSendResult}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/noUssdSendResult
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/noUssdSendResult
grep -Po "${ussdSendResult}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/ussdSendResult
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/ussdSendResult

grep -Po "${pushColorContent}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/pushColorContent
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/pushColorContent

grep -Po "${pushColorID}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/pushColorID
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/pushColorID

grep -Po "${pushColorBoxID}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/pushColorBoxID
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/pushColorBoxID
grep -Po "${callTimes}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/callTimes
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/callTimes

grep -Po "${forwardPhone}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/forwardPhone
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/forwardPhone

grep -Po "${chargeNumber}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/chargeNumber
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/chargeNumber

grep -Po "${enterpriseID}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/enterpriseID
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/enterpriseID
grep -Po "${enterpriseCode}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/enterpriseCode
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/enterpriseCode

grep -Po "${enterpriseName}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/enterpriseName
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/enterpriseName

grep -Po "${enterpriseType}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/enterpriseType
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/enterpriseType

grep -Po "${serviceType}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/serviceType
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/serviceType
grep -Po "${subServiceType}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/subServiceType
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/subServiceType

grep -Po "${provinceIdentify}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/provinceIdentify
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/provinceIdentify

grep -Po "${cityIdentify}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/cityIdentify
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/cityIdentify

grep -Po "${sessionIdentify}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/sessionIdentify
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/sessionIdentify
grep -Po "${contentIdentify}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/contentIdentify
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/contentIdentify

grep -Po "${target}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/target
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/target

grep -Po "${deliveryReqTime}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/deliveryReqTime
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/deliveryReqTime

grep -Po "${deliveryRspTime}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/deliveryRspTime
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/deliveryRspTime
grep -Po "${deliveryResultReqTime}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/deliveryResultReqTime
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/deliveryResultReqTime

grep -Po "${deliveryResultRspTime}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/deliveryResultRspTime
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/deliveryResultRspTime

grep -Po "${deliveryRspCode}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/deliveryRspCode
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/deliveryRspCode

grep -Po "${deliveryResult}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/deliveryResult
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/deliveryResult
grep -Po "${src}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/src
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/src

grep -Po "${owner}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/owner
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/owner

grep -Po "${chargeCount}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/chargeCount
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/chargeCount

grep -Po "${callEvent}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/callEvent
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/callEvent
grep -Po "${callProcess}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/callProcess
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/callProcess

grep -Po "${parentEnterpriseID}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/parentEnterpriseID
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/parentEnterpriseID

grep -Po "${parentEnterpriseCode}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/parentEnterpriseCode
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/parentEnterpriseCode

grep -Po "${parentEnterpriseName}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/parentEnterpriseName
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/parentEnterpriseName
grep -Po "${msgType}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/msgType
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/msgType

grep -Po "${orderId}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/orderId
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/orderId

grep -Po "${subscribeId}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/subscribeId
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/subscribeId

grep -Po "${contentArgs}[\" :]+\K[^\"]*" ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/contentArgs
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/contentArgs
grep -Po "${deliveryTimestamp}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/deliveryTimestamp
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/deliveryTimestamp

grep -Po "${packageCode}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/packageCode
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/packageCode

grep -Po "${productCode}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/productCode
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/productCode

grep -Po "${timestamp}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/timestamp
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/timestamp
grep -Po "${sensitiveWords}[\" :]+\K[^\"]+"  ~/zwb/province_esexport_shell/temp/es_json.txt > ~/zwb/province_esexport_shell/temp/sensitiveWords
sed -i "s#|#l#g"  ~/zwb/province_esexport_shell/temp/sensitiveWords

paste -d"|" ~/zwb/province_esexport_shell/temp/serviceID ~/zwb/province_esexport_shell/temp/callingPhone ~/zwb/province_esexport_shell/temp/calledPhone ~/zwb/province_esexport_shell/temp/contRuleID ~/zwb/province_esexport_shell/temp/statID ~/zwb/province_esexport_shell/temp/callingIdentity ~/zwb/province_esexport_shell/temp/callingTime ~/zwb/province_esexport_shell/temp/noSendColorReason ~/zwb/province_esexport_shell/temp/colorPushTime ~/zwb/province_esexport_shell/temp/colorSendDelayTime ~/zwb/province_esexport_shell/temp/colorSendType ~/zwb/province_esexport_shell/temp/noUssdSendResult ~/zwb/province_esexport_shell/temp/ussdSendResult ~/zwb/province_esexport_shell/temp/pushColorContent ~/zwb/province_esexport_shell/temp/pushColorID ~/zwb/province_esexport_shell/temp/pushColorBoxID ~/zwb/province_esexport_shell/temp/callTimes ~/zwb/province_esexport_shell/temp/forwardPhone ~/zwb/province_esexport_shell/temp/chargeNumber ~/zwb/province_esexport_shell/temp/enterpriseID ~/zwb/province_esexport_shell/temp/enterpriseCode ~/zwb/province_esexport_shell/temp/enterpriseName ~/zwb/province_esexport_shell/temp/enterpriseType ~/zwb/province_esexport_shell/temp/serviceType ~/zwb/province_esexport_shell/temp/subServiceType ~/zwb/province_esexport_shell/temp/provinceIdentify ~/zwb/province_esexport_shell/temp/cityIdentify ~/zwb/province_esexport_shell/temp/sessionIdentify ~/zwb/province_esexport_shell/temp/contentIdentify ~/zwb/province_esexport_shell/temp/target ~/zwb/province_esexport_shell/temp/deliveryReqTime ~/zwb/province_esexport_shell/temp/deliveryRspTime ~/zwb/province_esexport_shell/temp/deliveryResultReqTime ~/zwb/province_esexport_shell/temp/deliveryResultRspTime ~/zwb/province_esexport_shell/temp/deliveryRspCode ~/zwb/province_esexport_shell/temp/deliveryResult ~/zwb/province_esexport_shell/temp/src ~/zwb/province_esexport_shell/temp/owner ~/zwb/province_esexport_shell/temp/chargeCount ~/zwb/province_esexport_shell/temp/callEvent ~/zwb/province_esexport_shell/temp/callProcess ~/zwb/province_esexport_shell/temp/parentEnterpriseID ~/zwb/province_esexport_shell/temp/parentEnterpriseCode ~/zwb/province_esexport_shell/temp/parentEnterpriseName ~/zwb/province_esexport_shell/temp/msgType ~/zwb/province_esexport_shell/temp/orderId ~/zwb/province_esexport_shell/temp/subscribeId ~/zwb/province_esexport_shell/temp/contentArgs ~/zwb/province_esexport_shell/temp/deliveryTimestamp ~/zwb/province_esexport_shell/temp/packageCode ~/zwb/province_esexport_shell/temp/productCode ~/zwb/province_esexport_shell/temp/timestamp ~/zwb/province_esexport_shell/temp/sensitiveWords  >> ~/zwb/province_esexport_shell/province_es_cdr/es_cdr_${date}_€ccc_€ddd_€ggg.txt

#格式化话单，将“,|” 替换为“|”
sed  -i "s#,|#|#g" ~/zwb/province_esexport_shell/province_es_cdr/es_cdr_${date}_€ccc_€ddd_€ggg.txt

done
