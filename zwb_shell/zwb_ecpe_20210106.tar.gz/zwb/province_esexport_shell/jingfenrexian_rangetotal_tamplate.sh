#!/bin/bash

curl -XGET '10.124.72.189:9200/delivery_detail/delivery_record/_search?pretty'  -H 'Content-Type: application/json' -d'
{
  "query": {
    "bool": {
      "must": [
        {
          "bool": {
            "should": [
              {
                "term": {
                  "provinceIdentify": {
                    "value": "€ccc",
                    "boost": 1
                  }
                }
              }
            ]


          }
        }, 
{
          "bool": {
            "should": [
              {
                "term": {
                  "deliveryResult": {
                    "value": "0",
                    "boost": 1
                  }
                }
              },
                                        {
                "term": {
                  "deliveryResult": {
                    "value": "1",
                    "boost": 1
                  }
                }
              },
                                        {
                "term": {
                  "deliveryResult": {
                    "value": "2",
                    "boost": 1
                  }
                }
              },
                                        {
                "term": {
                  "deliveryResult": {
                    "value": "8",
                    "boost": 1
                  }
                }
              },
                          {
                "term": {
                  "deliveryResult": {
                    "value": "999",
                    "boost": 1
                  }
                }
              }
            ]


          }
        },


        {
          "range": {
            "colorPushTime": {
              "from": "€eee",
              "to": "€fff",
              "include_lower": true,
              "include_upper": true,
              "boost": 1
            }
          }
        }
      ]
    }
  },

"sort" : [
    {
      "deliveryReqTime" : {
        "order" : "desc"
      }
    }
  ]

}
' > ~/zwb/province_esexport_shell/temp/es_json_timetotal.txt

