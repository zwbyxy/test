[root@fjxm-dm-cy-k8s-master01 ~]# kubectl get pod -o wide -n caiyin | grep core-sms
cy-core-sms-64fd6878bc-2tmv6                       1/1       Running   0          2d        10.254.27.7     10.124.72.148   <none>
cy-core-sms-64fd6878bc-kchn2                       1/1       Running   0          2d        10.254.92.5     10.124.72.149   <none>
cy-core-sms-64fd6878bc-qn7t5                       1/1       Running   0          2d        10.254.57.2     10.124.72.154   <none>
cy-core-sms-64fd6878bc-r4z8r                       1/1       Running   0          2d        10.254.67.9     10.124.72.147   <none>
cy-core-sms-64fd6878bc-rwqrq                       1/1       Running   0          2d        10.254.87.3     10.124.72.155   <none>
cy-core-sms-64fd6878bc-zsx72                       1/1       Running   0          2d        10.254.23.2     10.124.72.160   <none>
cy-core-sms-family-7c4c544c84-bj94t                1/1       Running   0          3d        10.254.116.7    10.124.72.158   <none>

[root@fjxm-dm-cy-node-core15 ~]# cat 1.sh 
curl -X POST \
  http://10.254.23.2:19071/sms/send/template \
  -H 'Content-Type: application/json;charset=utf-8' \
  -H 'Connection: Keep-Alive' \
  -d '{
        "argv":[
                "告警€测试"
        ],
        "format":"FLASH",
        "platform":1,
        "receiver":"15280017653",
        "senderName":"10658086",
        "source":"ENTERPRISE",
        "templateId":"01120_2_201910171801574297"
}'
