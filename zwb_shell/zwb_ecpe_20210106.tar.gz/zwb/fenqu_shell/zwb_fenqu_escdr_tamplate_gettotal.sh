#!/bin/bash

curl -XGET '10.124.72.189:9200/cy-detail/detail/_search'  -H 'Content-Type: application/json' -d'
{
	"query": {
		"bool": {
			"must": [{
				"range": {
					"colorPushTime": {
						"from": "€aaa",
						"to": "€bbb",
						"include_lower": true,
						"include_upper": true,
						"boost": 1.0
					}
				}
			},
			{
          "bool": {
            "should": [
              {
                "term": {
                  "noUssdSendResult": {
                    "value": "0",
                    "boost": 1
                  }
                }
              },
                           {
                "term": {
                  "ussdSendResult": {
                    "value": "0",
                    "boost": 1
                  }
                }
              }
            ]


          }
        },
			{
				"wildcard": {
					"contRuleID": {
						"wildcard": "*_€ccc_*",
						"boost": 1.0
					}
				}
			}],
			"disable_coord": false,
			"adjust_pure_negative": true,
			"boost": 1.0
		}
	}
}
' > ~/zwb/temp/es_json_gettotal.txt

